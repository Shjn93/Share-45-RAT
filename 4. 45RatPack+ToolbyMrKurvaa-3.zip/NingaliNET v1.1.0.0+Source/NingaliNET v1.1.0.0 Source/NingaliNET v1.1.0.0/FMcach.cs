﻿using System;
using System.Collections.Generic;

namespace NINGALINET
{
	// Token: 0x02000032 RID: 50
	public class FMcach
	{
		// Token: 0x06000927 RID: 2343 RVA: 0x00004D60 File Offset: 0x00002F60
		public FMcach()
		{
			Class2.zP7eVJHzSiX6G();
			base..ctor();
			this.files = new List<string>();
			this.folders = new List<string>();
		}

		// Token: 0x04000449 RID: 1097
		public List<string> files;

		// Token: 0x0400044A RID: 1098
		public List<string> folders;

		// Token: 0x0400044B RID: 1099
		public string Path;
	}
}
