﻿using System;

namespace NINGALINET
{
	// Token: 0x0200005C RID: 92
	internal enum MouseState : byte
	{
		// Token: 0x04000541 RID: 1345
		None,
		// Token: 0x04000542 RID: 1346
		Over,
		// Token: 0x04000543 RID: 1347
		Down,
		// Token: 0x04000544 RID: 1348
		Block
	}
}
