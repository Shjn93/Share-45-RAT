﻿namespace NINGALINET
{
	// Token: 0x0200000B RID: 11
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class Form2 : global::System.Windows.Forms.Form
	{
		// Token: 0x060002AF RID: 687 RVA: 0x0001C45C File Offset: 0x0001A65C
		[global::System.Diagnostics.DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && this.components != null)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x0001C4A0 File Offset: 0x0001A6A0
		[global::System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::NINGALINET.Form2));
			this.Button1 = new global::System.Windows.Forms.Button();
			this.TextBox2 = new global::System.Windows.Forms.TextBox();
			this.Label2 = new global::System.Windows.Forms.Label();
			this.TextBox1 = new global::System.Windows.Forms.TextBox();
			this.Label1 = new global::System.Windows.Forms.Label();
			this.Label13 = new global::System.Windows.Forms.Label();
			this.Label15 = new global::System.Windows.Forms.Label();
			this.PictureBox3 = new global::System.Windows.Forms.PictureBox();
			((global::System.ComponentModel.ISupportInitialize)this.PictureBox3).BeginInit();
			this.SuspendLayout();
			this.Button1.BackColor = global::System.Drawing.Color.FromArgb(20, 20, 20);
			this.Button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			global::System.Windows.Forms.Control arg_B0_0 = this.Button1;
			global::System.Drawing.Point location = new global::System.Drawing.Point(31, 258);
			arg_B0_0.Location = location;
			this.Button1.Name = "Button1";
			global::System.Windows.Forms.Control arg_DA_0 = this.Button1;
			global::System.Drawing.Size size = new global::System.Drawing.Size(250, 44);
			arg_DA_0.Size = size;
			this.Button1.TabIndex = 8;
			this.Button1.Text = "www.turkhackteam.org";
			this.Button1.UseVisualStyleBackColor = false;
			this.TextBox2.BackColor = global::System.Drawing.Color.FromArgb(40, 40, 40);
			this.TextBox2.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.TextBox2.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			global::System.Windows.Forms.Control arg_14E_0 = this.TextBox2;
			location = new global::System.Drawing.Point(31, 232);
			arg_14E_0.Location = location;
			this.TextBox2.Name = "TextBox2";
			global::System.Windows.Forms.Control arg_178_0 = this.TextBox2;
			size = new global::System.Drawing.Size(250, 20);
			arg_178_0.Size = size;
			this.TextBox2.TabIndex = 10;
			this.Label2.AutoSize = true;
			global::System.Windows.Forms.Control arg_1AB_0 = this.Label2;
			location = new global::System.Drawing.Point(28, 171);
			arg_1AB_0.Location = location;
			this.Label2.Name = "Label2";
			global::System.Windows.Forms.Control arg_1D2_0 = this.Label2;
			size = new global::System.Drawing.Size(65, 14);
			arg_1D2_0.Size = size;
			this.Label2.TabIndex = 7;
			this.Label2.Text = "Username : ";
			this.TextBox1.BackColor = global::System.Drawing.Color.FromArgb(40, 40, 40);
			this.TextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.TextBox1.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			global::System.Windows.Forms.Control arg_23A_0 = this.TextBox1;
			location = new global::System.Drawing.Point(31, 189);
			arg_23A_0.Location = location;
			this.TextBox1.Name = "TextBox1";
			global::System.Windows.Forms.Control arg_264_0 = this.TextBox1;
			size = new global::System.Drawing.Size(250, 20);
			arg_264_0.Size = size;
			this.TextBox1.TabIndex = 9;
			this.Label1.AutoSize = true;
			global::System.Windows.Forms.Control arg_297_0 = this.Label1;
			location = new global::System.Drawing.Point(28, 214);
			arg_297_0.Location = location;
			this.Label1.Name = "Label1";
			global::System.Windows.Forms.Control arg_2BE_0 = this.Label1;
			size = new global::System.Drawing.Size(35, 14);
			arg_2BE_0.Size = size;
			this.Label1.TabIndex = 6;
			this.Label1.Text = "Key : ";
			this.Label13.AutoSize = true;
			this.Label13.Font = new global::System.Drawing.Font("Belwe Lt BT", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			global::System.Windows.Forms.Control arg_31A_0 = this.Label13;
			location = new global::System.Drawing.Point(86, 108);
			arg_31A_0.Location = location;
			this.Label13.Name = "Label13";
			global::System.Windows.Forms.Control arg_344_0 = this.Label13;
			size = new global::System.Drawing.Size(139, 15);
			arg_344_0.Size = size;
			this.Label13.TabIndex = 74;
			this.Label13.Text = "TurkHacker346 NGENET-RAT Cracked";
			this.Label15.AutoSize = true;
			this.Label15.Font = new global::System.Drawing.Font("Arial", 7f);
			this.Label15.ForeColor = global::System.Drawing.Color.FromArgb(100, 100, 100);
			global::System.Windows.Forms.Control arg_3B4_0 = this.Label15;
			location = new global::System.Drawing.Point(86, 125);
			arg_3B4_0.Location = location;
			this.Label15.Name = "Label15";
			global::System.Windows.Forms.Control arg_3DE_0 = this.Label15;
			size = new global::System.Drawing.Size(142, 13);
			arg_3DE_0.Size = size;
			this.Label15.TabIndex = 75;
			this.Label15.Text = "Remote Administration Tools";
			this.PictureBox3.Anchor = global::System.Windows.Forms.AnchorStyles.None;
			this.PictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("PictureBox3.Image");
			global::System.Windows.Forms.Control arg_439_0 = this.PictureBox3;
			location = new global::System.Drawing.Point(113, 12);
			arg_439_0.Location = location;
			this.PictureBox3.Name = "PictureBox3";
			global::System.Windows.Forms.Control arg_460_0 = this.PictureBox3;
			size = new global::System.Drawing.Size(86, 73);
			arg_460_0.Size = size;
			this.PictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.PictureBox3.TabIndex = 76;
			this.PictureBox3.TabStop = false;
			global::System.Drawing.SizeF autoScaleDimensions = new global::System.Drawing.SizeF(6f, 14f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FromArgb(10, 10, 10);
			size = new global::System.Drawing.Size(313, 315);
			this.ClientSize = size;
			this.Controls.Add(this.PictureBox3);
			this.Controls.Add(this.Label13);
			this.Controls.Add(this.Label15);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.TextBox2);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.TextBox1);
			this.Controls.Add(this.Label1);
			this.Font = new global::System.Drawing.Font("Arial", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ForeColor = global::System.Drawing.Color.WhiteSmoke;
			this.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form2";
			this.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "TurkHacker346 NGENET-RAT Cracked";
			this.TopMost = true;
			((global::System.ComponentModel.ISupportInitialize)this.PictureBox3).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x0400013A RID: 314
		private global::System.ComponentModel.IContainer components;
	}
}
