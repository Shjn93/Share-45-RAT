﻿using System;

// Token: 0x0200006D RID: 109
internal class Class2
{
	// Token: 0x06000B8C RID: 2956 RVA: 0x00002F54 File Offset: 0x00001154
	internal static void zP7eVJHzSiX6G()
	{
	}

	// Token: 0x04000569 RID: 1385
	private static bool bool_0;
}
