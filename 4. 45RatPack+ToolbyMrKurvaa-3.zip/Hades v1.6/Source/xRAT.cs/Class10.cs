﻿using Microsoft.VisualBasic.Devices;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;

[EditorBrowsable(EditorBrowsableState.Never), GeneratedCode("MyTemplate", "8.0.0.0")]
internal class Class10 : Computer
{
    [DebuggerHidden, EditorBrowsable(EditorBrowsableState.Never)]
    public Class10()
    {
        Class1.QaIGh5M7cuigS();
    }
}

