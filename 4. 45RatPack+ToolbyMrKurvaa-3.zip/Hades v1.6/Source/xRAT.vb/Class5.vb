﻿Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.CodeDom.Compiler
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Globalization
Imports System.Resources
Imports System.Runtime.CompilerServices

<CompilerGenerated, HideModuleName, DebuggerNonUserCode, GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), StandardModule> _
Friend NotInheritable Class Class5
    ' Methods
    Friend Shared Function asmUpuOh3() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("classique-skype-icone-5807-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_0() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Actions-configure-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_1() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Actions-configure-icon-little", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_10() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("agt_stop", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_11() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Alert-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_12() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("antivirus-bouclier-icone-7839-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_13() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("antivirus-bouclier-icone-7839-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_14() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Apps-utilities-desktop-extra-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_15() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("asterisk-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_16() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("blue-screen-of-death-ecran-des-fenetres-icone-4629-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_17() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("box-open-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_18() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("build", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_19() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("calendar-task-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_2() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Actions-document-save-all-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_20() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Chat-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_21() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("clock-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_22() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Close_2_icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_23() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("coins-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_24() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Computer1_256", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_25() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("cool-face-icone-7669-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_26() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Device-blockdevice-cubes-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_27() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Download-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_28() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("evil-face-icone-7664-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_29() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Exemple", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_3() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Actions-help-about-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_30() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("facebook-icone-8470-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_31() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("facial-laugh-icone-4834-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_32() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("FAQ-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_33() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("FAQ-icon1", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_34() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("filebrowser", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_35() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("gear-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_36() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("gear-icon1", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_37() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("gg_connecting", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_38() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("ghost-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_39() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("green_button", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_4() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Actions-media-playback-start-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_40() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("happy-smiley-red-icone-9796-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_41() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("homme-costume-cravate-utilisateur-icone-7362-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_42() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("icon_48x48_icon (1)", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_43() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("icon_48x48_icon (1)1", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_44() As Byte()
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("iniSettings", Class5.cultureInfo_0)), Byte())
    End Function

    Friend Shared Function smethod_45() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Internet_128", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_46() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("itunes2aqua", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_47() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("key-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_48() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("la-protection-bouclier-icone-9170-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_49() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("loading_circle", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_5() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Actions-view-refresh-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_50() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Locker-blue", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_51() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("messagebox_info_256", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_52() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("microphone-plus-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_53() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Mimetypes-application-x-executable-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_54() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("mouse-error-icone-4466-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_55() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("mouse-error-icone-4466-161", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_56() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("mouse-icone-9003-16 (1)", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_57() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("music-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_58() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("navigateur-terre-globe-internet-web-icone-3747-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_59() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("navigateur-terre-globe-internet-web-icone-3747-321", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_6() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("agt_action_fail", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_60() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("network-connections-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_61() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Network-Globe-Connected-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_62() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Network-Globe-Connected-icon1", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_63() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Network-Panel-Settings-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_64() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Network-Remote-Desktop-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_65() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("noip", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_66() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("page-white-paint-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_67() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Pause-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_68() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("plugin-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_69() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("png-file-icon (1)", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_7() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("agt_action_success", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_70() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("quick_restart", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_71() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("red_button", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_72() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("robot-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_73() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("RSS-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_74() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("RSS-icon1", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_75() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("rss-image-flux-reflet-10-icone-4690-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_76() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("script-icone-9524-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_77() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("shield-arrow-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_78() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("shutdown", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_79() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("skype-icone-4316-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_8() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("agt_softwareD", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_80() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("skype-icone-5820-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_81() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("skype-icone-9016-16", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_82() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("smile-face-icone-9694-32", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_83() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("start-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_84() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Status-dialog-error-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_85() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("stop-red-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_86() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("success_icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_87() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("systemsettings", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_88() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("uac-shield", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_89() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Upload-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_9() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("agt_start_here", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_90() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("USB-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_91() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("webcam-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_92() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Window-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_93() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("windows-icon", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_94() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("winmov", Class5.cultureInfo_0)), Bitmap)
    End Function

    Friend Shared Function smethod_95() As Bitmap
        Return DirectCast(RuntimeHelpers.GetObjectValue(Class5.ResourceManager_0.GetObject("Zoom-icon", Class5.cultureInfo_0)), Bitmap)
    End Function


    ' Properties
    <EditorBrowsable(EditorBrowsableState.Advanced)> _
    Friend Shared WriteOnly Property CultureInfo_0 As CultureInfo
        Set(ByVal value As CultureInfo)
            Class5.cultureInfo_0 = value
        End Set
    End Property

    <EditorBrowsable(EditorBrowsableState.Advanced)> _
    Friend Shared ReadOnly Property ResourceManager_0 As ResourceManager
        Get
            If Object.ReferenceEquals(Class5.resourceManager_0, Nothing) Then
                Dim manager As New ResourceManager("xRAT.Resources", GetType(Class5).Assembly)
                Class5.resourceManager_0 = manager
            End If
            Return Class5.resourceManager_0
        End Get
    End Property


    ' Fields
    Private Shared cultureInfo_0 As CultureInfo
    Private Shared resourceManager_0 As ResourceManager
End Class


