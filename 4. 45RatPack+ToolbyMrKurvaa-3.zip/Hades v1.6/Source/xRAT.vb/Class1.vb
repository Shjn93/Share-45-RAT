﻿Imports System
Imports System.Windows.Forms

Friend Class Class1
    ' Methods
    Friend Shared Sub QaIGh5M7cuigS()
        If Not Class1.bool_0 Then
            Class1.bool_0 = True
            MessageBox.Show("This assembly is protected by an unregistered version of Eziriz's "".NET Reactor""!")
        End If
    End Sub


    ' Fields
    Private Shared bool_0 As Boolean
End Class


