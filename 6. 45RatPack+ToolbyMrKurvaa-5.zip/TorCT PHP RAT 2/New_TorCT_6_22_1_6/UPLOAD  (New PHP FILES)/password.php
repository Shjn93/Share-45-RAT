<?php
// If you want to change your password, 
// please edit it like this: $password = "example1"; This will make the password: example1
// By default the password is: $password = "ww";
$password = "ww";
$ClientPassword = "False"; // Change in True if you want a password for your client
?>