                             ATTENT!0N, je ne garanti pas que tout ces rats sont CLEAN 
                                          A ouvrir en VM ou SANDBOXIE 
                                   ( Certains rats sont d�ja assez vieux ) 


                                                     .-*[ 45 RATS]*-.

888RAT
Babylon RAT         *
Cloud Net  v1.7
Comet Rat v0.1.4
DarkComent v5.3.1
DarkCometRAT4
DarkCometRAT42F
DarkCometRAT51-1
DarkCometRAT52-2F
DarkCometRAT53
DarkCometRAT531
DarkTrack Alien 4.1
D-RAT
DroidJack v4.4
EchoRat 0.2
Hades v1.6
HAKOPS RAT v2
IndRat v.9.5
Inmminent Monitor v3.9   *
KazyBotLite
KilerRat v10.0.0
KJw0rm V0.5X
LimeRAT v0.1.8.2F
Loki Rat
Luminosity
NanoCore 1.2.2.0
NingaliNET v1.1.0.0+Source
njRAT v0.5.0
njRAT v0.6.4
njRAT v0.7           *** Celui que l'utilise le plus 
NjRat_0.7D_Danger_Edition_2018Fransesco_Ctraik             [?clean?]
Orcus
PandoraRat 2.2
Plasma RAT 1.5
Quasar v1.3.0.0      *
Revenge-RAT v0.3     *** Pour l'interface graphique et quelques options 
SpyGate-RAT 3.2
SpyNote5.0
TorCT PHP RAT 2
UnknownRAT
VanToM RAT 1.4
xRAT v2.0 Release_3
Xtreme RAT v3.7
XtremeRAT v3.5 Private
Maus



                                                     .-*[ CRYPTERS ]*-.

Confuser Crypter 
Obfuscator **

                                                 .-*[ Binder & Spoofer ]*-.

BD2.Net Injector ***
Extension Spoofer

                                              _________________________________
                                               Uploaded by MrKurvaa for SolidFox
                                              _________________________________
