Coded by DarkCoderSc.
Unremote.org

If you wan't to submit another language file just send it to me i will update it asap.
DarkCoderSc @ Unremote.org

Have fun.