Official website : http://darkcomet-rat.com/
a http://unremote.org/ product.

Coded and Directed by DarkCoderSc (Jean-Pierre LESUEUR)

darkcodersc@gmail.com