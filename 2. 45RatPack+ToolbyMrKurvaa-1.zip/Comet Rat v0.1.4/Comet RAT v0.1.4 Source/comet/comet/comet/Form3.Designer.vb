﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.CheckBox31 = New System.Windows.Forms.CheckBox()
        Me.hidme = New System.Windows.Forms.CheckBox()
        Me.melt = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.CheckBox32 = New System.Windows.Forms.CheckBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.CheckBox28 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.tt1 = New System.Windows.Forms.Timer(Me.components)
        Me.tt2 = New System.Windows.Forms.Timer(Me.components)
        Me.tt3 = New System.Windows.Forms.Timer(Me.components)
        Me.tt4 = New System.Windows.Forms.Timer(Me.components)
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.qq1 = New System.Windows.Forms.LinkLabel()
        Me.pp1 = New System.Windows.Forms.Panel()
        Me.qq2 = New System.Windows.Forms.LinkLabel()
        Me.pp2 = New System.Windows.Forms.Panel()
        Me.qq3 = New System.Windows.Forms.LinkLabel()
        Me.pp3 = New System.Windows.Forms.Panel()
        Me.qq4 = New System.Windows.Forms.LinkLabel()
        Me.rdc = New System.Windows.Forms.Panel()
        Me.qq5 = New System.Windows.Forms.LinkLabel()
        Me.pp5 = New System.Windows.Forms.Panel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.dta = New System.Windows.Forms.CheckBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.CheckBox34 = New System.Windows.Forms.CheckBox()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.tt5 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.VisualStudioGroupBox5 = New comet.VisualStudioGroupBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CheckBox30 = New System.Windows.Forms.CheckBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.CheckBox29 = New System.Windows.Forms.CheckBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.VisualStudioGroupBox4 = New comet.VisualStudioGroupBox()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.flder = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.css = New System.Windows.Forms.RadioButton()
        Me.tcs = New System.Windows.Forms.TextBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.VisualStudioGroupBox3 = New comet.VisualStudioGroupBox()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.VisualStudioGroupBox2 = New comet.VisualStudioGroupBox()
        Me.sc = New System.Windows.Forms.Panel()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.pp0 = New System.Windows.Forms.Panel()
        Me.CheckBox39 = New System.Windows.Forms.CheckBox()
        Me.CheckBox35 = New System.Windows.Forms.CheckBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.CheckBox33 = New System.Windows.Forms.CheckBox()
        Me.CheckBox27 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox25 = New System.Windows.Forms.CheckBox()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox21 = New System.Windows.Forms.CheckBox()
        Me.CheckBox24 = New System.Windows.Forms.CheckBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.CheckBox23 = New System.Windows.Forms.CheckBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.CheckBox22 = New System.Windows.Forms.CheckBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.CheckBox26 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.PictureBox20 = New System.Windows.Forms.PictureBox()
        Me.PictureBox21 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.VisualStudioGroupBox1 = New comet.VisualStudioGroupBox()
        Me.CheckBox40 = New System.Windows.Forms.CheckBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.CheckBox36 = New System.Windows.Forms.CheckBox()
        Me.CheckBox37 = New System.Windows.Forms.CheckBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.CheckBox38 = New System.Windows.Forms.CheckBox()
        Me.Panel3.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.pp1.SuspendLayout()
        Me.pp2.SuspendLayout()
        Me.pp3.SuspendLayout()
        Me.rdc.SuspendLayout()
        Me.pp5.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.VisualStudioGroupBox5.SuspendLayout()
        Me.Panel12.SuspendLayout()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.VisualStudioGroupBox4.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel9.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.VisualStudioGroupBox3.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.VisualStudioGroupBox2.SuspendLayout()
        Me.sc.SuspendLayout()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pp0.SuspendLayout()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.VisualStudioGroupBox1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'CheckBox31
        '
        Me.CheckBox31.AutoSize = True
        Me.CheckBox31.Location = New System.Drawing.Point(107, 79)
        Me.CheckBox31.Name = "CheckBox31"
        Me.CheckBox31.Size = New System.Drawing.Size(81, 18)
        Me.CheckBox31.TabIndex = 49
        Me.CheckBox31.Text = "Run sleep"
        Me.CheckBox31.UseVisualStyleBackColor = True
        '
        'hidme
        '
        Me.hidme.AutoSize = True
        Me.hidme.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hidme.Location = New System.Drawing.Point(3, 58)
        Me.hidme.Name = "hidme"
        Me.hidme.Size = New System.Drawing.Size(103, 17)
        Me.hidme.TabIndex = 21
        Me.hidme.Text = "Hide After Run"
        Me.hidme.UseVisualStyleBackColor = True
        '
        'melt
        '
        Me.melt.AutoSize = True
        Me.melt.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.melt.ForeColor = System.Drawing.Color.Black
        Me.melt.Location = New System.Drawing.Point(3, 80)
        Me.melt.Name = "melt"
        Me.melt.Size = New System.Drawing.Size(103, 17)
        Me.melt.TabIndex = 20
        Me.melt.Text = "Melt After Run"
        Me.melt.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox13.Location = New System.Drawing.Point(109, 58)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(84, 17)
        Me.CheckBox13.TabIndex = 4
        Me.CheckBox13.Text = "Persistence"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'CheckBox32
        '
        Me.CheckBox32.AutoSize = True
        Me.CheckBox32.Location = New System.Drawing.Point(7, 3)
        Me.CheckBox32.Name = "CheckBox32"
        Me.CheckBox32.Size = New System.Drawing.Size(47, 18)
        Me.CheckBox32.TabIndex = 40
        Me.CheckBox32.Text = "Run"
        Me.CheckBox32.UseVisualStyleBackColor = True
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Enabled = False
        Me.LinkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel1.Location = New System.Drawing.Point(18, 118)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(70, 14)
        Me.LinkLabel1.TabIndex = 16
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Extra Install"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Red
        Me.Panel3.Controls.Add(Me.CheckBox32)
        Me.Panel3.Controls.Add(Me.LinkLabel1)
        Me.Panel3.Controls.Add(Me.CheckBox28)
        Me.Panel3.Controls.Add(Me.CheckBox2)
        Me.Panel3.Controls.Add(Me.hidme)
        Me.Panel3.Controls.Add(Me.melt)
        Me.Panel3.Controls.Add(Me.CheckBox13)
        Me.Panel3.Controls.Add(Me.CheckBox31)
        Me.Panel3.Location = New System.Drawing.Point(290, 361)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(10, 10)
        Me.Panel3.TabIndex = 68
        '
        'CheckBox28
        '
        Me.CheckBox28.AutoSize = True
        Me.CheckBox28.Location = New System.Drawing.Point(60, 6)
        Me.CheckBox28.Name = "CheckBox28"
        Me.CheckBox28.Size = New System.Drawing.Size(59, 18)
        Me.CheckBox28.TabIndex = 65
        Me.CheckBox28.Text = "Tasks"
        Me.CheckBox28.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(10, 35)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(146, 17)
        Me.CheckBox2.TabIndex = 11
        Me.CheckBox2.Text = "Copy To Folder Startup"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button2.Location = New System.Drawing.Point(310, 350)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(190, 30)
        Me.Button2.TabIndex = 51
        Me.Button2.Text = "Build Server"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Red
        Me.GroupBox3.Controls.Add(Me.ComboBox1)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Location = New System.Drawing.Point(274, 367)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(10, 10)
        Me.GroupBox3.TabIndex = 34
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Directory Server"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(9, 39)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(114, 22)
        Me.ComboBox1.TabIndex = 26
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 14)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Directory :"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'tt1
        '
        Me.tt1.Enabled = True
        Me.tt1.Interval = 10
        '
        'tt2
        '
        Me.tt2.Interval = 10
        '
        'tt3
        '
        Me.tt3.Interval = 10
        '
        'tt4
        '
        Me.tt4.Interval = 10
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.Gainsboro
        Me.FlowLayoutPanel1.Controls.Add(Me.qq1)
        Me.FlowLayoutPanel1.Controls.Add(Me.pp1)
        Me.FlowLayoutPanel1.Controls.Add(Me.qq2)
        Me.FlowLayoutPanel1.Controls.Add(Me.pp2)
        Me.FlowLayoutPanel1.Controls.Add(Me.qq3)
        Me.FlowLayoutPanel1.Controls.Add(Me.pp3)
        Me.FlowLayoutPanel1.Controls.Add(Me.qq4)
        Me.FlowLayoutPanel1.Controls.Add(Me.rdc)
        Me.FlowLayoutPanel1.Controls.Add(Me.qq5)
        Me.FlowLayoutPanel1.Controls.Add(Me.pp5)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(4, 3)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(496, 341)
        Me.FlowLayoutPanel1.TabIndex = 8
        '
        'qq1
        '
        Me.qq1.ActiveLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.qq1.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.qq1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.qq1.DisabledLinkColor = System.Drawing.Color.DimGray
        Me.qq1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.qq1.Image = CType(resources.GetObject("qq1.Image"), System.Drawing.Image)
        Me.qq1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.qq1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.qq1.LinkColor = System.Drawing.Color.White
        Me.qq1.Location = New System.Drawing.Point(3, 0)
        Me.qq1.Name = "qq1"
        Me.qq1.Size = New System.Drawing.Size(472, 24)
        Me.qq1.TabIndex = 6
        Me.qq1.TabStop = True
        Me.qq1.Text = "Default Settings"
        Me.qq1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pp1
        '
        Me.pp1.BackColor = System.Drawing.Color.Gainsboro
        Me.pp1.Controls.Add(Me.VisualStudioGroupBox5)
        Me.pp1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.pp1.ForeColor = System.Drawing.Color.Black
        Me.pp1.Location = New System.Drawing.Point(3, 27)
        Me.pp1.Name = "pp1"
        Me.pp1.Size = New System.Drawing.Size(470, 10)
        Me.pp1.TabIndex = 4
        '
        'qq2
        '
        Me.qq2.ActiveLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.qq2.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.qq2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.qq2.DisabledLinkColor = System.Drawing.SystemColors.HotTrack
        Me.qq2.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.qq2.Image = CType(resources.GetObject("qq2.Image"), System.Drawing.Image)
        Me.qq2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.qq2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.qq2.LinkColor = System.Drawing.Color.White
        Me.qq2.Location = New System.Drawing.Point(3, 40)
        Me.qq2.Name = "qq2"
        Me.qq2.Size = New System.Drawing.Size(470, 24)
        Me.qq2.TabIndex = 7
        Me.qq2.TabStop = True
        Me.qq2.Text = "Startup installation"
        Me.qq2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pp2
        '
        Me.pp2.BackColor = System.Drawing.Color.Gainsboro
        Me.pp2.Controls.Add(Me.VisualStudioGroupBox4)
        Me.pp2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.pp2.ForeColor = System.Drawing.Color.Black
        Me.pp2.Location = New System.Drawing.Point(3, 67)
        Me.pp2.Name = "pp2"
        Me.pp2.Size = New System.Drawing.Size(470, 10)
        Me.pp2.TabIndex = 5
        '
        'qq3
        '
        Me.qq3.ActiveLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.qq3.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.qq3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.qq3.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.qq3.Image = CType(resources.GetObject("qq3.Image"), System.Drawing.Image)
        Me.qq3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.qq3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.qq3.LinkColor = System.Drawing.Color.White
        Me.qq3.Location = New System.Drawing.Point(3, 80)
        Me.qq3.Name = "qq3"
        Me.qq3.Size = New System.Drawing.Size(470, 24)
        Me.qq3.TabIndex = 8
        Me.qq3.TabStop = True
        Me.qq3.Text = " Extra"
        Me.qq3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pp3
        '
        Me.pp3.BackColor = System.Drawing.Color.Gainsboro
        Me.pp3.Controls.Add(Me.VisualStudioGroupBox3)
        Me.pp3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.pp3.Location = New System.Drawing.Point(3, 107)
        Me.pp3.Name = "pp3"
        Me.pp3.Size = New System.Drawing.Size(470, 10)
        Me.pp3.TabIndex = 9
        '
        'qq4
        '
        Me.qq4.ActiveLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.qq4.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.qq4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.qq4.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.qq4.Image = CType(resources.GetObject("qq4.Image"), System.Drawing.Image)
        Me.qq4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.qq4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.qq4.LinkColor = System.Drawing.Color.White
        Me.qq4.Location = New System.Drawing.Point(3, 120)
        Me.qq4.Name = "qq4"
        Me.qq4.Size = New System.Drawing.Size(470, 24)
        Me.qq4.TabIndex = 10
        Me.qq4.TabStop = True
        Me.qq4.Text = "Anti's and Spread"
        Me.qq4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'rdc
        '
        Me.rdc.BackColor = System.Drawing.Color.Gainsboro
        Me.rdc.Controls.Add(Me.VisualStudioGroupBox2)
        Me.rdc.Location = New System.Drawing.Point(3, 147)
        Me.rdc.Name = "rdc"
        Me.rdc.Size = New System.Drawing.Size(470, 10)
        Me.rdc.TabIndex = 63
        '
        'qq5
        '
        Me.qq5.ActiveLinkColor = System.Drawing.Color.DeepSkyBlue
        Me.qq5.BackColor = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.qq5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.qq5.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.qq5.Image = CType(resources.GetObject("qq5.Image"), System.Drawing.Image)
        Me.qq5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.qq5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.qq5.LinkColor = System.Drawing.Color.White
        Me.qq5.Location = New System.Drawing.Point(3, 160)
        Me.qq5.Name = "qq5"
        Me.qq5.Size = New System.Drawing.Size(470, 28)
        Me.qq5.TabIndex = 64
        Me.qq5.TabStop = True
        Me.qq5.Text = "if"
        Me.qq5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pp5
        '
        Me.pp5.BackColor = System.Drawing.Color.Gainsboro
        Me.pp5.Controls.Add(Me.VisualStudioGroupBox1)
        Me.pp5.ForeColor = System.Drawing.Color.Black
        Me.pp5.Location = New System.Drawing.Point(3, 191)
        Me.pp5.Name = "pp5"
        Me.pp5.Size = New System.Drawing.Size(471, 345)
        Me.pp5.TabIndex = 65
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(557, 13)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(541, 601)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 1
        Me.TabControl1.TabStop = False
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.CheckBox3)
        Me.TabPage1.Controls.Add(Me.Label29)
        Me.TabPage1.Controls.Add(Me.dta)
        Me.TabPage1.Controls.Add(Me.TextBox10)
        Me.TabPage1.Controls.Add(Me.CheckBox34)
        Me.TabPage1.Controls.Add(Me.GroupBox11)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.ImageKey = "Misc-Settings-icon.png"
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TabPage1.Size = New System.Drawing.Size(533, 574)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Install Options"
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(264, 80)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(87, 18)
        Me.CheckBox3.TabIndex = 71
        Me.CheckBox3.Text = "CheckBox3"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(279, 138)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(98, 14)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "Contact Settings"
        '
        'dta
        '
        Me.dta.AutoSize = True
        Me.dta.Location = New System.Drawing.Point(257, 30)
        Me.dta.Name = "dta"
        Me.dta.Size = New System.Drawing.Size(43, 18)
        Me.dta.TabIndex = 70
        Me.dta.Text = "dta"
        Me.dta.UseVisualStyleBackColor = True
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(258, 51)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 20)
        Me.TextBox10.TabIndex = 2
        '
        'CheckBox34
        '
        Me.CheckBox34.AutoSize = True
        Me.CheckBox34.Location = New System.Drawing.Point(258, 225)
        Me.CheckBox34.Name = "CheckBox34"
        Me.CheckBox34.Size = New System.Drawing.Size(93, 18)
        Me.CheckBox34.TabIndex = 69
        Me.CheckBox34.Text = "CheckBox34"
        Me.CheckBox34.UseVisualStyleBackColor = True
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Label8)
        Me.GroupBox11.Controls.Add(Me.TextBox4)
        Me.GroupBox11.Controls.Add(Me.CheckBox1)
        Me.GroupBox11.Location = New System.Drawing.Point(274, 294)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(92, 61)
        Me.GroupBox11.TabIndex = 37
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Copy Server to Temp"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(26, 35)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 14)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Name"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(67, 32)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(155, 20)
        Me.TextBox4.TabIndex = 2
        Me.TextBox4.Text = "Dan"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(10, 37)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(54, 18)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Copy"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'tt5
        '
        Me.tt5.Interval = 10
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel13.Controls.Add(Me.FlowLayoutPanel1)
        Me.Panel13.Controls.Add(Me.Button2)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel13.Location = New System.Drawing.Point(0, 0)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(525, 387)
        Me.Panel13.TabIndex = 4
        '
        'VisualStudioGroupBox5
        '
        Me.VisualStudioGroupBox5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.VisualStudioGroupBox5.Controls.Add(Me.CheckBox4)
        Me.VisualStudioGroupBox5.Controls.Add(Me.Panel12)
        Me.VisualStudioGroupBox5.Controls.Add(Me.Label17)
        Me.VisualStudioGroupBox5.Controls.Add(Me.PictureBox16)
        Me.VisualStudioGroupBox5.Controls.Add(Me.PictureBox17)
        Me.VisualStudioGroupBox5.Controls.Add(Me.Panel2)
        Me.VisualStudioGroupBox5.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.VisualStudioGroupBox5.ForeColor = System.Drawing.Color.Firebrick
        Me.VisualStudioGroupBox5.HeaderColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox5.Location = New System.Drawing.Point(5, 13)
        Me.VisualStudioGroupBox5.MainColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox5.Name = "VisualStudioGroupBox5"
        Me.VisualStudioGroupBox5.Size = New System.Drawing.Size(465, 269)
        Me.VisualStudioGroupBox5.TabIndex = 2
        Me.VisualStudioGroupBox5.Text = "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" &
    "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"
        Me.VisualStudioGroupBox5.TextColour = System.Drawing.Color.FromArgb(CType(CType(129, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(131, Byte), Integer))
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.BackColor = System.Drawing.Color.Gainsboro
        Me.CheckBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox4.ForeColor = System.Drawing.Color.Black
        Me.CheckBox4.Location = New System.Drawing.Point(335, 120)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(126, 23)
        Me.CheckBox4.TabIndex = 72
        Me.CheckBox4.Text = "File compression"
        Me.CheckBox4.UseVisualStyleBackColor = False
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.White
        Me.Panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel12.Controls.Add(Me.TextBox5)
        Me.Panel12.Controls.Add(Me.Label2)
        Me.Panel12.Controls.Add(Me.Label5)
        Me.Panel12.Controls.Add(Me.TextBox2)
        Me.Panel12.Controls.Add(Me.Label1)
        Me.Panel12.Controls.Add(Me.TextBox1)
        Me.Panel12.Location = New System.Drawing.Point(5, 29)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(423, 80)
        Me.Panel12.TabIndex = 0
        '
        'TextBox5
        '
        Me.TextBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TextBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TextBox5.BackColor = System.Drawing.Color.White
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox5.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.ForeColor = System.Drawing.Color.Black
        Me.TextBox5.Location = New System.Drawing.Point(86, 30)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(270, 22)
        Me.TextBox5.TabIndex = 8
        Me.TextBox5.Text = "Hacked"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(252, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Port :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.White
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(4, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(24, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "ID :"
        '
        'TextBox2
        '
        Me.TextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TextBox2.BackColor = System.Drawing.Color.White
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.Color.Black
        Me.TextBox2.Location = New System.Drawing.Point(292, 3)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(64, 22)
        Me.TextBox2.TabIndex = 6
        Me.TextBox2.Text = "1122"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(4, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "DNS Address :"
        '
        'TextBox1
        '
        Me.TextBox1.AutoCompleteCustomSource.AddRange(New String() {"127.0.0.1"})
        Me.TextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.Black
        Me.TextBox1.Location = New System.Drawing.Point(86, 3)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(160, 22)
        Me.TextBox1.TabIndex = 4
        Me.TextBox1.Text = "127.0.0.1"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Gainsboro
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(33, 121)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(148, 19)
        Me.Label17.TabIndex = 66
        Me.Label17.Text = "Install Scheduled Tasks"
        '
        'PictureBox16
        '
        Me.PictureBox16.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox16.Image = CType(resources.GetObject("PictureBox16.Image"), System.Drawing.Image)
        Me.PictureBox16.Location = New System.Drawing.Point(4, 114)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox16.TabIndex = 59
        Me.PictureBox16.TabStop = False
        '
        'PictureBox17
        '
        Me.PictureBox17.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox17.Image = CType(resources.GetObject("PictureBox17.Image"), System.Drawing.Image)
        Me.PictureBox17.Location = New System.Drawing.Point(4, 114)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox17.TabIndex = 60
        Me.PictureBox17.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.CheckBox30)
        Me.Panel2.Controls.Add(Me.TextBox7)
        Me.Panel2.Controls.Add(Me.CheckBox29)
        Me.Panel2.Controls.Add(Me.Label21)
        Me.Panel2.Controls.Add(Me.TextBox13)
        Me.Panel2.Controls.Add(Me.TextBox12)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.TextBox8)
        Me.Panel2.Enabled = False
        Me.Panel2.ForeColor = System.Drawing.Color.Black
        Me.Panel2.Location = New System.Drawing.Point(7, 143)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(452, 113)
        Me.Panel2.TabIndex = 58
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.White
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(267, 5)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(89, 19)
        Me.Label7.TabIndex = 73
        Me.Label7.Text = "Every minute"
        '
        'CheckBox30
        '
        Me.CheckBox30.AutoSize = True
        Me.CheckBox30.BackColor = System.Drawing.Color.White
        Me.CheckBox30.Checked = True
        Me.CheckBox30.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox30.ForeColor = System.Drawing.Color.Black
        Me.CheckBox30.Location = New System.Drawing.Point(336, 27)
        Me.CheckBox30.Name = "CheckBox30"
        Me.CheckBox30.Size = New System.Drawing.Size(56, 23)
        Me.CheckBox30.TabIndex = 75
        Me.CheckBox30.Text = "Loop"
        Me.CheckBox30.UseVisualStyleBackColor = False
        '
        'TextBox7
        '
        Me.TextBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TextBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TextBox7.BackColor = System.Drawing.Color.White
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox7.Enabled = False
        Me.TextBox7.ForeColor = System.Drawing.Color.Black
        Me.TextBox7.Location = New System.Drawing.Point(270, 74)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(169, 25)
        Me.TextBox7.TabIndex = 74
        '
        'CheckBox29
        '
        Me.CheckBox29.AutoSize = True
        Me.CheckBox29.BackColor = System.Drawing.Color.White
        Me.CheckBox29.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox29.ForeColor = System.Drawing.Color.Black
        Me.CheckBox29.Location = New System.Drawing.Point(271, 53)
        Me.CheckBox29.Name = "CheckBox29"
        Me.CheckBox29.Size = New System.Drawing.Size(92, 23)
        Me.CheckBox29.TabIndex = 73
        Me.CheckBox29.Text = "new Folder"
        Me.CheckBox29.UseVisualStyleBackColor = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.White
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(4, 53)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(68, 19)
        Me.Label21.TabIndex = 71
        Me.Label21.Text = "Task Path"
        '
        'TextBox13
        '
        Me.TextBox13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TextBox13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TextBox13.BackColor = System.Drawing.Color.White
        Me.TextBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox13.ForeColor = System.Drawing.Color.Black
        Me.TextBox13.Location = New System.Drawing.Point(5, 26)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(256, 25)
        Me.TextBox13.TabIndex = 3
        Me.TextBox13.Text = "Name"
        '
        'TextBox12
        '
        Me.TextBox12.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TextBox12.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TextBox12.BackColor = System.Drawing.Color.White
        Me.TextBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox12.ForeColor = System.Drawing.Color.Black
        Me.TextBox12.Location = New System.Drawing.Point(4, 74)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(257, 25)
        Me.TextBox12.TabIndex = 2
        Me.TextBox12.Text = "C:\Users\?\AppData\Server.exe"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.White
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(5, 5)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(108, 19)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Scheduled Tasks"
        '
        'TextBox8
        '
        Me.TextBox8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TextBox8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TextBox8.BackColor = System.Drawing.Color.White
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox8.ForeColor = System.Drawing.Color.Black
        Me.TextBox8.Location = New System.Drawing.Point(273, 26)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(57, 25)
        Me.TextBox8.TabIndex = 0
        Me.TextBox8.Text = "mo 1"
        '
        'VisualStudioGroupBox4
        '
        Me.VisualStudioGroupBox4.BackColor = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.VisualStudioGroupBox4.Controls.Add(Me.Panel11)
        Me.VisualStudioGroupBox4.Controls.Add(Me.Panel10)
        Me.VisualStudioGroupBox4.Controls.Add(Me.Panel9)
        Me.VisualStudioGroupBox4.Controls.Add(Me.PictureBox12)
        Me.VisualStudioGroupBox4.Controls.Add(Me.Label14)
        Me.VisualStudioGroupBox4.Controls.Add(Me.PictureBox3)
        Me.VisualStudioGroupBox4.Controls.Add(Me.Label22)
        Me.VisualStudioGroupBox4.Controls.Add(Me.PictureBox13)
        Me.VisualStudioGroupBox4.Controls.Add(Me.Label13)
        Me.VisualStudioGroupBox4.Controls.Add(Me.PictureBox2)
        Me.VisualStudioGroupBox4.Controls.Add(Me.PictureBox4)
        Me.VisualStudioGroupBox4.Controls.Add(Me.PictureBox5)
        Me.VisualStudioGroupBox4.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.VisualStudioGroupBox4.HeaderColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox4.Location = New System.Drawing.Point(3, 1)
        Me.VisualStudioGroupBox4.MainColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox4.Name = "VisualStudioGroupBox4"
        Me.VisualStudioGroupBox4.Size = New System.Drawing.Size(464, 263)
        Me.VisualStudioGroupBox4.TabIndex = 2
        Me.VisualStudioGroupBox4.Text = resources.GetString("VisualStudioGroupBox4.Text")
        Me.VisualStudioGroupBox4.TextColour = System.Drawing.Color.FromArgb(CType(CType(129, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(131, Byte), Integer))
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.White
        Me.Panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel11.Controls.Add(Me.Label6)
        Me.Panel11.Controls.Add(Me.TextBox6)
        Me.Panel11.Enabled = False
        Me.Panel11.Location = New System.Drawing.Point(7, 74)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(175, 65)
        Me.Panel11.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.White
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(9, 14)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 19)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Key :"
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.Color.White
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox6.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.ForeColor = System.Drawing.Color.Black
        Me.TextBox6.Location = New System.Drawing.Point(47, 13)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(116, 22)
        Me.TextBox6.TabIndex = 12
        Me.TextBox6.Text = "Google Chrome"
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.White
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel10.Controls.Add(Me.flder)
        Me.Panel10.Controls.Add(Me.TextBox9)
        Me.Panel10.Controls.Add(Me.Label9)
        Me.Panel10.Controls.Add(Me.Label12)
        Me.Panel10.Enabled = False
        Me.Panel10.Location = New System.Drawing.Point(185, 73)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(276, 66)
        Me.Panel10.TabIndex = 2
        '
        'flder
        '
        Me.flder.BackColor = System.Drawing.Color.White
        Me.flder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.flder.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.flder.ForeColor = System.Drawing.Color.Black
        Me.flder.Location = New System.Drawing.Point(100, 7)
        Me.flder.Name = "flder"
        Me.flder.Size = New System.Drawing.Size(127, 22)
        Me.flder.TabIndex = 11
        Me.flder.Text = "Folder"
        Me.flder.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.White
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox9.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.ForeColor = System.Drawing.Color.Black
        Me.TextBox9.Location = New System.Drawing.Point(100, 34)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(127, 22)
        Me.TextBox9.TabIndex = 9
        Me.TextBox9.Text = "Server.exe"
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(5, 12)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 13)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Folder Name   :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.White
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(5, 39)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(87, 13)
        Me.Label12.TabIndex = 10
        Me.Label12.Text = "EXE Name        :"
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.White
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel9.Controls.Add(Me.RadioButton1)
        Me.Panel9.Controls.Add(Me.css)
        Me.Panel9.Controls.Add(Me.tcs)
        Me.Panel9.Enabled = False
        Me.Panel9.Location = New System.Drawing.Point(11, 175)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(403, 67)
        Me.Panel9.TabIndex = 2
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.BackColor = System.Drawing.Color.White
        Me.RadioButton1.Checked = True
        Me.RadioButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RadioButton1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton1.ForeColor = System.Drawing.Color.Black
        Me.RadioButton1.Location = New System.Drawing.Point(165, 16)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(53, 17)
        Me.RadioButton1.TabIndex = 18
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "None"
        Me.RadioButton1.UseVisualStyleBackColor = False
        '
        'css
        '
        Me.css.AutoSize = True
        Me.css.BackColor = System.Drawing.Color.White
        Me.css.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.css.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.css.ForeColor = System.Drawing.Color.Black
        Me.css.Location = New System.Drawing.Point(3, 14)
        Me.css.Name = "css"
        Me.css.Size = New System.Drawing.Size(143, 17)
        Me.css.TabIndex = 15
        Me.css.Text = "Apllication Data Folder"
        Me.css.UseVisualStyleBackColor = False
        '
        'tcs
        '
        Me.tcs.BackColor = System.Drawing.Color.White
        Me.tcs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tcs.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tcs.ForeColor = System.Drawing.Color.Black
        Me.tcs.Location = New System.Drawing.Point(3, 35)
        Me.tcs.Name = "tcs"
        Me.tcs.Size = New System.Drawing.Size(245, 22)
        Me.tcs.TabIndex = 1
        Me.tcs.Text = "Comet\Folder"
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox12.Image = CType(resources.GetObject("PictureBox12.Image"), System.Drawing.Image)
        Me.PictureBox12.Location = New System.Drawing.Point(6, 38)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox12.TabIndex = 54
        Me.PictureBox12.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Gainsboro
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(31, 44)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(54, 19)
        Me.Label14.TabIndex = 53
        Me.Label14.Text = "Startup"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(185, 38)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox3.TabIndex = 50
        Me.PictureBox3.TabStop = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Gainsboro
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(36, 149)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(87, 19)
        Me.Label22.TabIndex = 71
        Me.Label22.Text = "Install Server"
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox13.Image = CType(resources.GetObject("PictureBox13.Image"), System.Drawing.Image)
        Me.PictureBox13.Location = New System.Drawing.Point(6, 38)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox13.TabIndex = 55
        Me.PictureBox13.TabStop = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Gainsboro
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(208, 44)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(104, 19)
        Me.Label13.TabIndex = 52
        Me.Label13.Text = "Name - Startup"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(7, 146)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox2.TabIndex = 69
        Me.PictureBox2.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(185, 38)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox4.TabIndex = 51
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(7, 145)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox5.TabIndex = 70
        Me.PictureBox5.TabStop = False
        '
        'VisualStudioGroupBox3
        '
        Me.VisualStudioGroupBox3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.VisualStudioGroupBox3.Controls.Add(Me.Panel8)
        Me.VisualStudioGroupBox3.Controls.Add(Me.Label10)
        Me.VisualStudioGroupBox3.Controls.Add(Me.Panel7)
        Me.VisualStudioGroupBox3.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.VisualStudioGroupBox3.HeaderColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox3.Location = New System.Drawing.Point(5, 9)
        Me.VisualStudioGroupBox3.MainColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox3.Name = "VisualStudioGroupBox3"
        Me.VisualStudioGroupBox3.Size = New System.Drawing.Size(462, 191)
        Me.VisualStudioGroupBox3.TabIndex = 2
        Me.VisualStudioGroupBox3.Text = "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\" &
    "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\"
        Me.VisualStudioGroupBox3.TextColour = System.Drawing.Color.FromArgb(CType(CType(129, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(131, Byte), Integer))
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.White
        Me.Panel8.Controls.Add(Me.PictureBox8)
        Me.Panel8.Controls.Add(Me.PictureBox6)
        Me.Panel8.Controls.Add(Me.PictureBox14)
        Me.Panel8.Controls.Add(Me.TextBox3)
        Me.Panel8.Controls.Add(Me.PictureBox15)
        Me.Panel8.Controls.Add(Me.Button5)
        Me.Panel8.Controls.Add(Me.Label25)
        Me.Panel8.Controls.Add(Me.Label4)
        Me.Panel8.Controls.Add(Me.Label20)
        Me.Panel8.Controls.Add(Me.PictureBox7)
        Me.Panel8.Controls.Add(Me.Label19)
        Me.Panel8.Controls.Add(Me.Label18)
        Me.Panel8.Controls.Add(Me.PictureBox9)
        Me.Panel8.Controls.Add(Me.PictureBox10)
        Me.Panel8.Controls.Add(Me.PictureBox11)
        Me.Panel8.Location = New System.Drawing.Point(14, 49)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(434, 77)
        Me.Panel8.TabIndex = 2
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.White
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(117, 53)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(41, 22)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox8.TabIndex = 55
        Me.PictureBox8.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.White
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(246, 54)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(41, 22)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox6.TabIndex = 53
        Me.PictureBox6.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.White
        Me.PictureBox14.Image = CType(resources.GetObject("PictureBox14.Image"), System.Drawing.Image)
        Me.PictureBox14.Location = New System.Drawing.Point(350, 53)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(41, 22)
        Me.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox14.TabIndex = 63
        Me.PictureBox14.TabStop = False
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.White
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.ForeColor = System.Drawing.Color.Black
        Me.TextBox3.Location = New System.Drawing.Point(55, 5)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(270, 22)
        Me.TextBox3.TabIndex = 1
        Me.TextBox3.Text = "1DC0Z5T8L9-1DC0Z5T8L9-1DC0Z5T8L9"
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PictureBox15
        '
        Me.PictureBox15.BackColor = System.Drawing.Color.White
        Me.PictureBox15.Image = CType(resources.GetObject("PictureBox15.Image"), System.Drawing.Image)
        Me.PictureBox15.Location = New System.Drawing.Point(350, 53)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(41, 22)
        Me.PictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox15.TabIndex = 64
        Me.PictureBox15.TabStop = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.White
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button5.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(329, 4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(35, 23)
        Me.Button5.TabIndex = 0
        Me.Button5.Text = "..."
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.White
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(349, 37)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(45, 19)
        Me.Label25.TabIndex = 62
        Me.Label25.Text = "BSOD"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.White
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(4, 8)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Mutex :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.White
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(233, 36)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(99, 19)
        Me.Label20.TabIndex = 61
        Me.Label20.Text = "Hide After Run"
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.White
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(246, 54)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(41, 22)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox7.TabIndex = 54
        Me.PictureBox7.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.White
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(100, 35)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(99, 19)
        Me.Label19.TabIndex = 60
        Me.Label19.Text = "Melt After Run"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.White
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(7, 34)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(77, 19)
        Me.Label18.TabIndex = 59
        Me.Label18.Text = "Persistence"
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.White
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(117, 53)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(41, 22)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox9.TabIndex = 56
        Me.PictureBox9.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.White
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(24, 52)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(41, 22)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox10.TabIndex = 57
        Me.PictureBox10.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.BackColor = System.Drawing.Color.White
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(24, 52)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(41, 22)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox11.TabIndex = 58
        Me.PictureBox11.TabStop = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Gainsboro
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(6, 31)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(130, 19)
        Me.Label10.TabIndex = 65
        Me.Label10.Text = "Mutex - Persistence"
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.White
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.Label23)
        Me.Panel7.Controls.Add(Me.Label11)
        Me.Panel7.Controls.Add(Me.LinkLabel3)
        Me.Panel7.Controls.Add(Me.PictureBox1)
        Me.Panel7.Controls.Add(Me.LinkLabel2)
        Me.Panel7.Location = New System.Drawing.Point(17, 130)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(431, 49)
        Me.Panel7.TabIndex = 2
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.White
        Me.Label23.ForeColor = System.Drawing.Color.Maroon
        Me.Label23.Location = New System.Drawing.Point(178, 23)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(57, 19)
        Me.Label23.TabIndex = 72
        Me.Label23.Text = "Label23"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.White
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(5, 12)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(29, 13)
        Me.Label11.TabIndex = 39
        Me.Label11.Text = "Icon"
        '
        'LinkLabel3
        '
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.BackColor = System.Drawing.Color.White
        Me.LinkLabel3.ForeColor = System.Drawing.Color.Black
        Me.LinkLabel3.LinkColor = System.Drawing.Color.Black
        Me.LinkLabel3.Location = New System.Drawing.Point(82, 24)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(72, 19)
        Me.LinkLabel3.TabIndex = 42
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "Select ICO"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Location = New System.Drawing.Point(39, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(37, 35)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 37
        Me.PictureBox1.TabStop = False
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.BackColor = System.Drawing.Color.White
        Me.LinkLabel2.ForeColor = System.Drawing.Color.Black
        Me.LinkLabel2.LinkColor = System.Drawing.Color.Green
        Me.LinkLabel2.Location = New System.Drawing.Point(82, 2)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(86, 19)
        Me.LinkLabel2.TabIndex = 41
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Remove ICO"
        '
        'VisualStudioGroupBox2
        '
        Me.VisualStudioGroupBox2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.VisualStudioGroupBox2.Controls.Add(Me.sc)
        Me.VisualStudioGroupBox2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.VisualStudioGroupBox2.HeaderColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox2.Location = New System.Drawing.Point(5, 0)
        Me.VisualStudioGroupBox2.MainColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox2.Name = "VisualStudioGroupBox2"
        Me.VisualStudioGroupBox2.Size = New System.Drawing.Size(459, 408)
        Me.VisualStudioGroupBox2.TabIndex = 2
        Me.VisualStudioGroupBox2.Text = resources.GetString("VisualStudioGroupBox2.Text")
        Me.VisualStudioGroupBox2.TextColour = System.Drawing.Color.FromArgb(CType(CType(129, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(131, Byte), Integer))
        '
        'sc
        '
        Me.sc.BackColor = System.Drawing.Color.Gainsboro
        Me.sc.Controls.Add(Me.PictureBox18)
        Me.sc.Controls.Add(Me.PictureBox19)
        Me.sc.Controls.Add(Me.pp0)
        Me.sc.Controls.Add(Me.PictureBox20)
        Me.sc.Controls.Add(Me.PictureBox21)
        Me.sc.Controls.Add(Me.Panel1)
        Me.sc.Location = New System.Drawing.Point(4, 37)
        Me.sc.Name = "sc"
        Me.sc.Size = New System.Drawing.Size(442, 368)
        Me.sc.TabIndex = 38
        '
        'PictureBox18
        '
        Me.PictureBox18.Image = CType(resources.GetObject("PictureBox18.Image"), System.Drawing.Image)
        Me.PictureBox18.Location = New System.Drawing.Point(7, 291)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox18.TabIndex = 61
        Me.PictureBox18.TabStop = False
        '
        'PictureBox19
        '
        Me.PictureBox19.Image = CType(resources.GetObject("PictureBox19.Image"), System.Drawing.Image)
        Me.PictureBox19.Location = New System.Drawing.Point(7, 291)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox19.TabIndex = 62
        Me.PictureBox19.TabStop = False
        '
        'pp0
        '
        Me.pp0.BackColor = System.Drawing.Color.White
        Me.pp0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pp0.Controls.Add(Me.CheckBox39)
        Me.pp0.Controls.Add(Me.CheckBox35)
        Me.pp0.Controls.Add(Me.TextBox14)
        Me.pp0.Controls.Add(Me.Label24)
        Me.pp0.Controls.Add(Me.CheckBox33)
        Me.pp0.Controls.Add(Me.CheckBox27)
        Me.pp0.Controls.Add(Me.CheckBox5)
        Me.pp0.Controls.Add(Me.CheckBox19)
        Me.pp0.Controls.Add(Me.CheckBox18)
        Me.pp0.Controls.Add(Me.CheckBox25)
        Me.pp0.Controls.Add(Me.CheckBox7)
        Me.pp0.Controls.Add(Me.CheckBox21)
        Me.pp0.Controls.Add(Me.CheckBox24)
        Me.pp0.Controls.Add(Me.CheckBox12)
        Me.pp0.Controls.Add(Me.CheckBox6)
        Me.pp0.Controls.Add(Me.CheckBox16)
        Me.pp0.Controls.Add(Me.CheckBox9)
        Me.pp0.Controls.Add(Me.CheckBox15)
        Me.pp0.Controls.Add(Me.CheckBox23)
        Me.pp0.Controls.Add(Me.CheckBox11)
        Me.pp0.Controls.Add(Me.CheckBox10)
        Me.pp0.Controls.Add(Me.CheckBox17)
        Me.pp0.Controls.Add(Me.CheckBox22)
        Me.pp0.Controls.Add(Me.CheckBox20)
        Me.pp0.Controls.Add(Me.CheckBox26)
        Me.pp0.Controls.Add(Me.CheckBox8)
        Me.pp0.Enabled = False
        Me.pp0.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pp0.ForeColor = System.Drawing.Color.White
        Me.pp0.Location = New System.Drawing.Point(7, 33)
        Me.pp0.Name = "pp0"
        Me.pp0.Size = New System.Drawing.Size(429, 258)
        Me.pp0.TabIndex = 49
        '
        'CheckBox39
        '
        Me.CheckBox39.AutoSize = True
        Me.CheckBox39.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox39.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox39.ForeColor = System.Drawing.Color.Black
        Me.CheckBox39.Location = New System.Drawing.Point(7, 176)
        Me.CheckBox39.Name = "CheckBox39"
        Me.CheckBox39.Size = New System.Drawing.Size(72, 17)
        Me.CheckBox39.TabIndex = 66
        Me.CheckBox39.Text = "Anti-ESET"
        Me.CheckBox39.UseVisualStyleBackColor = True
        '
        'CheckBox35
        '
        Me.CheckBox35.AutoSize = True
        Me.CheckBox35.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox35.ForeColor = System.Drawing.Color.Black
        Me.CheckBox35.Location = New System.Drawing.Point(117, 175)
        Me.CheckBox35.Name = "CheckBox35"
        Me.CheckBox35.Size = New System.Drawing.Size(118, 17)
        Me.CheckBox35.TabIndex = 65
        Me.CheckBox35.Text = "Anti-.NET Reflector "
        Me.CheckBox35.UseVisualStyleBackColor = True
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.Color.White
        Me.TextBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox14.ForeColor = System.Drawing.Color.Black
        Me.TextBox14.Location = New System.Drawing.Point(81, 231)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(53, 20)
        Me.TextBox14.TabIndex = 64
        Me.TextBox14.Text = "5"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ForeColor = System.Drawing.Color.DimGray
        Me.Label24.Location = New System.Drawing.Point(134, 234)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(52, 13)
        Me.Label24.TabIndex = 62
        Me.Label24.Text = "))Startups"
        '
        'CheckBox33
        '
        Me.CheckBox33.AutoSize = True
        Me.CheckBox33.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox33.ForeColor = System.Drawing.Color.DimGray
        Me.CheckBox33.Location = New System.Drawing.Point(7, 233)
        Me.CheckBox33.Name = "CheckBox33"
        Me.CheckBox33.Size = New System.Drawing.Size(74, 17)
        Me.CheckBox33.TabIndex = 63
        Me.CheckBox33.Text = "Run After(("
        Me.CheckBox33.UseVisualStyleBackColor = True
        '
        'CheckBox27
        '
        Me.CheckBox27.AutoSize = True
        Me.CheckBox27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox27.ForeColor = System.Drawing.Color.Maroon
        Me.CheckBox27.Location = New System.Drawing.Point(251, 156)
        Me.CheckBox27.Name = "CheckBox27"
        Me.CheckBox27.Size = New System.Drawing.Size(67, 17)
        Me.CheckBox27.TabIndex = 37
        Me.CheckBox27.Text = "Select All"
        Me.CheckBox27.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox5.ForeColor = System.Drawing.Color.Black
        Me.CheckBox5.Location = New System.Drawing.Point(7, 30)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(91, 17)
        Me.CheckBox5.TabIndex = 17
        Me.CheckBox5.Text = "Anti Kill Server"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox19.ForeColor = System.Drawing.Color.Black
        Me.CheckBox19.Location = New System.Drawing.Point(7, 102)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(92, 17)
        Me.CheckBox19.TabIndex = 30
        Me.CheckBox19.Text = "Anti-Wireshark"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox18.ForeColor = System.Drawing.Color.Black
        Me.CheckBox18.Location = New System.Drawing.Point(117, 126)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(98, 17)
        Me.CheckBox18.TabIndex = 29
        Me.CheckBox18.Text = "Anti-SpeedGear"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox25
        '
        Me.CheckBox25.AutoSize = True
        Me.CheckBox25.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox25.ForeColor = System.Drawing.Color.DimGray
        Me.CheckBox25.Location = New System.Drawing.Point(251, 205)
        Me.CheckBox25.Name = "CheckBox25"
        Me.CheckBox25.Size = New System.Drawing.Size(110, 17)
        Me.CheckBox25.TabIndex = 20
        Me.CheckBox25.Text = "USB Spread / exe"
        Me.CheckBox25.UseVisualStyleBackColor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox7.ForeColor = System.Drawing.Color.Black
        Me.CheckBox7.Location = New System.Drawing.Point(117, 30)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(123, 17)
        Me.CheckBox7.TabIndex = 19
        Me.CheckBox7.Text = "Anti-Process Explorer"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox21.ForeColor = System.Drawing.Color.Black
        Me.CheckBox21.Location = New System.Drawing.Point(7, 54)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(74, 17)
        Me.CheckBox21.TabIndex = 32
        Me.CheckBox21.Text = "Anti-Cports"
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'CheckBox24
        '
        Me.CheckBox24.AutoSize = True
        Me.CheckBox24.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox24.ForeColor = System.Drawing.Color.Black
        Me.CheckBox24.Location = New System.Drawing.Point(117, 78)
        Me.CheckBox24.Name = "CheckBox24"
        Me.CheckBox24.Size = New System.Drawing.Size(90, 17)
        Me.CheckBox24.TabIndex = 35
        Me.CheckBox24.Text = "Anti-X-NetStat"
        Me.CheckBox24.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox12.ForeColor = System.Drawing.Color.DimGray
        Me.CheckBox12.Location = New System.Drawing.Point(7, 205)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(100, 17)
        Me.CheckBox12.TabIndex = 24
        Me.CheckBox12.Text = "Block VirusTotal"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox6.ForeColor = System.Drawing.Color.DimGray
        Me.CheckBox6.Location = New System.Drawing.Point(117, 205)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(107, 17)
        Me.CheckBox6.TabIndex = 18
        Me.CheckBox6.Text = "USB Spread / lnk"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox16.ForeColor = System.Drawing.Color.Black
        Me.CheckBox16.Location = New System.Drawing.Point(117, 101)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(80, 17)
        Me.CheckBox16.TabIndex = 27
        Me.CheckBox16.Text = "Anti-SbieCtrl"
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox9.ForeColor = System.Drawing.Color.Black
        Me.CheckBox9.Location = New System.Drawing.Point(117, 54)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(95, 17)
        Me.CheckBox9.TabIndex = 23
        Me.CheckBox9.Text = "Anti-ApateDNS"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox15.ForeColor = System.Drawing.Color.Black
        Me.CheckBox15.Location = New System.Drawing.Point(7, 126)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(68, 17)
        Me.CheckBox15.TabIndex = 26
        Me.CheckBox15.Text = "Anti-Avira"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBox23
        '
        Me.CheckBox23.AutoSize = True
        Me.CheckBox23.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox23.ForeColor = System.Drawing.Color.Black
        Me.CheckBox23.Location = New System.Drawing.Point(7, 78)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(79, 17)
        Me.CheckBox23.TabIndex = 34
        Me.CheckBox23.Text = "Anti-Ollydbg"
        Me.CheckBox23.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox11.ForeColor = System.Drawing.Color.Black
        Me.CheckBox11.Location = New System.Drawing.Point(251, 32)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(95, 17)
        Me.CheckBox11.TabIndex = 25
        Me.CheckBox11.Text = "Anti-AntiLogger"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox10.ForeColor = System.Drawing.Color.Black
        Me.CheckBox10.Location = New System.Drawing.Point(117, 152)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(109, 17)
        Me.CheckBox10.TabIndex = 24
        Me.CheckBox10.Text = "Anti-Malwarebytes"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox17.ForeColor = System.Drawing.Color.Black
        Me.CheckBox17.Location = New System.Drawing.Point(251, 131)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(99, 17)
        Me.CheckBox17.TabIndex = 28
        Me.CheckBox17.Text = "Anti-SpyTheSpy"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'CheckBox22
        '
        Me.CheckBox22.AutoSize = True
        Me.CheckBox22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox22.ForeColor = System.Drawing.Color.Black
        Me.CheckBox22.Location = New System.Drawing.Point(251, 83)
        Me.CheckBox22.Name = "CheckBox22"
        Me.CheckBox22.Size = New System.Drawing.Size(66, 17)
        Me.CheckBox22.TabIndex = 33
        Me.CheckBox22.Text = "Anti-AVG"
        Me.CheckBox22.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox20.ForeColor = System.Drawing.Color.Black
        Me.CheckBox20.Location = New System.Drawing.Point(7, 151)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(90, 17)
        Me.CheckBox20.TabIndex = 31
        Me.CheckBox20.Text = "Anti-IPBlocker"
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'CheckBox26
        '
        Me.CheckBox26.AutoSize = True
        Me.CheckBox26.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox26.ForeColor = System.Drawing.Color.Black
        Me.CheckBox26.Location = New System.Drawing.Point(251, 107)
        Me.CheckBox26.Name = "CheckBox26"
        Me.CheckBox26.Size = New System.Drawing.Size(107, 17)
        Me.CheckBox26.TabIndex = 36
        Me.CheckBox26.Text = "Anti-Keyscrambler"
        Me.CheckBox26.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox8.ForeColor = System.Drawing.Color.Black
        Me.CheckBox8.Location = New System.Drawing.Point(251, 59)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(120, 17)
        Me.CheckBox8.TabIndex = 22
        Me.CheckBox8.Text = "Anti-Process Hacker"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'PictureBox20
        '
        Me.PictureBox20.Image = CType(resources.GetObject("PictureBox20.Image"), System.Drawing.Image)
        Me.PictureBox20.Location = New System.Drawing.Point(8, 5)
        Me.PictureBox20.Name = "PictureBox20"
        Me.PictureBox20.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox20.TabIndex = 63
        Me.PictureBox20.TabStop = False
        '
        'PictureBox21
        '
        Me.PictureBox21.Image = CType(resources.GetObject("PictureBox21.Image"), System.Drawing.Image)
        Me.PictureBox21.Location = New System.Drawing.Point(7, 4)
        Me.PictureBox21.Name = "PictureBox21"
        Me.PictureBox21.Size = New System.Drawing.Size(23, 23)
        Me.PictureBox21.TabIndex = 64
        Me.PictureBox21.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.TextBox11)
        Me.Panel1.Location = New System.Drawing.Point(7, 320)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(412, 36)
        Me.Panel1.TabIndex = 67
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(10, 6)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(117, 19)
        Me.Label16.TabIndex = 61
        Me.Label16.Text = " Sleep (1000=1s) "
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.Color.White
        Me.TextBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox11.Enabled = False
        Me.TextBox11.ForeColor = System.Drawing.Color.Black
        Me.TextBox11.Location = New System.Drawing.Point(132, 4)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(245, 25)
        Me.TextBox11.TabIndex = 0
        Me.TextBox11.Text = "1000"
        '
        'VisualStudioGroupBox1
        '
        Me.VisualStudioGroupBox1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(2, Byte), Integer), CType(CType(118, Byte), Integer), CType(CType(196, Byte), Integer))
        Me.VisualStudioGroupBox1.Controls.Add(Me.CheckBox40)
        Me.VisualStudioGroupBox1.Controls.Add(Me.Panel4)
        Me.VisualStudioGroupBox1.Controls.Add(Me.Panel6)
        Me.VisualStudioGroupBox1.Controls.Add(Me.Panel5)
        Me.VisualStudioGroupBox1.Controls.Add(Me.CheckBox38)
        Me.VisualStudioGroupBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.VisualStudioGroupBox1.HeaderColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox1.Location = New System.Drawing.Point(19, 20)
        Me.VisualStudioGroupBox1.MainColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioGroupBox1.Name = "VisualStudioGroupBox1"
        Me.VisualStudioGroupBox1.Size = New System.Drawing.Size(445, 287)
        Me.VisualStudioGroupBox1.TabIndex = 1
        Me.VisualStudioGroupBox1.Text = resources.GetString("VisualStudioGroupBox1.Text")
        Me.VisualStudioGroupBox1.TextColour = System.Drawing.Color.FromArgb(CType(CType(129, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(131, Byte), Integer))
        '
        'CheckBox40
        '
        Me.CheckBox40.AutoSize = True
        Me.CheckBox40.BackColor = System.Drawing.Color.Gainsboro
        Me.CheckBox40.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox40.ForeColor = System.Drawing.Color.Black
        Me.CheckBox40.Location = New System.Drawing.Point(9, 190)
        Me.CheckBox40.Name = "CheckBox40"
        Me.CheckBox40.Size = New System.Drawing.Size(216, 23)
        Me.CheckBox40.TabIndex = 87
        Me.CheckBox40.Text = "If there is a picture on  desktop"
        Me.CheckBox40.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.White
        Me.Panel4.Controls.Add(Me.CheckBox36)
        Me.Panel4.Controls.Add(Me.CheckBox37)
        Me.Panel4.Controls.Add(Me.Label26)
        Me.Panel4.ForeColor = System.Drawing.Color.White
        Me.Panel4.Location = New System.Drawing.Point(3, 32)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(410, 61)
        Me.Panel4.TabIndex = 84
        '
        'CheckBox36
        '
        Me.CheckBox36.AutoSize = True
        Me.CheckBox36.BackColor = System.Drawing.Color.White
        Me.CheckBox36.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox36.ForeColor = System.Drawing.Color.Black
        Me.CheckBox36.Location = New System.Drawing.Point(102, 34)
        Me.CheckBox36.Name = "CheckBox36"
        Me.CheckBox36.Size = New System.Drawing.Size(61, 23)
        Me.CheckBox36.TabIndex = 73
        Me.CheckBox36.Text = "86 Bit"
        Me.CheckBox36.UseVisualStyleBackColor = False
        '
        'CheckBox37
        '
        Me.CheckBox37.AutoSize = True
        Me.CheckBox37.BackColor = System.Drawing.Color.White
        Me.CheckBox37.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox37.ForeColor = System.Drawing.Color.Black
        Me.CheckBox37.Location = New System.Drawing.Point(35, 34)
        Me.CheckBox37.Name = "CheckBox37"
        Me.CheckBox37.Size = New System.Drawing.Size(61, 23)
        Me.CheckBox37.TabIndex = 74
        Me.CheckBox37.Text = "64 Bit"
        Me.CheckBox37.UseVisualStyleBackColor = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label26.Location = New System.Drawing.Point(3, 8)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(174, 19)
        Me.Label26.TabIndex = 75
        Me.Label26.Text = "windows Xp - 7 - 8 - 9 -10"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.White
        Me.Panel6.Controls.Add(Me.TextBox16)
        Me.Panel6.Controls.Add(Me.Label28)
        Me.Panel6.Enabled = False
        Me.Panel6.ForeColor = System.Drawing.Color.Black
        Me.Panel6.Location = New System.Drawing.Point(4, 213)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(409, 56)
        Me.Panel6.TabIndex = 86
        '
        'TextBox16
        '
        Me.TextBox16.BackColor = System.Drawing.Color.White
        Me.TextBox16.ForeColor = System.Drawing.Color.Black
        Me.TextBox16.Location = New System.Drawing.Point(20, 28)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(380, 25)
        Me.TextBox16.TabIndex = 1
        Me.TextBox16.Text = ".png"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.White
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(13, 9)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(34, 19)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "\\\\\"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.White
        Me.Panel5.Controls.Add(Me.TextBox15)
        Me.Panel5.Controls.Add(Me.Label27)
        Me.Panel5.Enabled = False
        Me.Panel5.ForeColor = System.Drawing.Color.White
        Me.Panel5.Location = New System.Drawing.Point(4, 118)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(409, 66)
        Me.Panel5.TabIndex = 85
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.Color.White
        Me.TextBox15.ForeColor = System.Drawing.Color.Black
        Me.TextBox15.Location = New System.Drawing.Point(20, 28)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(380, 25)
        Me.TextBox15.TabIndex = 1
        Me.TextBox15.Text = "YouTube - Google Chrome"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(13, 9)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(34, 19)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "\\\\\"
        '
        'CheckBox38
        '
        Me.CheckBox38.AutoSize = True
        Me.CheckBox38.BackColor = System.Drawing.Color.Gainsboro
        Me.CheckBox38.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox38.ForeColor = System.Drawing.Color.Black
        Me.CheckBox38.Location = New System.Drawing.Point(9, 97)
        Me.CheckBox38.Name = "CheckBox38"
        Me.CheckBox38.Size = New System.Drawing.Size(120, 23)
        Me.CheckBox38.TabIndex = 76
        Me.CheckBox38.Text = "If the site is run"
        Me.CheckBox38.UseVisualStyleBackColor = False
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(524, 387)
        Me.Controls.Add(Me.Panel13)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Create Server"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.pp1.ResumeLayout(False)
        Me.pp2.ResumeLayout(False)
        Me.pp3.ResumeLayout(False)
        Me.rdc.ResumeLayout(False)
        Me.pp5.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.VisualStudioGroupBox5.ResumeLayout(False)
        Me.VisualStudioGroupBox5.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.VisualStudioGroupBox4.ResumeLayout(False)
        Me.VisualStudioGroupBox4.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.VisualStudioGroupBox3.ResumeLayout(False)
        Me.VisualStudioGroupBox3.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.VisualStudioGroupBox2.ResumeLayout(False)
        Me.sc.ResumeLayout(False)
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pp0.ResumeLayout(False)
        Me.pp0.PerformLayout()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox21, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.VisualStudioGroupBox1.ResumeLayout(False)
        Me.VisualStudioGroupBox1.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CheckBox12 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox25 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox27 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox26 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox24 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox23 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox22 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox21 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox20 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox19 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox18 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox17 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox16 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox11 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox9 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox8 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox7 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents hidme As System.Windows.Forms.CheckBox
    Friend WithEvents melt As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents flder As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents tcs As System.Windows.Forms.TextBox
    Friend WithEvents css As System.Windows.Forms.RadioButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents CheckBox31 As CheckBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents CheckBox32 As System.Windows.Forms.CheckBox
    Friend WithEvents pp0 As System.Windows.Forms.Panel
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox19 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox20 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox21 As System.Windows.Forms.PictureBox
    Friend WithEvents CheckBox28 As System.Windows.Forms.CheckBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents tt1 As System.Windows.Forms.Timer
    Friend WithEvents tt2 As System.Windows.Forms.Timer
    Friend WithEvents tt3 As System.Windows.Forms.Timer
    Friend WithEvents tt4 As System.Windows.Forms.Timer
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents qq1 As System.Windows.Forms.LinkLabel
    Friend WithEvents qq2 As System.Windows.Forms.LinkLabel
    Friend WithEvents pp2 As System.Windows.Forms.Panel
    Friend WithEvents qq3 As System.Windows.Forms.LinkLabel
    Friend WithEvents pp3 As System.Windows.Forms.Panel
    Friend WithEvents qq4 As System.Windows.Forms.LinkLabel
    Friend WithEvents pp1 As System.Windows.Forms.Panel
    Friend WithEvents rdc As System.Windows.Forms.Panel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents sc As System.Windows.Forms.Panel
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox29 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox30 As System.Windows.Forms.CheckBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents CheckBox33 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents CheckBox34 As System.Windows.Forms.CheckBox
    Friend WithEvents tt5 As System.Windows.Forms.Timer
    Friend WithEvents qq5 As System.Windows.Forms.LinkLabel
    Friend WithEvents pp5 As System.Windows.Forms.Panel
    Friend WithEvents CheckBox35 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents CheckBox36 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox37 As System.Windows.Forms.CheckBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents CheckBox38 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents CheckBox39 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox40 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents VisualStudioGroupBox2 As comet.VisualStudioGroupBox
    Friend WithEvents VisualStudioGroupBox1 As comet.VisualStudioGroupBox
    Friend WithEvents VisualStudioGroupBox3 As comet.VisualStudioGroupBox
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents VisualStudioGroupBox4 As comet.VisualStudioGroupBox
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents dta As System.Windows.Forms.CheckBox
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents VisualStudioGroupBox5 As comet.VisualStudioGroupBox
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
End Class
