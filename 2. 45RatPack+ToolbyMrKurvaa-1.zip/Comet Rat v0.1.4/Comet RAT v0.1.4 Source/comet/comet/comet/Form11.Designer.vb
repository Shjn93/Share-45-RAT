﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form11
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form11))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BuilderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SeveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RememberTheThumbnailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SeveNameServerInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HideInformationServerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowServerInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.COPSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Q1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Q2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Q3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Q4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOSxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.VisualStudioSeperator1 = New comet.VisualStudioSeperator()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Gainsboro
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TolsToolStripMenuItem, Me.SeveToolStripMenuItem, Me.HelpToolStripMenuItem, Me.HelpToolStripMenuItem1})
        Me.MenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(938, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TolsToolStripMenuItem
        '
        Me.TolsToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.TolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BuilderToolStripMenuItem})
        Me.TolsToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.TolsToolStripMenuItem.Name = "TolsToolStripMenuItem"
        Me.TolsToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.TolsToolStripMenuItem.Text = "Tools"
        '
        'BuilderToolStripMenuItem
        '
        Me.BuilderToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.BuilderToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.BuilderToolStripMenuItem.Image = CType(resources.GetObject("BuilderToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BuilderToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BuilderToolStripMenuItem.Name = "BuilderToolStripMenuItem"
        Me.BuilderToolStripMenuItem.Size = New System.Drawing.Size(121, 32)
        Me.BuilderToolStripMenuItem.Text = "Builder"
        '
        'SeveToolStripMenuItem
        '
        Me.SeveToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.SeveToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RememberTheThumbnailToolStripMenuItem, Me.SeveNameServerInformationToolStripMenuItem})
        Me.SeveToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.SeveToolStripMenuItem.Name = "SeveToolStripMenuItem"
        Me.SeveToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.SeveToolStripMenuItem.Text = "Save"
        '
        'RememberTheThumbnailToolStripMenuItem
        '
        Me.RememberTheThumbnailToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RememberTheThumbnailToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RememberTheThumbnailToolStripMenuItem.Image = CType(resources.GetObject("RememberTheThumbnailToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RememberTheThumbnailToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RememberTheThumbnailToolStripMenuItem.Name = "RememberTheThumbnailToolStripMenuItem"
        Me.RememberTheThumbnailToolStripMenuItem.Size = New System.Drawing.Size(175, 30)
        Me.RememberTheThumbnailToolStripMenuItem.Text = "ScreenShot"
        '
        'SeveNameServerInformationToolStripMenuItem
        '
        Me.SeveNameServerInformationToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.SeveNameServerInformationToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.SeveNameServerInformationToolStripMenuItem.Image = CType(resources.GetObject("SeveNameServerInformationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SeveNameServerInformationToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SeveNameServerInformationToolStripMenuItem.Name = "SeveNameServerInformationToolStripMenuItem"
        Me.SeveNameServerInformationToolStripMenuItem.Size = New System.Drawing.Size(175, 30)
        Me.SeveNameServerInformationToolStripMenuItem.Text = "Save Victim's Info"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem, Me.HideInformationServerToolStripMenuItem, Me.ShowServerInformationToolStripMenuItem, Me.COPSToolStripMenuItem, Me.LOSxToolStripMenuItem})
        Me.HelpToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.HelpToolStripMenuItem.Text = "Additions"
        '
        'StartToolStripMenuItem
        '
        Me.StartToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.StartToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.StartToolStripMenuItem.Image = CType(resources.GetObject("StartToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StartToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StartToolStripMenuItem.Name = "StartToolStripMenuItem"
        Me.StartToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.StartToolStripMenuItem.Text = "Start"
        '
        'HideInformationServerToolStripMenuItem
        '
        Me.HideInformationServerToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.HideInformationServerToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.HideInformationServerToolStripMenuItem.Name = "HideInformationServerToolStripMenuItem"
        Me.HideInformationServerToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.HideInformationServerToolStripMenuItem.Text = "Hide Desktop"
        '
        'ShowServerInformationToolStripMenuItem
        '
        Me.ShowServerInformationToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ShowServerInformationToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ShowServerInformationToolStripMenuItem.Name = "ShowServerInformationToolStripMenuItem"
        Me.ShowServerInformationToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.ShowServerInformationToolStripMenuItem.Text = "Show Desktop"
        '
        'COPSToolStripMenuItem
        '
        Me.COPSToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.COPSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Q1ToolStripMenuItem, Me.Q2ToolStripMenuItem, Me.Q3ToolStripMenuItem, Me.Q4ToolStripMenuItem})
        Me.COPSToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.COPSToolStripMenuItem.Name = "COPSToolStripMenuItem"
        Me.COPSToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.COPSToolStripMenuItem.Text = "View"
        '
        'Q1ToolStripMenuItem
        '
        Me.Q1ToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.Q1ToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.Q1ToolStripMenuItem.Name = "Q1ToolStripMenuItem"
        Me.Q1ToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.Q1ToolStripMenuItem.Text = "Details"
        '
        'Q2ToolStripMenuItem
        '
        Me.Q2ToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.Q2ToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.Q2ToolStripMenuItem.Name = "Q2ToolStripMenuItem"
        Me.Q2ToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.Q2ToolStripMenuItem.Text = "Large"
        '
        'Q3ToolStripMenuItem
        '
        Me.Q3ToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.Q3ToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.Q3ToolStripMenuItem.Name = "Q3ToolStripMenuItem"
        Me.Q3ToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.Q3ToolStripMenuItem.Text = "List"
        '
        'Q4ToolStripMenuItem
        '
        Me.Q4ToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.Q4ToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.Q4ToolStripMenuItem.Name = "Q4ToolStripMenuItem"
        Me.Q4ToolStripMenuItem.Size = New System.Drawing.Size(109, 22)
        Me.Q4ToolStripMenuItem.Text = "Small"
        '
        'LOSxToolStripMenuItem
        '
        Me.LOSxToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.LOSxToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SToolStripMenuItem, Me.DToolStripMenuItem})
        Me.LOSxToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.LOSxToolStripMenuItem.Name = "LOSxToolStripMenuItem"
        Me.LOSxToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.LOSxToolStripMenuItem.Text = "Display"
        '
        'SToolStripMenuItem
        '
        Me.SToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.SToolStripMenuItem.Name = "SToolStripMenuItem"
        Me.SToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.SToolStripMenuItem.Text = "Display Screen"
        '
        'DToolStripMenuItem
        '
        Me.DToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.DToolStripMenuItem.Name = "DToolStripMenuItem"
        Me.DToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.DToolStripMenuItem.Text = "Classic"
        '
        'HelpToolStripMenuItem1
        '
        Me.HelpToolStripMenuItem1.BackColor = System.Drawing.Color.Gainsboro
        Me.HelpToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.HelpToolStripMenuItem1.Name = "HelpToolStripMenuItem1"
        Me.HelpToolStripMenuItem1.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem1.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.AboutToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.AboutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.VisualStudioSeperator1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.ForeColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(0, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(938, 45)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel2.Controls.Add(Me.Button23)
        Me.Panel2.Controls.Add(Me.Button22)
        Me.Panel2.Controls.Add(Me.Button21)
        Me.Panel2.Controls.Add(Me.Button20)
        Me.Panel2.Controls.Add(Me.Button19)
        Me.Panel2.Controls.Add(Me.Button18)
        Me.Panel2.Controls.Add(Me.Button17)
        Me.Panel2.Controls.Add(Me.Button16)
        Me.Panel2.Controls.Add(Me.Button15)
        Me.Panel2.Controls.Add(Me.Button14)
        Me.Panel2.Controls.Add(Me.Button13)
        Me.Panel2.Controls.Add(Me.Button12)
        Me.Panel2.Controls.Add(Me.Button6)
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.Button11)
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Controls.Add(Me.Button7)
        Me.Panel2.Controls.Add(Me.Button4)
        Me.Panel2.Controls.Add(Me.Button10)
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.Button8)
        Me.Panel2.Controls.Add(Me.Button9)
        Me.Panel2.ForeColor = System.Drawing.Color.Black
        Me.Panel2.Location = New System.Drawing.Point(11, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(920, 32)
        Me.Panel2.TabIndex = 12
        '
        'Button23
        '
        Me.Button23.BackColor = System.Drawing.Color.Gainsboro
        Me.Button23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button23.Image = CType(resources.GetObject("Button23.Image"), System.Drawing.Image)
        Me.Button23.Location = New System.Drawing.Point(861, 0)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(33, 32)
        Me.Button23.TabIndex = 23
        Me.ToolTip1.SetToolTip(Me.Button23, "Service Manager")
        Me.Button23.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.Gainsboro
        Me.Button22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button22.Image = CType(resources.GetObject("Button22.Image"), System.Drawing.Image)
        Me.Button22.Location = New System.Drawing.Point(822, 0)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(33, 32)
        Me.Button22.TabIndex = 22
        Me.ToolTip1.SetToolTip(Me.Button22, "Get Passwords")
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.Color.Gainsboro
        Me.Button21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button21.Image = CType(resources.GetObject("Button21.Image"), System.Drawing.Image)
        Me.Button21.Location = New System.Drawing.Point(783, 0)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(33, 32)
        Me.Button21.TabIndex = 21
        Me.ToolTip1.SetToolTip(Me.Button21, "Open WebSite")
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.Gainsboro
        Me.Button20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button20.Image = CType(resources.GetObject("Button20.Image"), System.Drawing.Image)
        Me.Button20.Location = New System.Drawing.Point(744, 0)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(33, 32)
        Me.Button20.TabIndex = 20
        Me.ToolTip1.SetToolTip(Me.Button20, "Execution of an order")
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.Color.Gainsboro
        Me.Button19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button19.Image = CType(resources.GetObject("Button19.Image"), System.Drawing.Image)
        Me.Button19.Location = New System.Drawing.Point(705, 0)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(33, 32)
        Me.Button19.TabIndex = 19
        Me.ToolTip1.SetToolTip(Me.Button19, "scan ports")
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.Color.Gainsboro
        Me.Button18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button18.Image = CType(resources.GetObject("Button18.Image"), System.Drawing.Image)
        Me.Button18.Location = New System.Drawing.Point(666, 0)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(33, 32)
        Me.Button18.TabIndex = 18
        Me.ToolTip1.SetToolTip(Me.Button18, "Operation and killed")
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.Gainsboro
        Me.Button17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button17.Image = CType(resources.GetObject("Button17.Image"), System.Drawing.Image)
        Me.Button17.Location = New System.Drawing.Point(627, 0)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(33, 32)
        Me.Button17.TabIndex = 17
        Me.ToolTip1.SetToolTip(Me.Button17, "desktop background")
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.Gainsboro
        Me.Button16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button16.Image = CType(resources.GetObject("Button16.Image"), System.Drawing.Image)
        Me.Button16.Location = New System.Drawing.Point(588, 0)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(33, 32)
        Me.Button16.TabIndex = 16
        Me.ToolTip1.SetToolTip(Me.Button16, "Msg")
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.Gainsboro
        Me.Button15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button15.Image = CType(resources.GetObject("Button15.Image"), System.Drawing.Image)
        Me.Button15.Location = New System.Drawing.Point(549, 0)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(33, 32)
        Me.Button15.TabIndex = 15
        Me.ToolTip1.SetToolTip(Me.Button15, "Run Scripts")
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.Gainsboro
        Me.Button14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button14.Image = CType(resources.GetObject("Button14.Image"), System.Drawing.Image)
        Me.Button14.Location = New System.Drawing.Point(510, 0)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(33, 32)
        Me.Button14.TabIndex = 14
        Me.ToolTip1.SetToolTip(Me.Button14, "Run From Link")
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.Gainsboro
        Me.Button13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button13.Image = CType(resources.GetObject("Button13.Image"), System.Drawing.Image)
        Me.Button13.Location = New System.Drawing.Point(471, 0)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(33, 32)
        Me.Button13.TabIndex = 13
        Me.ToolTip1.SetToolTip(Me.Button13, "Run From Disk")
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.Gainsboro
        Me.Button12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button12.Image = CType(resources.GetObject("Button12.Image"), System.Drawing.Image)
        Me.Button12.Location = New System.Drawing.Point(432, 0)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(33, 32)
        Me.Button12.TabIndex = 12
        Me.ToolTip1.SetToolTip(Me.Button12, "System Information")
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Gainsboro
        Me.Button6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.Location = New System.Drawing.Point(198, 0)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(33, 32)
        Me.Button6.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.Button6, "Remote Shell")
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Gainsboro
        Me.Button5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.Location = New System.Drawing.Point(159, 0)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(33, 32)
        Me.Button5.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.Button5, "KeyLogger")
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Gainsboro
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(42, 0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(33, 32)
        Me.Button2.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.Button2, "File Manager")
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.Gainsboro
        Me.Button11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.Location = New System.Drawing.Point(393, 0)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(33, 32)
        Me.Button11.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.Button11, "Ddos Attack")
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Gainsboro
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(3, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(33, 32)
        Me.Button1.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.Button1, "Remote Desktop")
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Gainsboro
        Me.Button7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button7.Image = CType(resources.GetObject("Button7.Image"), System.Drawing.Image)
        Me.Button7.Location = New System.Drawing.Point(237, 0)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(33, 32)
        Me.Button7.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.Button7, "Remote Regedit")
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Gainsboro
        Me.Button4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.Location = New System.Drawing.Point(120, 0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(33, 32)
        Me.Button4.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.Button4, "Microphone")
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.Gainsboro
        Me.Button10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button10.Image = CType(resources.GetObject("Button10.Image"), System.Drawing.Image)
        Me.Button10.Location = New System.Drawing.Point(354, 0)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(33, 32)
        Me.Button10.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.Button10, "Chat")
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Gainsboro
        Me.Button3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(81, 0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(33, 32)
        Me.Button3.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.Button3, " Process Manager")
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.Gainsboro
        Me.Button8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.Location = New System.Drawing.Point(276, 0)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(33, 32)
        Me.Button8.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.Button8, "Installed Programs")
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.Gainsboro
        Me.Button9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.Button9.Image = CType(resources.GetObject("Button9.Image"), System.Drawing.Image)
        Me.Button9.Location = New System.Drawing.Point(315, 0)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(33, 32)
        Me.Button9.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.Button9, "Scheduled Tasks")
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "34rewgfq3wased.png")
        '
        'VisualStudioSeperator1
        '
        Me.VisualStudioSeperator1.AddEndNotch = False
        Me.VisualStudioSeperator1.BackColor = System.Drawing.Color.Transparent
        Me.VisualStudioSeperator1.FontColour = System.Drawing.Color.Black
        Me.VisualStudioSeperator1.ForeColor = System.Drawing.Color.Black
        Me.VisualStudioSeperator1.LineColour = System.Drawing.Color.Black
        Me.VisualStudioSeperator1.Location = New System.Drawing.Point(216, -3)
        Me.VisualStudioSeperator1.Name = "VisualStudioSeperator1"
        Me.VisualStudioSeperator1.OnlyUnderlineText = False
        Me.VisualStudioSeperator1.ShowText = False
        Me.VisualStudioSeperator1.ShowTextAboveLine = False
        Me.VisualStudioSeperator1.Size = New System.Drawing.Size(212, 10)
        Me.VisualStudioSeperator1.TabIndex = 4
        Me.VisualStudioSeperator1.Text = "VisualStudioSeperator1"
        Me.VisualStudioSeperator1.TextAlignment = System.Drawing.StringAlignment.Center
        Me.VisualStudioSeperator1.TextLocation = comet.VisualStudioSeperator.__TextLocation.Left
        Me.VisualStudioSeperator1.UnderlineText = False
        '
        'Form11
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(239, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(938, 418)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.Color.White
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form11"
        Me.Text = "Form11"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents TolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BuilderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents VisualStudioSeperator1 As comet.VisualStudioSeperator
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents SeveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RememberTheThumbnailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SeveNameServerInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents HideInformationServerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShowServerInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents COPSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Q1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Q2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Q3ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Q4ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LOSxToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
