﻿Public Class Form21

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Form3.Label23.Text = 1
        Form3.PictureBox1.Image = PictureBox1.Image
        Me.Close()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Form3.Label23.Text = 2
        Form3.PictureBox1.Image = PictureBox2.Image
        Me.Close()
    End Sub

    Private Sub Form21_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error Resume Next
        Form3.Label23.Text = 0
        Form3.Timer1.Enabled = True
        PictureBox1.ImageLocation = "IOS\ico\1.ico"
        PictureBox2.ImageLocation = "IOS\ico\2.ico"
        PictureBox3.ImageLocation = "IOS\ico\3.ico"
        PictureBox4.ImageLocation = "IOS\ico\4.ico"
        PictureBox5.ImageLocation = "IOS\ico\5.ico"
        PictureBox6.ImageLocation = "IOS\ico\6.ico"
        PictureBox7.ImageLocation = "IOS\ico\7.ico"
        PictureBox8.ImageLocation = "IOS\ico\8.ico"
        PictureBox9.ImageLocation = "IOS\ico\9.ico"
        PictureBox10.ImageLocation = "IOS\ico\10.ico"
        PictureBox11.ImageLocation = "IOS\ico\11.ico"
        PictureBox12.ImageLocation = "IOS\ico\12.ico"
        PictureBox13.ImageLocation = "IOS\ico\13.ico"
        PictureBox14.ImageLocation = "IOS\ico\14.ico"
        PictureBox15.ImageLocation = "IOS\ico\15.ico"
        PictureBox16.ImageLocation = "IOS\ico\16.ico"
        PictureBox17.ImageLocation = "IOS\ico\17.ico"
        PictureBox18.ImageLocation = "IOS\ico\18.ico"
        'PictureBox19.ImageLocation = "IOS\ico\19.ico"
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Form3.Label23.Text = 3
        Form3.PictureBox1.Image = PictureBox3.Image
        Me.Close()
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        Form3.Label23.Text = 4
        Form3.PictureBox1.Image = PictureBox4.Image
        Me.Close()
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        Form3.Label23.Text = 5
        Form3.PictureBox1.Image = PictureBox5.Image
        Me.Close()
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click
        Form3.Label23.Text = 6
        Form3.PictureBox1.Image = PictureBox6.Image
        Me.Close()
    End Sub



    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        Form3.Label23.Text = 7
        Form3.PictureBox1.Image = PictureBox7.Image
        Me.Close()
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles PictureBox8.Click
        Form3.Label23.Text = 8
        Form3.PictureBox1.Image = PictureBox8.Image
        Me.Close()
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Form3.Label23.Text = 9
        Form3.PictureBox1.Image = PictureBox9.Image
        Me.Close()
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Form3.Label23.Text = 10
        Form3.PictureBox1.Image = PictureBox10.Image
        Me.Close()
    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles PictureBox11.Click
        Form3.Label23.Text = 11
        Form3.PictureBox1.Image = PictureBox11.Image
        Me.Close()
    End Sub

    Private Sub PictureBox12_Click(sender As Object, e As EventArgs) Handles PictureBox12.Click
        Form3.Label23.Text = 12
        Form3.PictureBox1.Image = PictureBox12.Image
        Me.Close()
    End Sub

    Private Sub PictureBox13_Click(sender As Object, e As EventArgs) Handles PictureBox13.Click
        Form3.Label23.Text = 13
        Form3.PictureBox1.Image = PictureBox13.Image
        Me.Close()
    End Sub

    Private Sub PictureBox14_Click(sender As Object, e As EventArgs) Handles PictureBox14.Click
        Form3.Label23.Text = 14
        Form3.PictureBox1.Image = PictureBox14.Image
        Me.Close()
    End Sub

    Private Sub PictureBox15_Click(sender As Object, e As EventArgs) Handles PictureBox15.Click
        Form3.Label23.Text = 15
        Form3.PictureBox1.Image = PictureBox15.Image
        Me.Close()
    End Sub

    Private Sub PictureBox16_Click(sender As Object, e As EventArgs) Handles PictureBox16.Click
        Form3.Label23.Text = 16
        Form3.PictureBox1.Image = PictureBox16.Image
        Me.Close()
    End Sub

    Private Sub PictureBox17_Click(sender As Object, e As EventArgs) Handles PictureBox17.Click
        Form3.Label23.Text = 17
        Form3.PictureBox1.Image = PictureBox17.Image
        Me.Close()
    End Sub

    Private Sub PictureBox18_Click(sender As Object, e As EventArgs) Handles PictureBox18.Click
        Form3.Label23.Text = 18
        Form3.PictureBox1.Image = PictureBox17.Image
        Me.Close()
    End Sub
End Class