﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            'On Error Resume Next
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally

            MyBase.Dispose(disposing)

        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("<  >")
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EncryptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Q1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Q2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServerCopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyHideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyNormilToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaSteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DestructionBoomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetAsWallpaperToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PressureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FLOCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExecuteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdminRunToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunTheFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PlayMusicHidenToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DownloadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewTextFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TxtToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ElseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ElseTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewEditTextToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CharacteristicsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.ListView1 = New comet.GClass9()
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.ListView2 = New comet.GClass9()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.ListView3 = New System.Windows.Forms.ListView()
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pic1 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.DisplayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.DimGray
        Me.TextBox1.Location = New System.Drawing.Point(155, 7)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(279, 21)
        Me.TextBox1.TabIndex = 45
        Me.TextBox1.TabStop = False
        Me.TextBox1.WordWrap = False
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "0.png")
        Me.ImageList1.Images.SetKeyName(1, "1.png")
        Me.ImageList1.Images.SetKeyName(2, "2.png")
        Me.ImageList1.Images.SetKeyName(3, "3.png")
        Me.ImageList1.Images.SetKeyName(4, "4.png")
        Me.ImageList1.Images.SetKeyName(5, "5.png")
        Me.ImageList1.Images.SetKeyName(6, "6.png")
        Me.ImageList1.Images.SetKeyName(7, "7.png")
        Me.ImageList1.Images.SetKeyName(8, "8.png")
        Me.ImageList1.Images.SetKeyName(9, "9.png")
        Me.ImageList1.Images.SetKeyName(10, "10.png")
        Me.ImageList1.Images.SetKeyName(11, "11.png")
        Me.ImageList1.Images.SetKeyName(12, "12.png")
        Me.ImageList1.Images.SetKeyName(13, "13.png")
        Me.ImageList1.Images.SetKeyName(14, "14.png")
        Me.ImageList1.Images.SetKeyName(15, "15.png")
        Me.ImageList1.Images.SetKeyName(16, "16.png")
        Me.ImageList1.Images.SetKeyName(17, "17.png")
        Me.ImageList1.Images.SetKeyName(18, "18.png")
        Me.ImageList1.Images.SetKeyName(19, "19.png")
        Me.ImageList1.Images.SetKeyName(20, "20.png")
        Me.ImageList1.Images.SetKeyName(21, "21.png")
        Me.ImageList1.Images.SetKeyName(22, "22.png")
        Me.ImageList1.Images.SetKeyName(23, "23.png")
        Me.ImageList1.Images.SetKeyName(24, "24.png")
        Me.ImageList1.Images.SetKeyName(25, "25.png")
        Me.ImageList1.Images.SetKeyName(26, "26.png")
        Me.ImageList1.Images.SetKeyName(27, "27.png")
        Me.ImageList1.Images.SetKeyName(28, "28.gif")
        Me.ImageList1.Images.SetKeyName(29, "28.png")
        Me.ImageList1.Images.SetKeyName(30, "29.png")
        Me.ImageList1.Images.SetKeyName(31, "30.png")
        Me.ImageList1.Images.SetKeyName(32, "31.png")
        Me.ImageList1.Images.SetKeyName(33, "32.png")
        Me.ImageList1.Images.SetKeyName(34, "33.png")
        Me.ImageList1.Images.SetKeyName(35, "34.png")
        Me.ImageList1.Images.SetKeyName(36, "35.png")
        Me.ImageList1.Images.SetKeyName(37, "36.png")
        Me.ImageList1.Images.SetKeyName(38, "37.png")
        Me.ImageList1.Images.SetKeyName(39, "38.png")
        Me.ImageList1.Images.SetKeyName(40, "39.png")
        Me.ImageList1.Images.SetKeyName(41, "40.png")
        Me.ImageList1.Images.SetKeyName(42, "41.png")
        Me.ImageList1.Images.SetKeyName(43, "42.png")
        Me.ImageList1.Images.SetKeyName(44, "43.png")
        Me.ImageList1.Images.SetKeyName(45, "44.png")
        Me.ImageList1.Images.SetKeyName(46, "45.png")
        Me.ImageList1.Images.SetKeyName(47, "46.png")
        Me.ImageList1.Images.SetKeyName(48, "47.png")
        Me.ImageList1.Images.SetKeyName(49, "48.png")
        Me.ImageList1.Images.SetKeyName(50, "49.png")
        Me.ImageList1.Images.SetKeyName(51, "50.png")
        Me.ImageList1.Images.SetKeyName(52, "51.png")
        Me.ImageList1.Images.SetKeyName(53, "52.png")
        Me.ImageList1.Images.SetKeyName(54, "53.png")
        Me.ImageList1.Images.SetKeyName(55, "54.png")
        Me.ImageList1.Images.SetKeyName(56, "55.png")
        Me.ImageList1.Images.SetKeyName(57, "56.png")
        Me.ImageList1.Images.SetKeyName(58, "57.png")
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.BackToolStripMenuItem1, Me.RefreshToolStripMenuItem, Me.EncryptToolStripMenuItem, Me.ServerCopyToolStripMenuItem, Me.DeleteToolStripMenuItem, Me.ExecuteToolStripMenuItem, Me.DownloadToolStripMenuItem, Me.UploadToolStripMenuItem, Me.NewTextFileToolStripMenuItem, Me.ViewEditTextToolStripMenuItem, Me.OpenFolderToolStripMenuItem, Me.CharacteristicsToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(207, 420)
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripMenuItem2.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem2.Image = CType(resources.GetObject("ToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(206, 32)
        Me.ToolStripMenuItem2.Text = "Open"
        '
        'BackToolStripMenuItem1
        '
        Me.BackToolStripMenuItem1.BackColor = System.Drawing.Color.Gainsboro
        Me.BackToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.BackToolStripMenuItem1.Image = CType(resources.GetObject("BackToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.BackToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BackToolStripMenuItem1.Name = "BackToolStripMenuItem1"
        Me.BackToolStripMenuItem1.Size = New System.Drawing.Size(206, 32)
        Me.BackToolStripMenuItem1.Text = "Back"
        '
        'RefreshToolStripMenuItem
        '
        Me.RefreshToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RefreshToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RefreshToolStripMenuItem.Image = CType(resources.GetObject("RefreshToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RefreshToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem"
        Me.RefreshToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.RefreshToolStripMenuItem.Text = "Refresh"
        '
        'EncryptToolStripMenuItem
        '
        Me.EncryptToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.EncryptToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Q1ToolStripMenuItem, Me.Q2ToolStripMenuItem})
        Me.EncryptToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.EncryptToolStripMenuItem.Image = CType(resources.GetObject("EncryptToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EncryptToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.EncryptToolStripMenuItem.Name = "EncryptToolStripMenuItem"
        Me.EncryptToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.EncryptToolStripMenuItem.Text = "Encrypt"
        '
        'Q1ToolStripMenuItem
        '
        Me.Q1ToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.Q1ToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.Q1ToolStripMenuItem.Image = CType(resources.GetObject("Q1ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.Q1ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Q1ToolStripMenuItem.Name = "Q1ToolStripMenuItem"
        Me.Q1ToolStripMenuItem.Size = New System.Drawing.Size(123, 30)
        Me.Q1ToolStripMenuItem.Text = "Encrypt"
        '
        'Q2ToolStripMenuItem
        '
        Me.Q2ToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.Q2ToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.Q2ToolStripMenuItem.Image = CType(resources.GetObject("Q2ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.Q2ToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Q2ToolStripMenuItem.Name = "Q2ToolStripMenuItem"
        Me.Q2ToolStripMenuItem.Size = New System.Drawing.Size(123, 30)
        Me.Q2ToolStripMenuItem.Text = "Decrypt"
        '
        'ServerCopyToolStripMenuItem
        '
        Me.ServerCopyToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ServerCopyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyHideToolStripMenuItem, Me.CopyNormilToolStripMenuItem})
        Me.ServerCopyToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ServerCopyToolStripMenuItem.Image = CType(resources.GetObject("ServerCopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ServerCopyToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ServerCopyToolStripMenuItem.Name = "ServerCopyToolStripMenuItem"
        Me.ServerCopyToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.ServerCopyToolStripMenuItem.Text = " Server Tools"
        '
        'CopyHideToolStripMenuItem
        '
        Me.CopyHideToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.CopyHideToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CopyHideToolStripMenuItem.Image = CType(resources.GetObject("CopyHideToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyHideToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CopyHideToolStripMenuItem.Name = "CopyHideToolStripMenuItem"
        Me.CopyHideToolStripMenuItem.Size = New System.Drawing.Size(188, 30)
        Me.CopyHideToolStripMenuItem.Text = "Server Copy Hide"
        '
        'CopyNormilToolStripMenuItem
        '
        Me.CopyNormilToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.CopyNormilToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CopyNormilToolStripMenuItem.Image = CType(resources.GetObject("CopyNormilToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyNormilToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CopyNormilToolStripMenuItem.Name = "CopyNormilToolStripMenuItem"
        Me.CopyNormilToolStripMenuItem.Size = New System.Drawing.Size(188, 30)
        Me.CopyNormilToolStripMenuItem.Text = "Server Copy Normal"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.DeleteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyToolStripMenuItem, Me.ToolStripMenuItem1, Me.PaSteToolStripMenuItem, Me.DeleteToolStripMenuItem1, Me.ToolStripMenuItem6, Me.ToolStripMenuItem7, Me.ToolStripMenuItem8, Me.DestructionBoomToolStripMenuItem, Me.SetAsWallpaperToolStripMenuItem1, Me.PressureToolStripMenuItem, Me.FLOCToolStripMenuItem})
        Me.DeleteToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.DeleteToolStripMenuItem.Image = CType(resources.GetObject("DeleteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.DeleteToolStripMenuItem.Text = "Edit Files"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.CopyToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CopyToolStripMenuItem.Image = CType(resources.GetObject("CopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(201, 32)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem1.Image = CType(resources.GetObject("ToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(201, 32)
        Me.ToolStripMenuItem1.Text = "Cut"
        '
        'PaSteToolStripMenuItem
        '
        Me.PaSteToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.PaSteToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.PaSteToolStripMenuItem.Image = CType(resources.GetObject("PaSteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PaSteToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PaSteToolStripMenuItem.Name = "PaSteToolStripMenuItem"
        Me.PaSteToolStripMenuItem.Size = New System.Drawing.Size(201, 32)
        Me.PaSteToolStripMenuItem.Text = "Paste"
        '
        'DeleteToolStripMenuItem1
        '
        Me.DeleteToolStripMenuItem1.BackColor = System.Drawing.Color.Gainsboro
        Me.DeleteToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.DeleteToolStripMenuItem1.Image = CType(resources.GetObject("DeleteToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.DeleteToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DeleteToolStripMenuItem1.Name = "DeleteToolStripMenuItem1"
        Me.DeleteToolStripMenuItem1.Size = New System.Drawing.Size(201, 32)
        Me.DeleteToolStripMenuItem1.Text = "Delete"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripMenuItem6.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem6.Image = CType(resources.GetObject("ToolStripMenuItem6.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(201, 32)
        Me.ToolStripMenuItem6.Text = "Rename File"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripMenuItem7.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem7.Image = CType(resources.GetObject("ToolStripMenuItem7.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(201, 32)
        Me.ToolStripMenuItem7.Text = "Hide Folder/File"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripMenuItem8.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem8.Image = CType(resources.GetObject("ToolStripMenuItem8.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem8.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(201, 32)
        Me.ToolStripMenuItem8.Text = "Show Folder/File"
        '
        'DestructionBoomToolStripMenuItem
        '
        Me.DestructionBoomToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.DestructionBoomToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.DestructionBoomToolStripMenuItem.Image = CType(resources.GetObject("DestructionBoomToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DestructionBoomToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DestructionBoomToolStripMenuItem.Name = "DestructionBoomToolStripMenuItem"
        Me.DestructionBoomToolStripMenuItem.Size = New System.Drawing.Size(201, 32)
        Me.DestructionBoomToolStripMenuItem.Text = "Ruin File"
        '
        'SetAsWallpaperToolStripMenuItem1
        '
        Me.SetAsWallpaperToolStripMenuItem1.BackColor = System.Drawing.Color.Gainsboro
        Me.SetAsWallpaperToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.SetAsWallpaperToolStripMenuItem1.Image = CType(resources.GetObject("SetAsWallpaperToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.SetAsWallpaperToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SetAsWallpaperToolStripMenuItem1.Name = "SetAsWallpaperToolStripMenuItem1"
        Me.SetAsWallpaperToolStripMenuItem1.Size = New System.Drawing.Size(201, 32)
        Me.SetAsWallpaperToolStripMenuItem1.Text = "Desktop background"
        '
        'PressureToolStripMenuItem
        '
        Me.PressureToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.PressureToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.PressureToolStripMenuItem.Image = CType(resources.GetObject("PressureToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PressureToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PressureToolStripMenuItem.Name = "PressureToolStripMenuItem"
        Me.PressureToolStripMenuItem.Size = New System.Drawing.Size(201, 32)
        Me.PressureToolStripMenuItem.Text = "Winrar Compress"
        '
        'FLOCToolStripMenuItem
        '
        Me.FLOCToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.FLOCToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.FLOCToolStripMenuItem.Image = CType(resources.GetObject("FLOCToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FLOCToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FLOCToolStripMenuItem.Name = "FLOCToolStripMenuItem"
        Me.FLOCToolStripMenuItem.Size = New System.Drawing.Size(201, 32)
        Me.FLOCToolStripMenuItem.Text = "Empty the Recycle Bin"
        '
        'ExecuteToolStripMenuItem
        '
        Me.ExecuteToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ExecuteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AdminRunToolStripMenuItem, Me.RunTheFileToolStripMenuItem, Me.PlayMusicHidenToolStripMenuItem1})
        Me.ExecuteToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ExecuteToolStripMenuItem.Image = CType(resources.GetObject("ExecuteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExecuteToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ExecuteToolStripMenuItem.Name = "ExecuteToolStripMenuItem"
        Me.ExecuteToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.ExecuteToolStripMenuItem.Text = "Run"
        '
        'AdminRunToolStripMenuItem
        '
        Me.AdminRunToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.AdminRunToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.AdminRunToolStripMenuItem.Image = CType(resources.GetObject("AdminRunToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AdminRunToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AdminRunToolStripMenuItem.Name = "AdminRunToolStripMenuItem"
        Me.AdminRunToolStripMenuItem.Size = New System.Drawing.Size(246, 30)
        Me.AdminRunToolStripMenuItem.Text = "Run the file as an administrator"
        '
        'RunTheFileToolStripMenuItem
        '
        Me.RunTheFileToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.RunTheFileToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RunTheFileToolStripMenuItem.Image = CType(resources.GetObject("RunTheFileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RunTheFileToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RunTheFileToolStripMenuItem.Name = "RunTheFileToolStripMenuItem"
        Me.RunTheFileToolStripMenuItem.Size = New System.Drawing.Size(246, 30)
        Me.RunTheFileToolStripMenuItem.Text = "Run the file"
        '
        'PlayMusicHidenToolStripMenuItem1
        '
        Me.PlayMusicHidenToolStripMenuItem1.BackColor = System.Drawing.Color.Gainsboro
        Me.PlayMusicHidenToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.PlayMusicHidenToolStripMenuItem1.Image = CType(resources.GetObject("PlayMusicHidenToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.PlayMusicHidenToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PlayMusicHidenToolStripMenuItem1.Name = "PlayMusicHidenToolStripMenuItem1"
        Me.PlayMusicHidenToolStripMenuItem1.Size = New System.Drawing.Size(246, 30)
        Me.PlayMusicHidenToolStripMenuItem1.Text = "Play Music Hiden"
        '
        'DownloadToolStripMenuItem
        '
        Me.DownloadToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.DownloadToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.DownloadToolStripMenuItem.Image = CType(resources.GetObject("DownloadToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DownloadToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DownloadToolStripMenuItem.Name = "DownloadToolStripMenuItem"
        Me.DownloadToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.DownloadToolStripMenuItem.Text = "Download"
        '
        'UploadToolStripMenuItem
        '
        Me.UploadToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.UploadToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.UploadToolStripMenuItem.Image = CType(resources.GetObject("UploadToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UploadToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UploadToolStripMenuItem.Name = "UploadToolStripMenuItem"
        Me.UploadToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.UploadToolStripMenuItem.Text = "Upload"
        '
        'NewTextFileToolStripMenuItem
        '
        Me.NewTextFileToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.NewTextFileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem3, Me.ToolStripMenuItem4, Me.ToolStripMenuItem5, Me.TxtToolStripMenuItem, Me.ElseToolStripMenuItem, Me.ElseTToolStripMenuItem})
        Me.NewTextFileToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.NewTextFileToolStripMenuItem.Image = CType(resources.GetObject("NewTextFileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NewTextFileToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.NewTextFileToolStripMenuItem.Name = "NewTextFileToolStripMenuItem"
        Me.NewTextFileToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.NewTextFileToolStripMenuItem.Text = "New Files"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripMenuItem3.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem3.Image = CType(resources.GetObject("ToolStripMenuItem3.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(142, 30)
        Me.ToolStripMenuItem3.Text = "New Folder"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripMenuItem4.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(142, 30)
        Me.ToolStripMenuItem4.Text = "New Rtf"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripMenuItem5.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(142, 30)
        Me.ToolStripMenuItem5.Text = "New log"
        '
        'TxtToolStripMenuItem
        '
        Me.TxtToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.TxtToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.TxtToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.TxtToolStripMenuItem.Name = "TxtToolStripMenuItem"
        Me.TxtToolStripMenuItem.Size = New System.Drawing.Size(142, 30)
        Me.TxtToolStripMenuItem.Text = "New vbs"
        '
        'ElseToolStripMenuItem
        '
        Me.ElseToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ElseToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ElseToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ElseToolStripMenuItem.Name = "ElseToolStripMenuItem"
        Me.ElseToolStripMenuItem.Size = New System.Drawing.Size(142, 30)
        Me.ElseToolStripMenuItem.Text = "New txt"
        '
        'ElseTToolStripMenuItem
        '
        Me.ElseTToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ElseTToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ElseTToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ElseTToolStripMenuItem.Name = "ElseTToolStripMenuItem"
        Me.ElseTToolStripMenuItem.Size = New System.Drawing.Size(142, 30)
        Me.ElseTToolStripMenuItem.Text = "(Else)"
        '
        'ViewEditTextToolStripMenuItem
        '
        Me.ViewEditTextToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.ViewEditTextToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ViewEditTextToolStripMenuItem.Image = CType(resources.GetObject("ViewEditTextToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewEditTextToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ViewEditTextToolStripMenuItem.Name = "ViewEditTextToolStripMenuItem"
        Me.ViewEditTextToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.ViewEditTextToolStripMenuItem.Text = "View/Edit Text"
        '
        'OpenFolderToolStripMenuItem
        '
        Me.OpenFolderToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.OpenFolderToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.OpenFolderToolStripMenuItem.Image = CType(resources.GetObject("OpenFolderToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenFolderToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.OpenFolderToolStripMenuItem.Name = "OpenFolderToolStripMenuItem"
        Me.OpenFolderToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.OpenFolderToolStripMenuItem.Text = "Open Download Folder"
        '
        'CharacteristicsToolStripMenuItem
        '
        Me.CharacteristicsToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro
        Me.CharacteristicsToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CharacteristicsToolStripMenuItem.Image = CType(resources.GetObject("CharacteristicsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CharacteristicsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CharacteristicsToolStripMenuItem.Name = "CharacteristicsToolStripMenuItem"
        Me.CharacteristicsToolStripMenuItem.Size = New System.Drawing.Size(206, 32)
        Me.CharacteristicsToolStripMenuItem.Text = "Properties"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 500
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.ListView1)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.ListView2)
        Me.SplitContainer1.Size = New System.Drawing.Size(531, 396)
        Me.SplitContainer1.SplitterDistance = 265
        Me.SplitContainer1.TabIndex = 48
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.Color.White
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5, Me.ColumnHeader6})
        Me.ListView1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.ListView1.ForeColor = System.Drawing.Color.Black
        Me.ListView1.FullRowSelect = True
        Me.ListView1.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1})
        Me.ListView1.LargeImageList = Me.ImageList1
        Me.ListView1.Location = New System.Drawing.Point(0, 36)
        Me.ListView1.MultiSelect = False
        Me.ListView1.Name = "ListView1"
        Me.ListView1.OwnerDraw = True
        Me.ListView1.Size = New System.Drawing.Size(531, 229)
        Me.ListView1.SmallImageList = Me.ImageList1
        Me.ListView1.TabIndex = 47
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Tile
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "File Name"
        Me.ColumnHeader5.Width = 83
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "File Size"
        Me.ColumnHeader6.Width = 444
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.TextBox2)
        Me.Panel1.Controls.Add(Me.TextBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.ForeColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(531, 36)
        Me.Panel1.TabIndex = 46
        '
        'Button7
        '
        Me.Button7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button7.BackColor = System.Drawing.Color.Gainsboro
        Me.Button7.Enabled = False
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button7.Image = CType(resources.GetObject("Button7.Image"), System.Drawing.Image)
        Me.Button7.Location = New System.Drawing.Point(440, 1)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(34, 34)
        Me.Button7.TabIndex = 48
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button6.BackColor = System.Drawing.Color.Gainsboro
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.Location = New System.Drawing.Point(496, 1)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(34, 34)
        Me.Button6.TabIndex = 47
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button8.BackColor = System.Drawing.Color.Gainsboro
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.Location = New System.Drawing.Point(467, 1)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(34, 34)
        Me.Button8.TabIndex = 50
        Me.Button8.UseVisualStyleBackColor = False
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.BackColor = System.Drawing.Color.White
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.Color.Silver
        Me.TextBox2.Location = New System.Drawing.Point(6, 7)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(151, 21)
        Me.TextBox2.TabIndex = 49
        Me.TextBox2.TabStop = False
        Me.TextBox2.Text = "Find"
        Me.TextBox2.WordWrap = False
        '
        'ListView2
        '
        Me.ListView2.BackColor = System.Drawing.Color.Gainsboro
        Me.ListView2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.ListView2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.ListView2.ForeColor = System.Drawing.Color.Black
        Me.ListView2.FullRowSelect = True
        Me.ListView2.Location = New System.Drawing.Point(0, 0)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.OwnerDraw = True
        Me.ListView2.Size = New System.Drawing.Size(531, 127)
        Me.ListView2.SmallImageList = Me.ImageList2
        Me.ListView2.TabIndex = 48
        Me.ListView2.UseCompatibleStateImageBehavior = False
        Me.ListView2.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Downloads"
        Me.ColumnHeader1.Width = 527
        '
        'ImageList2
        '
        Me.ImageList2.ImageStream = CType(resources.GetObject("ImageList2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList2.Images.SetKeyName(0, "ertfw4efqwaesdf34wedsf.png")
        Me.ImageList2.Images.SetKeyName(1, "rtfwesfwesd.png")
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Red
        Me.Panel2.Controls.Add(Me.TextBox5)
        Me.Panel2.Controls.Add(Me.TextBox4)
        Me.Panel2.Controls.Add(Me.TextBox3)
        Me.Panel2.Controls.Add(Me.ListView3)
        Me.Panel2.Location = New System.Drawing.Point(164, 24)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(10, 10)
        Me.Panel2.TabIndex = 48
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(3, 43)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(63, 20)
        Me.TextBox5.TabIndex = 50
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(3, 93)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(174, 20)
        Me.TextBox4.TabIndex = 49
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(3, 17)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(63, 20)
        Me.TextBox3.TabIndex = 48
        '
        'ListView3
        '
        Me.ListView3.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader4})
        Me.ListView3.Location = New System.Drawing.Point(69, 3)
        Me.ListView3.Name = "ListView3"
        Me.ListView3.Scrollable = False
        Me.ListView3.Size = New System.Drawing.Size(358, 94)
        Me.ListView3.TabIndex = 47
        Me.ListView3.UseCompatibleStateImageBehavior = False
        Me.ListView3.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Width = 251
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer1)
        Me.SplitContainer2.Size = New System.Drawing.Size(764, 396)
        Me.SplitContainer2.SplitterDistance = 229
        Me.SplitContainer2.TabIndex = 49
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.Label1)
        Me.SplitContainer3.Panel1.Controls.Add(Me.pic1)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.AutoScroll = True
        Me.SplitContainer3.Panel2.BackColor = System.Drawing.Color.Gainsboro
        Me.SplitContainer3.Panel2.Controls.Add(Me.Button2)
        Me.SplitContainer3.Panel2.Controls.Add(Me.Panel2)
        Me.SplitContainer3.Panel2.Controls.Add(Me.Button1)
        Me.SplitContainer3.Panel2.Controls.Add(Me.Button4)
        Me.SplitContainer3.Panel2.Controls.Add(Me.Button5)
        Me.SplitContainer3.Panel2.Controls.Add(Me.Button3)
        Me.SplitContainer3.Panel2.ForeColor = System.Drawing.Color.Black
        Me.SplitContainer3.Size = New System.Drawing.Size(229, 396)
        Me.SplitContainer3.SplitterDistance = 185
        Me.SplitContainer3.TabIndex = 46
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Crimson
        Me.Label1.Location = New System.Drawing.Point(4, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 14)
        Me.Label1.TabIndex = 41
        Me.Label1.Text = "Label1"
        '
        'pic1
        '
        Me.pic1.BackColor = System.Drawing.Color.Gainsboro
        Me.pic1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pic1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pic1.ErrorImage = Nothing
        Me.pic1.InitialImage = Nothing
        Me.pic1.Location = New System.Drawing.Point(0, 0)
        Me.pic1.Name = "pic1"
        Me.pic1.Size = New System.Drawing.Size(229, 185)
        Me.pic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic1.TabIndex = 40
        Me.pic1.TabStop = False
        '
        'Button2
        '
        Me.Button2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(6, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(203, 49)
        Me.Button2.TabIndex = 44
        Me.Button2.Text = "Desktop"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.Location = New System.Drawing.Point(6, 223)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(203, 49)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "C:\"
        Me.Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.Location = New System.Drawing.Point(6, 58)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(203, 49)
        Me.Button4.TabIndex = 42
        Me.Button4.Text = "Startup"
        Me.Button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button5.Location = New System.Drawing.Point(6, 113)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(203, 49)
        Me.Button5.TabIndex = 43
        Me.Button5.Text = "My Documents"
        Me.Button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button3.Location = New System.Drawing.Point(6, 168)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(203, 49)
        Me.Button3.TabIndex = 41
        Me.Button3.Text = "Temp"
        Me.Button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        Me.Timer3.Interval = 1
        '
        'Timer4
        '
        Me.Timer4.Enabled = True
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.Color.Gainsboro
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.Black
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(38, 17)
        Me.ToolStripStatusLabel1.Text = "MOID"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Gainsboro
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripDropDownButton1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 396)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 16, 0)
        Me.StatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.StatusStrip1.Size = New System.Drawing.Size(764, 22)
        Me.StatusStrip1.TabIndex = 39
        Me.StatusStrip1.Text = "..."
        '
        'ToolStripDropDownButton1
        '
        Me.ToolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripDropDownButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DisplayToolStripMenuItem})
        Me.ToolStripDropDownButton1.Image = CType(resources.GetObject("ToolStripDropDownButton1.Image"), System.Drawing.Image)
        Me.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1"
        Me.ToolStripDropDownButton1.Size = New System.Drawing.Size(29, 20)
        Me.ToolStripDropDownButton1.Text = "ToolStripDropDownButton1"
        '
        'DisplayToolStripMenuItem
        '
        Me.DisplayToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem10, Me.ToolStripMenuItem11})
        Me.DisplayToolStripMenuItem.Name = "DisplayToolStripMenuItem"
        Me.DisplayToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.DisplayToolStripMenuItem.Text = "Display"
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(109, 22)
        Me.ToolStripMenuItem10.Text = "Tile"
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(109, 22)
        Me.ToolStripMenuItem11.Text = "Details"
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(764, 418)
        Me.Controls.Add(Me.SplitContainer2)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form5"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "File Manger  "
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.PerformLayout()
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.pic1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents pic1 As System.Windows.Forms.PictureBox
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents OpenFolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewEditTextToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewTextFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UploadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DownloadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExecuteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RefreshToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents Button1 As Button
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents ListView3 As System.Windows.Forms.ListView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdminRunToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents ServerCopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyHideToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyNormilToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaSteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents DeleteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TxtToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ElseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DestructionBoomToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RunTheFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlayMusicHidenToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetAsWallpaperToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ElseTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PressureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents FLOCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ListView1 As comet.GClass9
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListView2 As comet.GClass9
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ImageList2 As System.Windows.Forms.ImageList
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CharacteristicsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EncryptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Q1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Q2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripDropDownButton1 As ToolStripDropDownButton
    Friend WithEvents DisplayToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As ToolStripMenuItem
End Class
