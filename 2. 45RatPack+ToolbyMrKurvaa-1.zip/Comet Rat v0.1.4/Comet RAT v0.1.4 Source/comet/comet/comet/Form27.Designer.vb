﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form27
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form27))
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.gg = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(45, 244)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 69
        Me.Label5.Text = "Label5"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label4.Location = New System.Drawing.Point(70, 21)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 13)
        Me.Label4.TabIndex = 68
        Me.Label4.Text = "Label4"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label1.Location = New System.Drawing.Point(35, 89)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 65
        Me.Label1.Text = "Label1"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.SkyBlue
        Me.Label17.Location = New System.Drawing.Point(8, 244)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(28, 13)
        Me.Label17.TabIndex = 64
        Me.Label17.Text = "OS :"
        '
        'Timer1
        '
        Me.Timer1.Interval = 20
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label3.Location = New System.Drawing.Point(48, 57)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 67
        Me.Label3.Text = "Label3"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label2.Location = New System.Drawing.Point(48, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 66
        Me.Label2.Text = "Label2"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Gray
        Me.Label16.Location = New System.Drawing.Point(53, 7)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(53, 13)
        Me.Label16.TabIndex = 63
        Me.Label16.Text = "Country_"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Gray
        Me.Label15.Location = New System.Drawing.Point(10, 57)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(36, 13)
        Me.Label15.TabIndex = 62
        Me.Label15.Text = "User :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Gray
        Me.Label12.Location = New System.Drawing.Point(11, 39)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(24, 13)
        Me.Label12.TabIndex = 60
        Me.Label12.Text = "ID :"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 460)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 70
        Me.TextBox1.Text = "1"
        '
        'gg
        '
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.Control
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(283, 5)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(24, 24)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 71
        Me.PictureBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.ListView1)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Location = New System.Drawing.Point(-4, -2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(312, 81)
        Me.Panel1.TabIndex = 72
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.Location = New System.Drawing.Point(0, -28)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(327, 141)
        Me.Panel2.TabIndex = 73
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.DimGray
        Me.Panel3.Location = New System.Drawing.Point(266, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(10, 81)
        Me.Panel3.TabIndex = 74
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.SystemColors.Control
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.ListView1.LargeImageList = Me.ImageList1
        Me.ListView1.Location = New System.Drawing.Point(6, 5)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Scrollable = False
        Me.ListView1.Size = New System.Drawing.Size(45, 30)
        Me.ListView1.SmallImageList = Me.ImageList1
        Me.ListView1.TabIndex = 4
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.SmallIcon
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "0.png")
        Me.ImageList1.Images.SetKeyName(1, "1.png")
        Me.ImageList1.Images.SetKeyName(2, "2.png")
        Me.ImageList1.Images.SetKeyName(3, "3.png")
        Me.ImageList1.Images.SetKeyName(4, "4.png")
        Me.ImageList1.Images.SetKeyName(5, "5.png")
        Me.ImageList1.Images.SetKeyName(6, "6.png")
        Me.ImageList1.Images.SetKeyName(7, "7.png")
        Me.ImageList1.Images.SetKeyName(8, "8.png")
        Me.ImageList1.Images.SetKeyName(9, "9.png")
        Me.ImageList1.Images.SetKeyName(10, "10.png")
        Me.ImageList1.Images.SetKeyName(11, "11.png")
        Me.ImageList1.Images.SetKeyName(12, "12.png")
        Me.ImageList1.Images.SetKeyName(13, "13.png")
        Me.ImageList1.Images.SetKeyName(14, "14.png")
        Me.ImageList1.Images.SetKeyName(15, "15.png")
        Me.ImageList1.Images.SetKeyName(16, "16.png")
        Me.ImageList1.Images.SetKeyName(17, "17.png")
        Me.ImageList1.Images.SetKeyName(18, "18.png")
        Me.ImageList1.Images.SetKeyName(19, "19.png")
        Me.ImageList1.Images.SetKeyName(20, "20.png")
        Me.ImageList1.Images.SetKeyName(21, "21.png")
        Me.ImageList1.Images.SetKeyName(22, "22.png")
        Me.ImageList1.Images.SetKeyName(23, "23.png")
        Me.ImageList1.Images.SetKeyName(24, "24.png")
        Me.ImageList1.Images.SetKeyName(25, "25.png")
        Me.ImageList1.Images.SetKeyName(26, "26.png")
        Me.ImageList1.Images.SetKeyName(27, "27.png")
        Me.ImageList1.Images.SetKeyName(28, "28.png")
        Me.ImageList1.Images.SetKeyName(29, "29.png")
        Me.ImageList1.Images.SetKeyName(30, "30.png")
        Me.ImageList1.Images.SetKeyName(31, "31.png")
        Me.ImageList1.Images.SetKeyName(32, "32.png")
        Me.ImageList1.Images.SetKeyName(33, "33.png")
        Me.ImageList1.Images.SetKeyName(34, "34.png")
        Me.ImageList1.Images.SetKeyName(35, "35.png")
        Me.ImageList1.Images.SetKeyName(36, "36.png")
        Me.ImageList1.Images.SetKeyName(37, "37.png")
        Me.ImageList1.Images.SetKeyName(38, "38.png")
        Me.ImageList1.Images.SetKeyName(39, "39.png")
        Me.ImageList1.Images.SetKeyName(40, "40.png")
        Me.ImageList1.Images.SetKeyName(41, "41.png")
        Me.ImageList1.Images.SetKeyName(42, "42.png")
        Me.ImageList1.Images.SetKeyName(43, "43.png")
        Me.ImageList1.Images.SetKeyName(44, "44.png")
        Me.ImageList1.Images.SetKeyName(45, "45.png")
        Me.ImageList1.Images.SetKeyName(46, "46.png")
        Me.ImageList1.Images.SetKeyName(47, "47.png")
        Me.ImageList1.Images.SetKeyName(48, "48.png")
        Me.ImageList1.Images.SetKeyName(49, "49.png")
        Me.ImageList1.Images.SetKeyName(50, "50.png")
        Me.ImageList1.Images.SetKeyName(51, "51.png")
        Me.ImageList1.Images.SetKeyName(52, "52.png")
        Me.ImageList1.Images.SetKeyName(53, "53.png")
        Me.ImageList1.Images.SetKeyName(54, "54.png")
        Me.ImageList1.Images.SetKeyName(55, "55.png")
        Me.ImageList1.Images.SetKeyName(56, "56.png")
        Me.ImageList1.Images.SetKeyName(57, "57.png")
        Me.ImageList1.Images.SetKeyName(58, "58.png")
        Me.ImageList1.Images.SetKeyName(59, "59.png")
        Me.ImageList1.Images.SetKeyName(60, "60.png")
        Me.ImageList1.Images.SetKeyName(61, "61.png")
        Me.ImageList1.Images.SetKeyName(62, "62.png")
        Me.ImageList1.Images.SetKeyName(63, "63.png")
        Me.ImageList1.Images.SetKeyName(64, "64.png")
        Me.ImageList1.Images.SetKeyName(65, "65.png")
        Me.ImageList1.Images.SetKeyName(66, "66.png")
        Me.ImageList1.Images.SetKeyName(67, "67.png")
        Me.ImageList1.Images.SetKeyName(68, "68.png")
        Me.ImageList1.Images.SetKeyName(69, "69.png")
        Me.ImageList1.Images.SetKeyName(70, "70.png")
        Me.ImageList1.Images.SetKeyName(71, "71.png")
        Me.ImageList1.Images.SetKeyName(72, "72.png")
        Me.ImageList1.Images.SetKeyName(73, "73.png")
        Me.ImageList1.Images.SetKeyName(74, "74.png")
        Me.ImageList1.Images.SetKeyName(75, "75.png")
        Me.ImageList1.Images.SetKeyName(76, "76.png")
        Me.ImageList1.Images.SetKeyName(77, "77.png")
        Me.ImageList1.Images.SetKeyName(78, "78.png")
        Me.ImageList1.Images.SetKeyName(79, "79.png")
        Me.ImageList1.Images.SetKeyName(80, "80.png")
        Me.ImageList1.Images.SetKeyName(81, "81.png")
        Me.ImageList1.Images.SetKeyName(82, "82.png")
        Me.ImageList1.Images.SetKeyName(83, "83.png")
        Me.ImageList1.Images.SetKeyName(84, "84.png")
        Me.ImageList1.Images.SetKeyName(85, "85.png")
        Me.ImageList1.Images.SetKeyName(86, "86.png")
        Me.ImageList1.Images.SetKeyName(87, "87.png")
        Me.ImageList1.Images.SetKeyName(88, "88.png")
        Me.ImageList1.Images.SetKeyName(89, "89.png")
        Me.ImageList1.Images.SetKeyName(90, "90.png")
        Me.ImageList1.Images.SetKeyName(91, "91.png")
        Me.ImageList1.Images.SetKeyName(92, "92.png")
        Me.ImageList1.Images.SetKeyName(93, "93.png")
        Me.ImageList1.Images.SetKeyName(94, "94.png")
        Me.ImageList1.Images.SetKeyName(95, "95.png")
        Me.ImageList1.Images.SetKeyName(96, "96.png")
        Me.ImageList1.Images.SetKeyName(97, "97.png")
        Me.ImageList1.Images.SetKeyName(98, "98.png")
        Me.ImageList1.Images.SetKeyName(99, "99.png")
        Me.ImageList1.Images.SetKeyName(100, "100.png")
        Me.ImageList1.Images.SetKeyName(101, "101.png")
        Me.ImageList1.Images.SetKeyName(102, "102.png")
        Me.ImageList1.Images.SetKeyName(103, "103.png")
        Me.ImageList1.Images.SetKeyName(104, "104.png")
        Me.ImageList1.Images.SetKeyName(105, "105.png")
        Me.ImageList1.Images.SetKeyName(106, "106.png")
        Me.ImageList1.Images.SetKeyName(107, "107.png")
        Me.ImageList1.Images.SetKeyName(108, "108.png")
        Me.ImageList1.Images.SetKeyName(109, "109.png")
        Me.ImageList1.Images.SetKeyName(110, "110.png")
        Me.ImageList1.Images.SetKeyName(111, "111.png")
        Me.ImageList1.Images.SetKeyName(112, "112.png")
        Me.ImageList1.Images.SetKeyName(113, "113.png")
        Me.ImageList1.Images.SetKeyName(114, "114.png")
        Me.ImageList1.Images.SetKeyName(115, "115.png")
        Me.ImageList1.Images.SetKeyName(116, "116.png")
        Me.ImageList1.Images.SetKeyName(117, "117.png")
        Me.ImageList1.Images.SetKeyName(118, "118.png")
        Me.ImageList1.Images.SetKeyName(119, "119.png")
        Me.ImageList1.Images.SetKeyName(120, "120.png")
        Me.ImageList1.Images.SetKeyName(121, "121.png")
        Me.ImageList1.Images.SetKeyName(122, "122.png")
        Me.ImageList1.Images.SetKeyName(123, "123.png")
        Me.ImageList1.Images.SetKeyName(124, "124.png")
        Me.ImageList1.Images.SetKeyName(125, "125.png")
        Me.ImageList1.Images.SetKeyName(126, "126.png")
        Me.ImageList1.Images.SetKeyName(127, "127.png")
        Me.ImageList1.Images.SetKeyName(128, "128.png")
        Me.ImageList1.Images.SetKeyName(129, "129.png")
        Me.ImageList1.Images.SetKeyName(130, "130.png")
        Me.ImageList1.Images.SetKeyName(131, "131.png")
        Me.ImageList1.Images.SetKeyName(132, "132.png")
        Me.ImageList1.Images.SetKeyName(133, "133.png")
        Me.ImageList1.Images.SetKeyName(134, "134.png")
        Me.ImageList1.Images.SetKeyName(135, "135.png")
        Me.ImageList1.Images.SetKeyName(136, "136.png")
        Me.ImageList1.Images.SetKeyName(137, "137.png")
        Me.ImageList1.Images.SetKeyName(138, "138.png")
        Me.ImageList1.Images.SetKeyName(139, "139.png")
        Me.ImageList1.Images.SetKeyName(140, "140.png")
        Me.ImageList1.Images.SetKeyName(141, "141.png")
        Me.ImageList1.Images.SetKeyName(142, "142.png")
        Me.ImageList1.Images.SetKeyName(143, "143.png")
        Me.ImageList1.Images.SetKeyName(144, "144.png")
        Me.ImageList1.Images.SetKeyName(145, "145.png")
        Me.ImageList1.Images.SetKeyName(146, "146.png")
        Me.ImageList1.Images.SetKeyName(147, "147.png")
        Me.ImageList1.Images.SetKeyName(148, "148.png")
        Me.ImageList1.Images.SetKeyName(149, "149.png")
        Me.ImageList1.Images.SetKeyName(150, "150.png")
        Me.ImageList1.Images.SetKeyName(151, "151.png")
        Me.ImageList1.Images.SetKeyName(152, "152.png")
        Me.ImageList1.Images.SetKeyName(153, "153.png")
        Me.ImageList1.Images.SetKeyName(154, "154.png")
        Me.ImageList1.Images.SetKeyName(155, "155.png")
        Me.ImageList1.Images.SetKeyName(156, "156.png")
        Me.ImageList1.Images.SetKeyName(157, "157.png")
        Me.ImageList1.Images.SetKeyName(158, "158.png")
        Me.ImageList1.Images.SetKeyName(159, "159.png")
        Me.ImageList1.Images.SetKeyName(160, "160.png")
        Me.ImageList1.Images.SetKeyName(161, "161.png")
        Me.ImageList1.Images.SetKeyName(162, "162.png")
        Me.ImageList1.Images.SetKeyName(163, "163.png")
        Me.ImageList1.Images.SetKeyName(164, "164.png")
        Me.ImageList1.Images.SetKeyName(165, "165.png")
        Me.ImageList1.Images.SetKeyName(166, "166.png")
        Me.ImageList1.Images.SetKeyName(167, "167.png")
        Me.ImageList1.Images.SetKeyName(168, "168.png")
        Me.ImageList1.Images.SetKeyName(169, "169.png")
        Me.ImageList1.Images.SetKeyName(170, "170.png")
        Me.ImageList1.Images.SetKeyName(171, "171.png")
        Me.ImageList1.Images.SetKeyName(172, "172.png")
        Me.ImageList1.Images.SetKeyName(173, "173.png")
        Me.ImageList1.Images.SetKeyName(174, "174.png")
        Me.ImageList1.Images.SetKeyName(175, "175.png")
        Me.ImageList1.Images.SetKeyName(176, "176.png")
        Me.ImageList1.Images.SetKeyName(177, "177.png")
        Me.ImageList1.Images.SetKeyName(178, "178.png")
        Me.ImageList1.Images.SetKeyName(179, "179.png")
        Me.ImageList1.Images.SetKeyName(180, "180.png")
        Me.ImageList1.Images.SetKeyName(181, "181.png")
        Me.ImageList1.Images.SetKeyName(182, "182.png")
        Me.ImageList1.Images.SetKeyName(183, "183.png")
        Me.ImageList1.Images.SetKeyName(184, "184.png")
        Me.ImageList1.Images.SetKeyName(185, "185.png")
        Me.ImageList1.Images.SetKeyName(186, "186.png")
        Me.ImageList1.Images.SetKeyName(187, "187.png")
        Me.ImageList1.Images.SetKeyName(188, "188.png")
        Me.ImageList1.Images.SetKeyName(189, "189.png")
        Me.ImageList1.Images.SetKeyName(190, "190.png")
        Me.ImageList1.Images.SetKeyName(191, "191.png")
        Me.ImageList1.Images.SetKeyName(192, "192.png")
        Me.ImageList1.Images.SetKeyName(193, "193.png")
        Me.ImageList1.Images.SetKeyName(194, "194.png")
        Me.ImageList1.Images.SetKeyName(195, "195.png")
        Me.ImageList1.Images.SetKeyName(196, "196.png")
        Me.ImageList1.Images.SetKeyName(197, "197.png")
        Me.ImageList1.Images.SetKeyName(198, "198.png")
        Me.ImageList1.Images.SetKeyName(199, "199.png")
        Me.ImageList1.Images.SetKeyName(200, "200.png")
        Me.ImageList1.Images.SetKeyName(201, "201.png")
        Me.ImageList1.Images.SetKeyName(202, "202.png")
        Me.ImageList1.Images.SetKeyName(203, "203.png")
        Me.ImageList1.Images.SetKeyName(204, "204.png")
        Me.ImageList1.Images.SetKeyName(205, "205.png")
        Me.ImageList1.Images.SetKeyName(206, "206.png")
        Me.ImageList1.Images.SetKeyName(207, "207.png")
        Me.ImageList1.Images.SetKeyName(208, "208.png")
        Me.ImageList1.Images.SetKeyName(209, "209.png")
        Me.ImageList1.Images.SetKeyName(210, "210.png")
        Me.ImageList1.Images.SetKeyName(211, "211.png")
        Me.ImageList1.Images.SetKeyName(212, "212.png")
        Me.ImageList1.Images.SetKeyName(213, "213.png")
        Me.ImageList1.Images.SetKeyName(214, "214.png")
        Me.ImageList1.Images.SetKeyName(215, "215.png")
        Me.ImageList1.Images.SetKeyName(216, "216.png")
        Me.ImageList1.Images.SetKeyName(217, "217.png")
        Me.ImageList1.Images.SetKeyName(218, "218.png")
        Me.ImageList1.Images.SetKeyName(219, "219.png")
        Me.ImageList1.Images.SetKeyName(220, "220.png")
        Me.ImageList1.Images.SetKeyName(221, "221.png")
        Me.ImageList1.Images.SetKeyName(222, "222.png")
        Me.ImageList1.Images.SetKeyName(223, "223.png")
        Me.ImageList1.Images.SetKeyName(224, "224.png")
        Me.ImageList1.Images.SetKeyName(225, "225.png")
        Me.ImageList1.Images.SetKeyName(226, "226.png")
        Me.ImageList1.Images.SetKeyName(227, "227.png")
        Me.ImageList1.Images.SetKeyName(228, "228.png")
        Me.ImageList1.Images.SetKeyName(229, "229.png")
        Me.ImageList1.Images.SetKeyName(230, "230.png")
        Me.ImageList1.Images.SetKeyName(231, "231.png")
        Me.ImageList1.Images.SetKeyName(232, "232.png")
        Me.ImageList1.Images.SetKeyName(233, "233.png")
        Me.ImageList1.Images.SetKeyName(234, "234.png")
        Me.ImageList1.Images.SetKeyName(235, "235.png")
        Me.ImageList1.Images.SetKeyName(236, "236.png")
        Me.ImageList1.Images.SetKeyName(237, "237.png")
        Me.ImageList1.Images.SetKeyName(238, "238.png")
        Me.ImageList1.Images.SetKeyName(239, "239.png")
        Me.ImageList1.Images.SetKeyName(240, "240.png")
        Me.ImageList1.Images.SetKeyName(241, "241.png")
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 1
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, 75)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(308, 37)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 73
        Me.PictureBox2.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Gray
        Me.Label14.Location = New System.Drawing.Point(8, 89)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(19, 13)
        Me.Label14.TabIndex = 74
        Me.Label14.Text = "IP:"
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(81, 118)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(162, 91)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 75
        Me.PictureBox3.TabStop = False
        '
        'Form27
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(320, 242)
        Me.ControlBox = False
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox2)
        Me.ForeColor = System.Drawing.Color.Black
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form27"
        Me.Opacity = 0.93R
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents gg As System.Windows.Forms.Timer
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As PictureBox
End Class
