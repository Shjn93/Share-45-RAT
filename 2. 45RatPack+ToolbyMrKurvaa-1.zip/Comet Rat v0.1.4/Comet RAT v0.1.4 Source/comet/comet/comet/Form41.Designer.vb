﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form41
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form41))
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.AvTabControl1 = New comet.AVTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.AvButton4 = New comet.AVButton()
        Me.AvButton1 = New comet.AVButton()
        Me.AvButton3 = New comet.AVButton()
        Me.AvButton2 = New comet.AVButton()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.HuraAlertBox1 = New comet.HuraAlertBox()
        Me.AvButton6 = New comet.AVButton()
        Me.AvButton5 = New comet.AVButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.AvButton7 = New comet.AVButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.AvButton8 = New comet.AVButton()
        Me.AvTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "wewer.png")
        '
        'AvTabControl1
        '
        Me.AvTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.AvTabControl1.BorderColor = System.Drawing.Color.Black
        Me.AvTabControl1.Controls.Add(Me.TabPage1)
        Me.AvTabControl1.Controls.Add(Me.TabPage2)
        Me.AvTabControl1.Controls.Add(Me.TabPage3)
        Me.AvTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AvTabControl1.DrawBottomBorder = False
        Me.AvTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.AvTabControl1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.AvTabControl1.ImageList = Me.ImageList1
        Me.AvTabControl1.ItemSize = New System.Drawing.Size(50, 50)
        Me.AvTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.AvTabControl1.Multiline = True
        Me.AvTabControl1.Name = "AvTabControl1"
        Me.AvTabControl1.SelectedIndex = 0
        Me.AvTabControl1.Size = New System.Drawing.Size(781, 386)
        Me.AvTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.AvTabControl1.TabIndex = 2
        Me.AvTabControl1.TextAlignment = System.Drawing.StringAlignment.Near
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.TabPage1.Controls.Add(Me.RichTextBox1)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.ForeColor = System.Drawing.Color.Black
        Me.TabPage1.ImageIndex = 0
        Me.TabPage1.Location = New System.Drawing.Point(54, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(723, 378)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBox1.ForeColor = System.Drawing.Color.Black
        Me.RichTextBox1.Location = New System.Drawing.Point(3, 39)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(717, 336)
        Me.RichTextBox1.TabIndex = 1
        Me.RichTextBox1.Text = ""
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer))
        Me.Panel1.Controls.Add(Me.AvButton4)
        Me.Panel1.Controls.Add(Me.AvButton1)
        Me.Panel1.Controls.Add(Me.AvButton3)
        Me.Panel1.Controls.Add(Me.AvButton2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(717, 36)
        Me.Panel1.TabIndex = 3
        '
        'AvButton4
        '
        Me.AvButton4.BackColor = System.Drawing.Color.Transparent
        Me.AvButton4.Font = New System.Drawing.Font("Constantia", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AvButton4.ForeColor = System.Drawing.Color.Black
        Me.AvButton4.Location = New System.Drawing.Point(531, 6)
        Me.AvButton4.MainColor = Nothing
        Me.AvButton4.Name = "AvButton4"
        Me.AvButton4.Size = New System.Drawing.Size(126, 22)
        Me.AvButton4.TabIndex = 7
        Me.AvButton4.Text = "Host and port"
        '
        'AvButton1
        '
        Me.AvButton1.BackColor = System.Drawing.Color.Transparent
        Me.AvButton1.Font = New System.Drawing.Font("Constantia", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AvButton1.ForeColor = System.Drawing.Color.Black
        Me.AvButton1.Location = New System.Drawing.Point(33, 6)
        Me.AvButton1.MainColor = Nothing
        Me.AvButton1.Name = "AvButton1"
        Me.AvButton1.Size = New System.Drawing.Size(100, 22)
        Me.AvButton1.TabIndex = 4
        Me.AvButton1.Text = "TCP"
        '
        'AvButton3
        '
        Me.AvButton3.BackColor = System.Drawing.Color.Transparent
        Me.AvButton3.Font = New System.Drawing.Font("Constantia", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AvButton3.ForeColor = System.Drawing.Color.Black
        Me.AvButton3.Location = New System.Drawing.Point(271, 6)
        Me.AvButton3.MainColor = Nothing
        Me.AvButton3.Name = "AvButton3"
        Me.AvButton3.Size = New System.Drawing.Size(254, 22)
        Me.AvButton3.TabIndex = 6
        Me.AvButton3.Text = "Connected devices in the network"
        '
        'AvButton2
        '
        Me.AvButton2.BackColor = System.Drawing.Color.Transparent
        Me.AvButton2.Font = New System.Drawing.Font("Constantia", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AvButton2.ForeColor = System.Drawing.Color.Black
        Me.AvButton2.Location = New System.Drawing.Point(139, 6)
        Me.AvButton2.MainColor = Nothing
        Me.AvButton2.Name = "AvButton2"
        Me.AvButton2.Size = New System.Drawing.Size(126, 22)
        Me.AvButton2.TabIndex = 5
        Me.AvButton2.Text = "Server runtime"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.HuraAlertBox1)
        Me.TabPage2.Controls.Add(Me.AvButton6)
        Me.TabPage2.Controls.Add(Me.AvButton5)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.TextBox2)
        Me.TabPage2.Controls.Add(Me.TextBox1)
        Me.TabPage2.Location = New System.Drawing.Point(54, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(723, 378)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        '
        'HuraAlertBox1
        '
        Me.HuraAlertBox1.AlertStyle = comet.HuraAlertBox.Style.Warning
        Me.HuraAlertBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.HuraAlertBox1.Location = New System.Drawing.Point(58, 167)
        Me.HuraAlertBox1.Name = "HuraAlertBox1"
        Me.HuraAlertBox1.Size = New System.Drawing.Size(532, 40)
        Me.HuraAlertBox1.TabIndex = 9
        Me.HuraAlertBox1.Text = "To avoid problems, you must change the server name when you set up each server !!" &
    ""
        '
        'AvButton6
        '
        Me.AvButton6.BackColor = System.Drawing.Color.Transparent
        Me.AvButton6.Location = New System.Drawing.Point(383, 337)
        Me.AvButton6.MainColor = Nothing
        Me.AvButton6.Name = "AvButton6"
        Me.AvButton6.Size = New System.Drawing.Size(159, 33)
        Me.AvButton6.TabIndex = 8
        Me.AvButton6.Text = "Default retrieval"
        '
        'AvButton5
        '
        Me.AvButton5.BackColor = System.Drawing.Color.Transparent
        Me.AvButton5.Location = New System.Drawing.Point(557, 337)
        Me.AvButton5.MainColor = Nothing
        Me.AvButton5.Name = "AvButton5"
        Me.AvButton5.Size = New System.Drawing.Size(159, 33)
        Me.AvButton5.TabIndex = 7
        Me.AvButton5.Text = "Save"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(23, 105)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 15)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Port"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(20, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 15)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Host"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.White
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.ForeColor = System.Drawing.Color.Black
        Me.TextBox2.Location = New System.Drawing.Point(58, 102)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(448, 23)
        Me.TextBox2.TabIndex = 1
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.Color.Black
        Me.TextBox1.Location = New System.Drawing.Point(58, 45)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(448, 23)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "127.0.0.1"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.AvButton8)
        Me.TabPage3.Controls.Add(Me.Label4)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Controls.Add(Me.AvButton7)
        Me.TabPage3.Controls.Add(Me.TextBox3)
        Me.TabPage3.Location = New System.Drawing.Point(54, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(723, 378)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "TabPage3"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.White
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.ForeColor = System.Drawing.Color.Black
        Me.TextBox3.Location = New System.Drawing.Point(123, 55)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(451, 23)
        Me.TextBox3.TabIndex = 2
        Me.TextBox3.Text = "www.xnxx.com"
        '
        'AvButton7
        '
        Me.AvButton7.BackColor = System.Drawing.Color.Transparent
        Me.AvButton7.Location = New System.Drawing.Point(545, 324)
        Me.AvButton7.MainColor = Nothing
        Me.AvButton7.Name = "AvButton7"
        Me.AvButton7.Size = New System.Drawing.Size(159, 33)
        Me.AvButton7.TabIndex = 8
        Me.AvButton7.Text = "new Block"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(79, 58)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 15)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Block"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label4.Location = New System.Drawing.Point(23, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 21)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Site closed"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label5.Location = New System.Drawing.Point(12, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(157, 21)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Replacement Contact"
        '
        'AvButton8
        '
        Me.AvButton8.BackColor = System.Drawing.Color.Transparent
        Me.AvButton8.Location = New System.Drawing.Point(380, 324)
        Me.AvButton8.MainColor = Nothing
        Me.AvButton8.Name = "AvButton8"
        Me.AvButton8.Size = New System.Drawing.Size(159, 33)
        Me.AvButton8.TabIndex = 11
        Me.AvButton8.Text = "Activation Site"
        '
        'Form41
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(781, 386)
        Me.Controls.Add(Me.AvTabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form41"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "network"
        Me.AvTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents AvTabControl1 As comet.AVTabControl
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents AvButton4 As comet.AVButton
    Friend WithEvents AvButton3 As comet.AVButton
    Friend WithEvents AvButton2 As comet.AVButton
    Friend WithEvents AvButton1 As comet.AVButton
    Friend WithEvents AvButton5 As comet.AVButton
    Friend WithEvents AvButton6 As comet.AVButton
    Friend WithEvents HuraAlertBox1 As comet.HuraAlertBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents AvButton7 As AVButton
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents AvButton8 As AVButton
End Class
