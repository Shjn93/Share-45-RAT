﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class q
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer6 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer7 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer8 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer9 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer10 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer11 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer12 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer13 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer14 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer15 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer16 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer17 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Timer18 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Horror = New System.Windows.Forms.Timer(Me.components)
        Me.hekoo = New System.Windows.Forms.TextBox()
        Me.KKKKS = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Timer19 = New System.Windows.Forms.Timer(Me.components)
        Me.xtrem = New System.Windows.Forms.RichTextBox()
        Me.Timer20 = New System.Windows.Forms.Timer(Me.components)
        Me.PfcCPU = New System.Diagnostics.PerformanceCounter()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        CType(Me.PfcCPU, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 8000
        '
        'Timer3
        '
        Me.Timer3.Interval = 10
        '
        'Timer4
        '
        Me.Timer4.Interval = 10
        '
        'Timer5
        '
        Me.Timer5.Interval = 10
        '
        'Timer6
        '
        Me.Timer6.Interval = 10
        '
        'Timer7
        '
        Me.Timer7.Interval = 10
        '
        'Timer8
        '
        Me.Timer8.Interval = 1000
        '
        'Timer9
        '
        Me.Timer9.Interval = 10
        '
        'Timer10
        '
        Me.Timer10.Interval = 10
        '
        'Timer11
        '
        Me.Timer11.Interval = 10
        '
        'Timer12
        '
        Me.Timer12.Interval = 10
        '
        'Timer13
        '
        Me.Timer13.Interval = 10
        '
        'Timer14
        '
        Me.Timer14.Interval = 10
        '
        'Timer15
        '
        Me.Timer15.Interval = 10
        '
        'Timer16
        '
        Me.Timer16.Interval = 10
        '
        'Timer17
        '
        Me.Timer17.Interval = 10
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(110, 51)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 0
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(110, 77)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 1
        '
        'Timer18
        '
        Me.Timer18.Interval = 5000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(257, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(13, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "1"
        '
        'Horror
        '
        Me.Horror.Enabled = True
        Me.Horror.Interval = 150
        '
        'hekoo
        '
        Me.hekoo.Location = New System.Drawing.Point(148, 159)
        Me.hekoo.Name = "hekoo"
        Me.hekoo.Size = New System.Drawing.Size(100, 20)
        Me.hekoo.TabIndex = 3
        '
        'KKKKS
        '
        Me.KKKKS.Location = New System.Drawing.Point(314, 186)
        Me.KKKKS.Name = "KKKKS"
        Me.KKKKS.Size = New System.Drawing.Size(100, 20)
        Me.KKKKS.TabIndex = 4
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(328, 114)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 5
        Me.TextBox3.Text = "1"
        '
        'Timer19
        '
        '
        'xtrem
        '
        Me.xtrem.Location = New System.Drawing.Point(440, 77)
        Me.xtrem.Name = "xtrem"
        Me.xtrem.Size = New System.Drawing.Size(100, 96)
        Me.xtrem.TabIndex = 6
        Me.xtrem.Text = ""
        '
        'Timer20
        '
        Me.Timer20.Enabled = True
        '
        'PfcCPU
        '
        Me.PfcCPU.CategoryName = "Processor"
        Me.PfcCPU.CounterName = "% Processor Time"
        Me.PfcCPU.InstanceName = "_Total"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(328, 241)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 7
        '
        'q
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(73, 152)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.xtrem)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.KKKKS)
        Me.Controls.Add(Me.hekoo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.name = "q"
        Me.Opacity = 0R
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        CType(Me.PfcCPU, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents Timer5 As System.Windows.Forms.Timer
    Friend WithEvents Timer6 As System.Windows.Forms.Timer
    Friend WithEvents Timer7 As System.Windows.Forms.Timer
    Friend WithEvents Timer8 As System.Windows.Forms.Timer
    Friend WithEvents Timer9 As System.Windows.Forms.Timer
    Friend WithEvents Timer10 As System.Windows.Forms.Timer
    Friend WithEvents Timer11 As System.Windows.Forms.Timer
    Friend WithEvents Timer12 As System.Windows.Forms.Timer
    Friend WithEvents Timer13 As System.Windows.Forms.Timer
    Friend WithEvents Timer14 As System.Windows.Forms.Timer
    Friend WithEvents Timer15 As System.Windows.Forms.Timer
    Friend WithEvents Timer16 As System.Windows.Forms.Timer
    Friend WithEvents Timer17 As System.Windows.Forms.Timer
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Timer18 As System.Windows.Forms.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Horror As System.Windows.Forms.Timer
    Friend WithEvents hekoo As System.Windows.Forms.TextBox
    Friend WithEvents KKKKS As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Timer19 As System.Windows.Forms.Timer
    Friend WithEvents xtrem As System.Windows.Forms.RichTextBox
    Friend WithEvents Timer20 As System.Windows.Forms.Timer
    Friend WithEvents PfcCPU As System.Diagnostics.PerformanceCounter
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
End Class
