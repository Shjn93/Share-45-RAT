DarkComet-RAT v4.0
------------------

Be sure you download the program from the official website : 
http://www.darkcomet-rat.com/

Don't forget to read the EULA.

Software designed, managed and coded by DarkCoderSc.
A single guy from FRANCE !!!!!!

Hope you will enjoy my free work.

notice: This software is 100% free and can be use under personal and
profesionnal needs.
The only thing you can't do with it is sell it.

Regards,
DarkCoderSc@Unremote.org